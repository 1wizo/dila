# DILA Installer — Build Instructions (v6.0.0)

This package replaces the legacy `DILA_v5.12_Setup.hta` installer with two
modern, production-ready installers:

| Platform | Tool         | Output file                  |
|----------|--------------|------------------------------|
| Windows  | Inno Setup 6 | `DILA_v6_Setup.exe`         |
| Linux    | AppImageKit  | `DILA-v6.0.0-x86_64.AppImage`|

The original HTA installer was treated as the **specification** — every step
it performed (download Python, install silently, test tkinter, pip install
deps, install Node.js, write `dila.pyw`, create shortcuts, write
`data.json`) is preserved here 1:1. The DILA application itself is
**unchanged** — only the installer has been replaced.

---

## 1. Repository layout

```
dila-installer-v6/
├── dila/                          # Bundled application assets (shared)
│   ├── dila.pyw                   # The DILA app (extracted from the HTA's DILA_B64)
│   ├── dila_map_qt.pyw            # PyQt6 knowledge map (extracted from DILA_MAP_B64)
│   ├── dila.ico                   # Multi-resolution Windows icon (16–256)
│   ├── dila_256.png               # 256×256 PNG (Linux icon)
│   ├── dila_512.png               # 512×512 PNG (Linux icon)
│   ├── dila.svg                   # Source SVG (flame + checkmark logo)
│   ├── wizard.bmp                 # Inno Setup wizard side image (197×313)
│   ├── wizard_small.bmp           # Inno Setup small image (69×71)
│   └── LICENSE.txt                # MIT license + 3rd-party notices
│
├── inno/                          # Windows installer (Inno Setup)
│   ├── DILA_v6_Setup.iss          # Main installer source
│   ├── helpers/
│   │   ├── step_01_python.bat     # Download + install Python 3.12.3 (user-scope)
│   │   ├── step_02_tkinter.bat    # Test tkinter, repair if broken
│   │   ├── step_03_pipdeps.bat    # pip install pystray Pillow pyttsx3 numpy matplotlib win11toast PyQt6 dukpy
│   │   ├── step_04_nodejs.bat     # Install Node.js LTS (winget → MSI fallback)
│   │   └── step_05_userdata.bat   # Persist detected Python paths
│   └── Output/                    # ISCC writes the .exe here
│
└── appimage/                      # Linux installer (AppImage)
    ├── AppDir/
    │   ├── AppRun                 # Launcher: locates python3, builds venv, launches dila.pyw
    │   ├── dila.desktop           # XDG desktop entry
    │   ├── dila.svg               # Root icon
    │   └── usr/
    │       ├── bin/dila           # Symlink → ../lib/dila/dila.pyw
    │       ├── lib/dila/
    │       │   ├── dila.pyw
    │       │   ├── dila_map_qt.pyw
    │       │   └── LICENSE.txt
    │       └── share/
    │           ├── applications/dila.desktop
    │           └── icons/hicolor/{16,32,48,64,128,256,512,scalable}/apps/dila.{png,svg}
    ├── build_appimage.sh          # One-shot build script
    └── output/
        └── DILA-v6.0.0-x86_64.AppImage
```

---

## 2. Build the Windows installer

### Prerequisites

* **Inno Setup 6.2.0 or newer** (Unicode)
  Download from <https://jrsoftware.org/isdl.php>
* Windows 10/11 x64 (or Wine + Inno Setup on Linux/macOS)
* ~1 MB free disk space for the source; output is ~600 KB

### Build

```cmd
:: From the inno/ directory
cd inno
iscc DILA_v6_Setup.iss
```

Output: `inno\Output\DILA_v6_Setup.exe`

### What the installer does (matches the HTA step-by-step)

| # | HTA step                       | Inno Setup implementation                                         |
|---|--------------------------------|-------------------------------------------------------------------|
| 1 | Download Python 3.12.3         | `helpers\step_01_python.bat` via PowerShell `WebClient`           |
| 2 | Install Python quietly         | `python-3.12.3-amd64.exe /quiet InstallAllUsers=0 …`              |
| 3 | Test tkinter, repair if broken | `helpers\step_02_tkinter.bat`                                     |
| 4 | pip install deps               | `helpers\step_03_pipdeps.bat` (pystray, Pillow, pyttsx3, numpy, matplotlib, win11toast, PyQt6, dukpy) |
| 5 | Install Node.js LTS            | `helpers\step_04_nodejs.bat` (winget → MSI fallback)              |
| 6 | Stop running DILA + recreate folder | Inno `[Run]` step + `[Dirs]`                              |
| 7 | Write `dila.pyw` + `dila_map_qt.pyw` | Inno `[Files]` section                                 |
| 8 | Create shortcuts               | Inno `[Icons]` (Desktop / Start Menu / Startup)                   |
| 9 | Write `data.json`              | Inno `CurStepChanged(ssPostInstall)` Pascal code                  |
| 10| Add/Remove Programs entry      | Inno automatic `[Registry]`                                       |

### Wizard pages (in order)

1. **Welcome** — DILA branding + icon
2. **License** — MIT license + 3rd-party notices
3. **Theme picker** — Dark Neon (default), Cyberpunk, Ocean, Sunset, Forest, Minimal Peace
4. **Install folder** — defaults to `%LOCALAPPDATA%\DILA` (no admin)
5. **Start Menu group** — defaults to `DILA`
6. **Tasks** — Desktop shortcut, Start Menu shortcut, Start with Windows, Minimize to tray
7. **Installing** — progress bar with per-step status messages
8. **Finish** — completion summary

### Behavioural notes (identical to the HTA)

* **No admin prompt** — installs into `%LOCALAPPDATA%`, `PrivilegesRequired=lowest`.
* **No PATH changes** — Python is installed with `PrependPath=0`, so it doesn't pollute the system PATH.
* **No auto-launch on finish** — preserved from the HTA's v5.9.9 change ("app no longer auto-launches").
* **Python detection** — checks `%LOCALAPPDATA%\Programs\Python\Python312\python.exe` first (HTA default), then registry (`HKCU\Software\Python\PythonCore\*\InstallPath` then HKLM), then `Wow6432Node`. If found, the Python download/install step is **skipped** — same as the HTA's "already satisfied" path.
* **Node.js detection** — `where node`, registry, then common winget locations. If found, the Node.js install step is **skipped**.
* **Clean uninstall** — by default, only program files are removed. User data (`%APPDATA%\DILA\data.json` and the install folder's `data.json`) is **preserved**. The uninstaller asks the user once: "Do you also want to delete your DILA streaks, notes and settings?" with **No** as the default (recommended).
* **Upgrade-safe** — `Flags: uninsneveruninstall` on the install folder + skip-overwrite of `%APPDATA%\DILA\data.json` means user streaks/notes survive reinstall.

---

## 3. Build the Linux AppImage

### Prerequisites

* Any modern Linux x86_64 (Ubuntu 18.04+, Fedora, Arch, etc.)
* `bash`, `wget` OR `curl`
* Internet access (the build script downloads `appimagetool` automatically on first run)
* **No root required**

### Build

```bash
cd appimage
./build_appimage.sh
```

Output: `appimage/output/DILA-v6.0.0-x86_64.AppImage` (~360 KB)

The build script:

1. Downloads `appimagetool-x86_64.AppImage` from the AppImageKit releases page (cached in `.tools/`).
2. Resamples the master 512×512 icon into all standard XDG sizes (16/32/48/64/128/256/512) if ImageMagick or `rsvg-convert` is available.
3. Validates the `AppDir` structure.
4. Invokes `appimagetool` to package `AppDir/` into a single `DILA-v6.0.0-x86_64.AppImage` file.

### How the AppImage runs (on the user's machine)

When a user double-clicks `DILA-v6.0.0-x86_64.AppImage`:

1. The AppImage runtime mounts the squashfs payload and executes `AppRun`.
2. `AppRun` locates a system `python3` (3.10+). If none is found, a helpful `zenity`/`kdialog`/`notify-send` error dialog is shown.
3. On **first launch**, `AppRun` creates a Python venv at `~/.local/share/DILA/venv/` and `pip install`s the cross-platform subset of DILA's deps:
   * `pystray`, `Pillow`, `pyttsx3`, `numpy`, `matplotlib`, `PyQt6`, `dukpy`
   * `win11toast`, `winreg`, `winsound` are **not** installed (Windows-only). `dila.pyw` already wraps them in `try/except ImportError`, so they fail soft.
4. On subsequent launches, the existing venv is reused — startup is instant.
5. `AppRun` exports `APPDATA=~/.config/DILA` so the app's `os.environ.get("APPDATA", …)` lookup writes `data.json` to the XDG-compliant location, matching the Windows behaviour exactly.
6. The app launches with `python` (no terminal window).

### User data locations (Linux)

| Path                                  | Purpose                          |
|---------------------------------------|----------------------------------|
| `~/.config/DILA/data.json`            | Streaks, notes, settings         |
| `~/.local/share/DILA/venv/`           | Cached Python venv (deps)        |
| `~/.local/share/DILA/.venv-stamp`     | First-run marker                 |
| `~/.cache/DILA/`                      | Transient caches                 |

All of these survive AppImage upgrades (the .AppImage file itself is read-only, so user state must live in `$HOME`).

### Distributing to users

```bash
# Users just need to:
chmod +x DILA-v6.0.0-x86_64.AppImage
./DILA-v6.0.0-x86_64.AppImage
```

If their distro doesn't have FUSE available (rare on personal machines, common in CI), they can extract-and-run:

```bash
./DILA-v6.0.0-x86_64.AppImage --appimage-extract-and-run
```

---

## 4. Verifying behavioural parity with the HTA

This table maps every observable behaviour of `DILA_v5.12_Setup.hta` to its
implementation in the new installers. If you find a row that doesn't hold,
file a bug — it's a regression.

| HTA behaviour                                                | Windows (Inno)                                 | Linux (AppImage)                          |
|--------------------------------------------------------------|------------------------------------------------|-------------------------------------------|
| Welcome screen with DILA branding + version badge           | Welcome page + `SetupIconFile` + `WizardImageFile` | N/A (AppImage launches directly)         |
| License page (mentioned in spec)                             | `LicenseFile=LICENSE.txt`                       | N/A                                       |
| Options: theme picker (6 themes, default Dark Neon)         | Custom wizard page after License                | First-run `data.json` writes Dark Neon    |
| Options: desktop shortcut (default ON)                       | Task `desktopicon` (checked)                    | Desktop entry installed by AppImage integration |
| Options: Start Menu shortcut (default ON)                    | Task `startmenuicon` (checked)                  | N/A (Linux has no Start Menu)             |
| Options: Start with Windows (default OFF)                    | Task `autostart` (unchecked)                    | N/A                                       |
| Options: Minimize to tray (default ON)                       | Task `mintray` (checked)                        | `min_tray: true` in initial `data.json`   |
| Install to `%LOCALAPPDATA%\DILA` (no admin)                  | `DefaultDirName={localappdata}\DILA`            | N/A — bundled inside AppImage             |
| Install Python 3.12.3 user-scope, no PATH                    | `step_01_python.bat`                            | N/A — uses system python3                 |
| Test tkinter, repair if broken                               | `step_02_tkinter.bat`                           | N/A                                       |
| pip install pystray Pillow pyttsx3 numpy matplotlib win11toast PyQt6 dukpy | `step_03_pipdeps.bat`              | `pip install` in AppRun (skips Win-only)  |
| Install Node.js LTS (winget → MSI fallback for v20.11.1)     | `step_04_nodejs.bat`                            | N/A (Linux users install via distro pkg)  |
| Stop running DILA (`taskkill pythonw.exe /F`)                | Inno `[Files]` `BeforeInstall` + `[UninstallRun]`| N/A                                       |
| Write `dila.pyw` from base64 payload                         | Inno `[Files]` ships the decoded file           | AppImage ships the decoded file           |
| Write `dila_map_qt.pyw` from base64 payload                  | Inno `[Files]` ships the decoded file           | AppImage ships the decoded file           |
| Create Desktop shortcut → `pythonw.exe "…\dila.pyw"`         | Inno `[Icons]`                                  | AppImage desktop integration              |
| Create Start Menu shortcut                                   | Inno `[Icons]`                                  | N/A                                       |
| Create Startup shortcut (optional)                           | Inno `[Icons]` with `Tasks: autostart`          | N/A                                       |
| Write `data.json` with `{theme, min_tray}` to install folder | `CurStepChanged(ssPostInstall)` writes `{app}\data.json` | AppRun writes `~/.config/DILA/data.json` on first run |
| Add/Remove Programs entry                                    | Inno automatic + `[Registry]` augmentations     | N/A                                       |
| Clean uninstall, preserve user data                          | `CurUninstallStepChanged` asks once, default NO | Just delete the AppImage file             |
| Does NOT auto-launch after install (per v5.9.9)              | No `[Run] postinstall` launch step              | N/A                                       |

---

## 5. Customising the build

### Bumping the version

Edit `inno/DILA_v6_Setup.iss`:

```
#define MyAppVersion  "6.0.0"     →  "6.1.0"
```

Edit `appimage/build_appimage.sh`:

```bash
APP_VERSION="6.0.0"   →   "6.1.0"
```

### Bundling a newer DILA app

Replace `dila/dila.pyw` and `dila/dila_map_qt.pyw` with the new versions
(either by re-running `python3 scripts/extract_payload.py` against a new
HTA, or by dropping in fresh copies from the DILA source tree). Then
rebuild both installers — the new app files will be picked up
automatically.

### Changing the install location

In `inno/DILA_v6_Setup.iss`, change:

```
DefaultDirName={localappdata}\DILA
```

e.g. to `{userpf}\DILA` for a Program Files install (note: this will
require admin rights — the HTA deliberately avoided this).

### Adding a custom theme

In `inno/DILA_v6_Setup.iss`, edit the `ThemeNames` array in the `[Code]`
section:

```pascal
ThemeNames: array[0..N-1] of string = (
  'Dark Neon', 'Cyberpunk', 'Ocean', 'Sunset', 'Forest', 'Minimal Peace', 'Your Theme'
);
```

The theme name is passed verbatim into `data.json` — DILA reads it from
there at startup.

---

## 6. Reproducing the build from scratch

If you've lost this package and only have the original HTA:

```bash
# 1. Extract the embedded app files from the HTA
python3 scripts/extract_payload.py

# 2. Regenerate the icon set from the inline SVG in the HTA
python3 scripts/make_icon.py

# 3. Regenerate the Inno Setup wizard BMPs
python3 scripts/make_wizard_bmps.py

# 4. Build the AppImage
cd build/appimage && ./build_appimage.sh

# 5. Build the Windows installer (on a Windows machine with Inno Setup 6)
cd build/inno && iscc DILA_v6_Setup.iss
```

The three Python scripts in `scripts/` are self-contained and
reproducible — they read the SVG logo and base64 payloads directly out of
the original HTA file, so the visual identity is preserved exactly.
