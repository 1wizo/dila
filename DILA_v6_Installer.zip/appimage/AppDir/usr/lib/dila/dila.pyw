#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DILA v5.0.0 - Streak tracker + notes app
Single-file tkinter app. No external UI dependencies.
"""

import os, sys, json, uuid, random, threading, time, datetime as dt, re, math
from pathlib import Path
from io import BytesIO

import tkinter as tk
from tkinter import ttk, messagebox, colorchooser, filedialog, simpledialog, font as tkfont

# Optional deps (all installed by the installer)
try:
    import pyttsx3; HAS_TTS = True
except ImportError: HAS_TTS = False
try:
    from PIL import Image, ImageDraw, ImageTk, ImageGrab; HAS_PIL = True
except ImportError: HAS_PIL = False
try:
    import pystray; HAS_TRAY = True
except ImportError: HAS_TRAY = False
try:
    import winreg; HAS_WINREG = True
except ImportError: HAS_WINREG = False
try:
    import winsound; HAS_SOUND = True
except ImportError: HAS_SOUND = False
try:
    import win11toast; HAS_TOAST = True
except ImportError: HAS_TOAST = False

APP_NAME = "DILA"
APP_VERSION = "5.12"
APP_DIR = Path(os.environ.get("APPDATA", Path.home())) / "DILA"
DATA_FILE = APP_DIR / "data.json"
APP_DIR.mkdir(parents=True, exist_ok=True)

WEEKDAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
NEON = ["#FF3B6B","#FF6B3B","#FFB347","#FFE03B","#A8FF3B","#3BFFB1","#3BD4FF","#3B6BFF",
        "#7C5CFF","#C53BFF","#FF3BC4","#FF3B3B","#3BFF8E","#00E5FF","#FFD600","#FF4081"]

WHOLESALE = [
    "You've got this! One small step today, giant leap for your streak.",
    "Future you is cheering. Past you is proud. Present you: time to shine.",
    "Every champion was once a beginner who refused to give up.",
    "Consistency is the secret sauce. You're cooking something great.",
    "Tiny daily wins become life-changing habits. Let's go!",
    "The streak believes in you. Believe in the streak.",
    "Showing up is 80% of success. Now do the thing.",
    "Your future self will high-five you for today. Don't disappoint them.",
    "Progress, not perfection. Just one rep. One page. Go.",
    "The river cuts the rock not through force, but persistence.",
    "Discipline is choosing what you want most over what you want now.",
    "Breathe. Focus. Execute. You were built for this.",
]
SAVAGE = [
    "Your streak is on life support. It's asking for you.",
    "I've seen houseplants with more discipline. Water yourself.",
    "The streak gremlins are watching. They're disappointed.",
    "Your streak called. It's crying.",
    "Even Monday has more momentum than you right now. Fix that.",
    "Procrastination called - you're its best customer. Prove it wrong.",
    "The universe doesn't care about your excuses. Do it.",
    "If excuses were reps, you'd be swole. Do the actual thing.",
    "Future you called: 'please, I'm begging you, just do it today.'",
    "Netflix called. It said 'go do your streak first.'",
    "DILA doesn't beg. DILA demands. Get up. Now.",
    "Lazy? That's just a word cowards use. You're not a coward.",
]

THEMES = {
    "Dark Neon": {"bg":"#0E0E14","panel":"#161620","card":"#1E1E2A","hover":"#262636","fg":"#EAEAF0","muted":"#8B8B9A","dim":"#555567","accent":"#7C5CFF","success":"#3FE0A1","danger":"#FF3B6B","warn":"#FFB347","border":"#2A2A3A","font":"Segoe UI"},
    "Minimal Peace": {"bg":"#FAFAF7","panel":"#F0EFEA","card":"#FFFFFF","hover":"#E8E7E2","fg":"#3A3A3A","muted":"#7A7A7A","dim":"#AAAAAA","accent":"#8B7355","success":"#7BA05B","danger":"#C97D5D","warn":"#D4A574","border":"#E0DFDA","font":"Segoe UI"},
    "Gym Bro": {"bg":"#0A0A0A","panel":"#1A0A0A","card":"#2A1010","hover":"#3A1515","fg":"#FF4444","muted":"#AA3333","dim":"#662222","accent":"#FF0000","success":"#FF6600","danger":"#FF0000","warn":"#FFAA00","border":"#440000","font":"Impact"},
    "Cyberpunk": {"bg":"#0D0221","panel":"#190B3E","card":"#2A1454","hover":"#3A1B6E","fg":"#00FFFF","muted":"#FF00FF","dim":"#7A4D8E","accent":"#FF00FF","success":"#00FF88","danger":"#FF0044","warn":"#FFAA00","border":"#4D2670","font":"Consolas"},
    "Ocean": {"bg":"#001220","panel":"#002030","card":"#003547","hover":"#004A63","fg":"#E0F7FA","muted":"#80DEEA","dim":"#4DD0E1","accent":"#00BCD4","success":"#26A69A","danger":"#EF5350","warn":"#FFA726","border":"#006978","font":"Segoe UI"},
    "Sunset": {"bg":"#2D1B2E","panel":"#4A2545","card":"#6B3556","hover":"#8B4A6B","fg":"#FFE5B4","muted":"#FFB088","dim":"#CC7755","accent":"#FF6B6B","success":"#FFB347","danger":"#FF3B6B","warn":"#FFD600","border":"#5A2A4A","font":"Segoe UI"},
    "Forest": {"bg":"#1B2D1B","panel":"#2A3F2A","card":"#3A523A","hover":"#4A664A","fg":"#E8F5E8","muted":"#A5D6A5","dim":"#66BB66","accent":"#66BB6A","success":"#81C784","danger":"#E57373","warn":"#FFB74D","border":"#388E3C","font":"Segoe UI"},
    "Paper": {"bg":"#F5F0E8","panel":"#EDE5D8","card":"#FFFFFF","hover":"#E0D5C0","fg":"#2C2C2C","muted":"#6B6B6B","dim":"#999999","accent":"#5C6BC0","success":"#66BB6A","danger":"#EF5350","warn":"#FFA726","border":"#D0C8B8","font":"Georgia"},
}


# ============================================================
# DATA
# ============================================================

class Data:
    def __init__(self):
        self.streaks = []
        self.notes = []
        self.settings = {
            "min_tray": True, "autostart": False, "sound": "", "eod_time": "22:00", "eod_done": "",
            "name": "", "color": "", "logo": "", "theme": "Dark Neon", "font_size": 0, "font_family": "",
            "best_ever_pts": 0, "best_ever_date": "", "longest_ever": 0, "longest_ever_name": "",
            "rage_questions": ["What did you just do?", "How do you feel about it?"],
            "notebooks": [],  # list of {"id","name","tags"}
            "day_comments": {},  # iso_date -> comment text
            "time_tags": [],  # list of {id, start, duration, tags}
            "phrases_w": list(WHOLESALE), "phrases_s": list(SAVAGE), "eod_openers": ["Here's how today went:","Today's tally:","Daily debrief:","Your day by numbers:","Drumroll... today:"],
        }
        self.load()

    def load(self):
        if DATA_FILE.exists():
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    d = json.load(f)
                self.streaks = d.get("streaks", [])
                self.notes = d.get("notes", [])
                for k, v in d.get("settings", {}).items():
                    self.settings[k] = v
                # Ensure best_ever keys exist for old data
                self.settings.setdefault("best_ever_pts", 0)
                self.settings.setdefault("best_ever_date", "")
                self.settings.setdefault("longest_ever", 0)
                self.settings.setdefault("longest_ever_name", "")
                self.settings.setdefault("font_family", "")
                self.settings.setdefault("rage_questions", ["What did you just do?", "How do you feel about it?"])
                self.settings.setdefault("notebooks", [])
                for s in self.streaks:
                    h = s.get("history", {})
                    if isinstance(h, list):
                        s["history"] = {x: "12:00" for x in h}
                    elif not isinstance(h, dict):
                        s["history"] = {}
            except Exception as e:
                print(f"Load error: {e}")
                # v5.9.9 FIX: back up corrupt file so user can recover
                try:
                    import shutil
                    backup = DATA_FILE.with_suffix(".corrupt")
                    shutil.copy2(str(DATA_FILE), str(backup))
                    print(f"Corrupt data backed up to {backup}")
                except: pass

    def save(self):
        # v5.9.9 FIX: atomic save — write to .tmp then rename, prevents corruption
        try:
            tmp = DATA_FILE.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"streaks": self.streaks, "notes": self.notes, "settings": self.settings},
                          f, indent=2, ensure_ascii=False)
            import os as _os
            _os.replace(str(tmp), str(DATA_FILE))  # atomic on Windows + POSIX
        except Exception as e:
            print(f"Save error: {e}")

    # Streaks
    def add_streak(self, s):
        s["id"] = str(uuid.uuid4())
        s["created"] = dt.datetime.now().isoformat()
        s["history"] = {}
        s["last_notified"] = ""
        self.streaks.append(s)
        self.save()

    def update_streak(self, sid, u):
        for s in self.streaks:
            if s["id"] == sid:
                s.update(u); self.save(); return s
        return None

    def delete_streak(self, sid):
        self.streaks = [s for s in self.streaks if s["id"] != sid]
        self.save()

    def mark_done(self, sid, date=None):
        if date is None: date = dt.date.today().isoformat()
        t = dt.datetime.now().strftime("%H:%M")
        for s in self.streaks:
            if s["id"] == sid:
                if not isinstance(s.get("history"), dict): s["history"] = {}
                if s.get("type", "once") in ("multi", "infinite"):
                    if date not in s["history"] or not isinstance(s["history"][date], list):
                        s["history"][date] = []
                    s["history"][date].append(t)
                else:
                    s["history"][date] = t
                self.save()
                self._update_best_ever()
                return True
        return False

    def unmark(self, sid, date):
        for s in self.streaks:
            if s["id"] == sid and isinstance(s.get("history"), dict) and date in s["history"]:
                del s["history"][date]; self.save(); return True
        return False

    def count_done(self, sid, date=None):
        """Return (count, target) for a streak on a given date. For 'once' type, count is 0/1 and target is 1."""
        if date is None: date = dt.date.today().isoformat()
        s = self.get_streak(sid)
        if not s: return (0, 0)
        try:
            d_obj = pd(date)
            if not streak_existed_on(s, d_obj): return (0, 0)
        except: pass
        h = s.get("history", {})
        if not isinstance(h, dict): return (0, 0)
        stype = s.get("type", "once")
        if stype == "multi":
            target = max(1, int(s.get("target", 1)))
            v = h.get(date, [])
            count = len(v) if isinstance(v, list) else (1 if v else 0)
            return (min(count, target), target)
        elif stype == "infinite":
            v = h.get(date, [])
            count = len(v) if isinstance(v, list) else (1 if v else 0)
            return (count, 0)
        else:
            return (1 if date in h else 0, 1)

    def historical_max_points(self):
        """Scan all history dates and return the max daily points ever achieved (across all streaks)."""
        max_pts = 0
        for s in self.streaks:
            w = max(1, int(s.get("weight", 1)))
            h = s.get("history", {})
            if not isinstance(h, dict): continue
            stype = s.get("type", "once")
            if stype == "multi":
                target = max(1, int(s.get("target", 1)))
                max_pts += w * target
            elif stype == "infinite":
                best_c = 0
                for dv, vv in h.items():
                    c = len(vv) if isinstance(vv, list) else (1 if vv else 0)
                    if c > best_c: best_c = c
                max_pts += w * max(best_c, 1)
            else:
                max_pts += w
        return max(max_pts, self.settings.get("best_ever_pts", 0), 1)

    def _update_best_ever(self):
        """Track best-ever day (points) and longest-ever streak. Persists when streaks are deleted."""
        try:
            today = dt.date.today().isoformat()
            e, _ = self.daily_points(today)
            if e > self.settings.get("best_ever_pts", 0):
                self.settings["best_ever_pts"] = e
                self.settings["best_ever_date"] = today
            # Longest ever across current streaks (don't shrink — only grow)
            cur_longest = self.settings.get("longest_ever", 0)
            cur_name = self.settings.get("longest_ever_name", "")
            for s in self.streaks:
                l = longest_streak(s)
                if l > cur_longest:
                    cur_longest = l
                    cur_name = s.get("name", "?")
            self.settings["longest_ever"] = cur_longest
            self.settings["longest_ever_name"] = cur_name
            self.save()
        except Exception as ex:
            print(f"best_ever update error: {ex}")

    def get_streak(self, sid):
        for s in self.streaks:
            if s["id"] == sid: return s
        return None

    def daily_points(self, date=None):
        if date is None: date = dt.date.today().isoformat()
        earned = total = 0
        try: d_obj = pd(date)
        except: d_obj = dt.date.today()
        for s in self.streaks:
            if not streak_existed_on(s, d_obj): continue
            # v5.9.8: skip tasks not due on this date — weekly/custom tasks
            # not due today were inflating the total and making the % wrong.
            if not is_due(s, d_obj): continue
            w = max(1, int(s.get("weight", 1)))
            stype = s.get("type", "once")
            h = s.get("history", {})
            if stype == "multi":
                target = max(1, int(s.get("target", 1)))
                total += w * target
                if isinstance(h, dict) and date in h:
                    v = h[date]
                    c = len(v) if isinstance(v, list) else (1 if v else 0)
                    earned += min(c, target) * w
            elif stype == "infinite":
                if isinstance(h, dict) and date in h:
                    v = h[date]
                    c = len(v) if isinstance(v, list) else (1 if v else 0)
                    earned += c * w
            else:
                total += w
                if isinstance(h, dict) and date in h:
                    earned += w
        return earned, total

    def series(self, days=30):
        today = dt.date.today()
        r = []
        for i in range(days - 1, -1, -1):
            d = today - dt.timedelta(days=i)
            iso = d.isoformat()
            e, t = self.daily_points(iso)
            r.append((iso, e, t))
        return r

    def laziest(self):
        today = dt.date.today()
        start = today - dt.timedelta(days=364)
        worst_d = None; worst_p = 999999
        cur = start
        while cur <= today:
            iso = cur.isoformat()
            e, t = self.daily_points(iso)
            if t > 0 and e < worst_p:
                worst_p = e; worst_d = iso
            cur += dt.timedelta(days=1)
        return worst_d, worst_p

    # Notes
    def add_note(self, title="Untitled", content="", notebook_id=None, tags=""):
        n = {"id": str(uuid.uuid4()), "title": title, "content": content,
             "notebook_id": notebook_id, "tags": tags,
             "splits": [],  # list of {"id","name","content","bg_color"}
             "created": dt.datetime.now().isoformat(), "modified": dt.datetime.now().isoformat()}
        self.notes.append(n); self.save(); return n

    def update_note(self, nid, title=None, content=None, tags=None):
        for n in self.notes:
            if n["id"] == nid:
                if title is not None: n["title"] = title
                if content is not None: n["content"] = content
                if tags is not None: n["tags"] = tags
                n["modified"] = dt.datetime.now().isoformat()
                self.save(); return n
        return None

    def delete_note(self, nid):
        self.notes = [n for n in self.notes if n["id"] != nid]
        self.save()

    def get_note(self, nid):
        for n in self.notes:
            if n["id"] == nid: return n
        return None

    def get_note_by_title(self, title):
        for n in self.notes:
            if n["title"].lower() == title.lower(): return n
        return None

    def backlinks(self, title):
        r = []
        pat = re.compile(r'\[\[' + re.escape(title) + r'\]\]', re.IGNORECASE)
        for n in self.notes:
            if pat.search(n.get("content", "")): r.append(n)
        return r

    # Splits (sub-sections of a note)
    def add_split(self, nid, name, content="", bg_color=""):
        n = self.get_note(nid)
        if not n: return None
        if not isinstance(n.get("splits"), list): n["splits"] = []
        sp = {"id": str(uuid.uuid4()), "name": name, "content": content, "bg_color": bg_color}
        n["splits"].append(sp)
        n["modified"] = dt.datetime.now().isoformat()
        self.save(); return sp

    def update_split(self, nid, sid, name=None, content=None, bg_color=None):
        n = self.get_note(nid)
        if not n: return False
        for sp in n.get("splits", []):
            if sp["id"] == sid:
                if name is not None: sp["name"] = name
                if content is not None: sp["content"] = content
                if bg_color is not None: sp["bg_color"] = bg_color
                self.save(); return True
        return False

    def delete_split(self, nid, sid):
        n = self.get_note(nid)
        if not n: return
        n["splits"] = [s for s in n.get("splits", []) if s["id"] != sid]
        self.save()

    # Notebooks
    def add_notebook(self, name, tags=""):
        nb = {"id": str(uuid.uuid4()), "name": name, "tags": tags}
        # Store notebooks in settings (simple approach)
        if not isinstance(self.settings.get("notebooks"), list):
            self.settings["notebooks"] = []
        self.settings["notebooks"].append(nb)
        self.save(); return nb

    def delete_notebook(self, nbid):
        nbs = self.settings.get("notebooks", [])
        self.settings["notebooks"] = [nb for nb in nbs if nb["id"] != nbid]
        # Unassign notes from this notebook
        for n in self.notes:
            if n.get("notebook_id") == nbid:
                n["notebook_id"] = None
        self.save()

    def get_notebooks(self):
        return self.settings.get("notebooks", [])

    def get_notebook(self, nbid):
        for nb in self.get_notebooks():
            if nb["id"] == nbid: return nb
        return None


# ============================================================
# STREAK MATH
# ============================================================

def pd(s): return dt.date.fromisoformat(s)

def is_due(s, today=None):
    if today is None: today = dt.date.today()
    sc = s.get("schedule", {"type":"daily"})
    t = sc.get("type","daily")
    if t == "daily": return True
    if t == "weekly": return today.weekday() == sc.get("day", 0)
    if t == "custom":
        iv = max(1, int(sc.get("interval", 1)))
        st = pd(sc.get("start", today.isoformat()))
        if today < st: return False
        return (today - st).days % iv == 0
    return True

def hist_dates(s):
    h = s.get("history", {})
    if isinstance(h, dict): return set(h.keys())
    if isinstance(h, list): return set(h)
    return set()

def current_streak(s, today=None):
    if today is None: today = dt.date.today()
    h = hist_dates(s)
    forg = max(0, int(s.get("forgiveness", 0)))
    c = 0; skips = 0; cur = today
    if is_due(s, today) and today.isoformat() not in h:
        cur = today - dt.timedelta(days=1)
    for _ in range(3650):
        if is_due(s, cur):
            if cur.isoformat() in h: c += 1
            else:
                if skips < forg: skips += 1
                else: break
        cur -= dt.timedelta(days=1)
        if cur.year < 2000: break
    return c

def streak_existed_on(s, date):
    """Check if a streak was created on or before the given date."""
    created = s.get("created", "")
    if not created: return True
    try:
        return date >= dt.datetime.fromisoformat(created).date()
    except:
        return True


def longest_streak(s):
    h = sorted(hist_dates(s))
    if not h: return 0
    longest = cur = 0; prev = None
    for d in h:
        dt_ = pd(d)
        if not is_due(s, dt_): continue
        if prev is None: cur = 1
        else:
            step = prev + dt.timedelta(days=1); found = None
            for _ in range(4000):
                if step > dt_: break
                if is_due(s, step): found = step; break
                step += dt.timedelta(days=1)
            cur = cur + 1 if found == dt_ else 1
        if cur > longest: longest = cur
        prev = dt_
    return longest


# ============================================================
# THEME
# ============================================================

class Theme:
    def __init__(self, data):
        self.d = data
        self.apply()

    def apply(self):
        t = THEMES.get(self.d.settings.get("theme", "Dark Neon"), THEMES["Dark Neon"])
        for k, v in t.items():
            setattr(self, k, v)
        if self.d.settings.get("color"):
            self.accent = self.d.settings["color"]
        if self.d.settings.get("font_size", 0) > 0:
            self.fsize = self.d.settings["font_size"]
        else:
            self.fsize = 10
        # Font family override (blank = theme default)
        ff = self.d.settings.get("font_family", "").strip()
        if ff:
            self.font = ff

    def refresh(self): self.apply()

    def f(self, delta=0, bold=False):
        return (self.font, self.fsize + delta, "bold" if bold else "normal")


# ============================================================
# LOGO
# ============================================================

# --- color + gradient helpers (pure PIL, no numpy needed) ---
def _hex_to_rgb(h):
    h = h.lstrip("#")
    return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16))

def _lerp_color(c1, c2, t):
    r1,g1,b1 = _hex_to_rgb(c1); r2,g2,b2 = _hex_to_rgb(c2)
    return (int(r1+(r2-r1)*t), int(g1+(g2-g1)*t), int(b1+(b2-b1)*t))

def _stops_color(stops, r):
    r = max(0.0, min(1.0, r))
    for i in range(len(stops)-1):
        p0,c0 = stops[i]; p1,c1 = stops[i+1]
        if p0 <= r <= p1:
            t = (r-p0)/max(0.001, p1-p0)
            return _lerp_color(c0, c1, t)
    return _hex_to_rgb(stops[-1][1])

def _diagonal_gradient(size, stops):
    """Diagonal (top-left -> bottom-right) gradient. stops: [(pos, hex),...]."""
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            r = (x + y) / (2 * max(1, size-1))
            px[x,y] = _stops_color(stops, r) + (255,)
    return img

def _vertical_gradient(size, stops):
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        r = y / max(1, size-1)
        col = _stops_color(stops, r) + (255,)
        for x in range(size):
            px[x,y] = col
    return img

def _cubic_bezier_pts(p0, p1, p2, p3, n=24):
    pts = []
    for i in range(n+1):
        t = i / n
        mt = 1-t
        x = mt**3*p0[0] + 3*mt**2*t*p1[0] + 3*mt*t**2*p2[0] + t**3*p3[0]
        y = mt**3*p0[1] + 3*mt**2*t*p1[1] + 3*mt*t**2*p2[1] + t**3*p3[1]
        pts.append((x, y))
    return pts

def make_logo(size=64, accent="#7C5CFF"):
    """Draw the DILA neon logo: gradient rounded square + flame + checkmark.
    Matches the installer's SVG design exactly."""
    if not HAS_PIL: return None
    s = size
    img = Image.new("RGBA", (s, s), (0,0,0,0))
    m = int(s * 0.06)
    # --- gradient rounded square background (violet -> fuchsia -> emerald) ---
    grad = _diagonal_gradient(s, [(0.0, "#7C5CFF"), (0.5, "#A78BFA"), (1.0, "#3BE0A1")])
    mask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(mask).rounded_rectangle([m, m, s-m, s-m], radius=int(s*0.22), fill=255)
    img.paste(grad, (0,0), mask)
    # --- flame / streak shape (4 cubic beziers, same path as the installer SVG) ---
    fp  = _cubic_bezier_pts((s*0.50,s*0.22),(s*0.58,s*0.36),(s*0.68,s*0.40),(s*0.64,s*0.56))
    fp += _cubic_bezier_pts((s*0.64,s*0.56),(s*0.78,s*0.50),(s*0.74,s*0.70),(s*0.50,s*0.78))
    fp += _cubic_bezier_pts((s*0.50,s*0.78),(s*0.26,s*0.70),(s*0.22,s*0.50),(s*0.36,s*0.56))
    fp += _cubic_bezier_pts((s*0.36,s*0.56),(s*0.32,s*0.40),(s*0.42,s*0.36),(s*0.50,s*0.22))
    fgrad = _vertical_gradient(s, [(0.0, "#3BE0A1"), (1.0, accent)])
    fmask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(fmask).polygon(fp, fill=255)
    img.paste(fgrad, (0,0), fmask)
    # --- dark checkmark on top ---
    d = ImageDraw.Draw(img)
    cw = max(3, int(round(s * 0.045)))
    d.line([(int(s*0.40), int(s*0.54)), (int(s*0.47), int(s*0.61))], fill="#0E0E14", width=cw, joint="curve")
    d.line([(int(s*0.47), int(s*0.61)), (int(s*0.62), int(s*0.42))], fill="#0E0E14", width=cw, joint="curve")
    return img

def get_logo(data, size=64, theme=None):
    accent = theme.accent if theme else "#7C5CFF"
    custom = data.settings.get("logo", "")
    if custom and os.path.exists(custom) and HAS_PIL:
        try:
            c = Image.open(custom).convert("RGBA").resize((size, size), Image.LANCZOS)
            off = make_logo(int(size*0.3), accent)
            if off: c.alpha_composite(off, (size - off.width - 2, size - off.height - 2))
            return c
        except: pass
    return make_logo(size, accent)

def get_name(data):
    n = data.settings.get("name", "").strip()
    return f"{n}-DILA" if n else APP_NAME


# ============================================================
# SCROLL FRAME
# ============================================================

class ScrollFrame(tk.Frame):
    def __init__(self, parent, t, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.t = t
        self.canvas = tk.Canvas(self, bg=t.bg, highlightthickness=0)
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.sb.set)
        self.sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=t.bg)
        self.iw = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfig(self.iw, width=e.width))
        self.canvas.bind("<MouseWheel>", lambda e: self.canvas.yview_scroll(-1*(e.delta//120), "units"))
        self.inner.bind("<MouseWheel>", lambda e: self.canvas.yview_scroll(-1*(e.delta//120), "units"))
        # Touchpad / Linux scroll buttons (Button-4/5 are X11-only, safe to skip on Windows)
        try:
            self.canvas.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
            self.canvas.bind("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))
            self.inner.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
            self.inner.bind("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))
        except: pass
        # Middle mouse button drag to scroll
        self._mid_scroll = None
        self.canvas.bind("<Button-2>", self._sf_mid_down)
        self.inner.bind("<Button-2>", self._sf_mid_down)
        self.canvas.bind("<B2-Motion>", self._sf_mid_drag)
        self.inner.bind("<B2-Motion>", self._sf_mid_drag)
        self.canvas.bind("<ButtonRelease-2>", lambda e: setattr(self, "_mid_scroll", None))
        self.inner.bind("<ButtonRelease-2>", lambda e: setattr(self, "_mid_scroll", None))
        self.inner.bind("<Enter>", lambda e: self._bind())
        self.inner.bind("<Leave>", lambda e: self._unbind())

    def _sf_mid_down(self, e):
        self._mid_scroll = e.y_root

    def _sf_mid_drag(self, e):
        if not self._mid_scroll: return
        dy = e.y_root - self._mid_scroll
        self.canvas.yview_scroll(int(-dy / 10), "units")
        self._mid_scroll = e.y_root

    def _bind(self):
        self.bind_all("<Up>", lambda e: self.canvas.yview_scroll(-1, "units"))
        self.bind_all("<Down>", lambda e: self.canvas.yview_scroll(1, "units"))
        self.bind_all("<Prior>", lambda e: self.canvas.yview_scroll(-3, "units"))
        self.bind_all("<Next>", lambda e: self.canvas.yview_scroll(3, "units"))

    def _unbind(self):
        for k in ("<Up>", "<Down>", "<Prior>", "<Next>"):
            try: self.unbind_all(k)
            except: pass


def valid_time(s):
    try:
        h, m = s.split(":"); return 0 <= int(h) <= 23 and 0 <= int(m) <= 59
    except: return False

def blend(c1, c2, r):
    c1 = c1.lstrip("#"); c2 = c2.lstrip("#")
    r1, g1, b1 = int(c1[0:2],16), int(c1[2:4],16), int(c1[4:6],16)
    r2, g2, b2 = int(c2[0:2],16), int(c2[2:4],16), int(c2[4:6],16)
    return f"#{int(r1+(r2-r1)*r):02X}{int(g1+(g2-g1)*r):02X}{int(b1+(b2-b1)*r):02X}"


# ============================================================
# NOTIFICATIONS
# ============================================================

class Notifier:
    def __init__(self, data):
        self.d = data
        self.tts = None
        self.tts_lock = threading.Lock()
        self.app = None  # ref to MainApp for scheduling popups on main thread
        if HAS_TTS:
            try:
                self.tts = pyttsx3.init()
                self.tts.setProperty("rate", 150)
            except: self.tts = None
        if HAS_TOAST:
            try: win11toast.set_app_id(APP_NAME)
            except: pass
        self._active_rage = {}  # sid -> rage dialog ref (prevent duplicates)

    def phrase(self, s, aggressive=False):
        tone = s.get("tone", "mixed")
        pool = [p for p in s.get("phrases", []) if p.strip()]
        if aggressive:
            # Aggressive/rage mode: use savage phrases only, add urgency
            pool = list(self.d.settings.get("phrases_s", SAVAGE)) + [
                "STOP. WHATEVER YOU'RE DOING. DO YOUR STREAK NOW.",
                "This is not a drill. Your streak is dying. DO IT.",
                "I WILL NOT STOP UNTIL YOU DO THIS. DO IT NOW.",
                "NO EXCUSES. NO DELAYS. DO IT. DO IT. DO IT.",
            ]
        else:
            if tone in ("wholesome", "mixed"):
                pool.extend(self.d.settings.get("phrases_w", WHOLESALE))
            if tone in ("savage", "mixed"):
                pool.extend(self.d.settings.get("phrases_s", SAVAGE))
        return random.choice(pool) if pool else "Time for your streak!"

    def notify(self, s):
        intensity = s.get("intensity", "normal")
        modes = s.get("modes", ["sound","toast","popup"])
        ph = self.phrase(s, aggressive=(intensity in ("aggressive","rage")))
        name = s.get("name", "Streak")
        title = f"{name} - Day {current_streak(s) + 1}"
        snooze = max(1, int(s.get("snooze", 5)))  # minutes

        if intensity == "cute":
            # Just a toast, no repeat
            if HAS_TOAST:
                threading.Thread(target=self._toast, args=(title, ph, s), daemon=True).start()
        elif intensity == "normal":
            # Toast + popup, repeats after snooze minutes if not done
            if "sound" in modes and HAS_SOUND:
                threading.Thread(target=self._sound, daemon=True).start()
            if HAS_TOAST:
                threading.Thread(target=self._toast, args=(title, ph, s), daemon=True).start()
            if "popup" in modes:
                self._popup_main(title, ph, s, snooze=snooze)
        elif intensity == "aggressive":
            # TTS speaks even when app is in tray, repeats with savage phrases
            if "sound" in modes and HAS_SOUND:
                threading.Thread(target=self._sound, daemon=True).start()
            if self.tts:
                threading.Thread(target=self._speak, args=(ph,), daemon=True).start()
            if HAS_TOAST:
                threading.Thread(target=self._toast, args=(title, ph, s), daemon=True).start()
            self._popup_main(title, ph, s, snooze=snooze, aggressive=True)
        elif intensity == "rage":
            # Max volume, persistent ringing, must answer questions
            if "sound" in modes and HAS_SOUND:
                threading.Thread(target=self._rage_sound, daemon=True).start()
            if self.tts:
                threading.Thread(target=self._speak, args=(ph,), daemon=True).start()
            if HAS_TOAST:
                threading.Thread(target=self._toast, args=(title, ph, s), daemon=True).start()
            self._rage_popup(title, ph, s, snooze=snooze)
        else:
            # Fallback: old behavior
            if "sound" in modes and HAS_SOUND:
                threading.Thread(target=self._sound, daemon=True).start()
            if "tts" in modes and self.tts:
                threading.Thread(target=self._speak, args=(ph,), daemon=True).start()
            if "toast" in modes and HAS_TOAST:
                threading.Thread(target=self._toast, args=(title, ph, s), daemon=True).start()
            if "popup" in modes:
                self._popup_main(title, ph, s, snooze=snooze)

    def test(self):
        s = {"id":"test","name":"TEST","color":"#7C5CFF","tone":"mixed","phrases":[],"modes":["sound","tts","toast","popup"],"intensity":"normal","snooze":5}
        self.notify(s)

    def _toast(self, title, body, s=None):
        if not HAS_TOAST: return
        try:
            icon = self.d.settings.get("logo", "") if self.d else ""
            if not icon or not os.path.exists(icon): icon = ""
            win11toast.notify(
                title=title or APP_NAME,
                body=body,
                icon=icon,
                app_id=APP_NAME,
                duration="short",
            )
        except Exception as e:
            print(f"Toast error: {e}")

    def _sound(self):
        try:
            p = self.d.settings.get("sound", "")
            if p and os.path.exists(p):
                winsound.PlaySound(p, winsound.SND_FILENAME | winsound.SND_ASYNC)
            else:
                for _ in range(3):
                    winsound.Beep(880, 250); time.sleep(0.05)
        except: pass

    def _speak(self, text):
        with self.tts_lock:
            try: self.tts.say(text); self.tts.runAndWait()
            except: pass

    def _rage_sound(self):
        """Persistent loud beeping for rage mode."""
        try:
            for _ in range(50):  # ~25 seconds of loud beeping
                winsound.Beep(1000, 200); time.sleep(0.05)
                winsound.Beep(1200, 200); time.sleep(0.05)
        except: pass

    def _popup_main(self, title, body, s, snooze=5, aggressive=False):
        """Schedule popup on main thread to avoid Tk-in-thread issues."""
        if self.app:
            self.app.after(0, lambda: self._popup(title, body, s, snooze, aggressive))
        else:
            threading.Thread(target=self._popup, args=(title, body, s, snooze, aggressive), daemon=True).start()

    def _popup(self, title, body, s, snooze=5, aggressive=False):
        # v5.9.7: Release any existing grab (e.g. SettingsDialog.grab_set) so the
        # popup's buttons are actually clickable. Previously you had to close
        # Settings before the popup would accept clicks.
        current_grab = None
        if self.app:
            try: current_grab = self.app.grab_current()
            except: current_grab = None
            if current_grab:
                try: current_grab.grab_release()
                except: pass
        r = tk.Toplevel(); r.title(title); r.attributes("-topmost", True)
        r.configure(bg="#1E1E2A"); r.resizable(False, False)  # v5.9.9: fixed size
        sw, sh = r.winfo_screenwidth(), r.winfo_screenheight()
        w, h = 460, 320
        r.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        color = s.get("color", "#7C5CFF")
        if aggressive:
            color = "#FF0000"; r.configure(bg="#1A0000")
        tk.Frame(r, bg=color, height=8).pack(fill="x")
        tk.Label(r, text=title, bg=r["bg"], fg=color, font=("Segoe UI",16,"bold"),
                 wraplength=420, justify="center").pack(pady=(20,8))
        tk.Label(r, text=body, bg=r["bg"], fg="#EAEAF0", font=("Segoe UI",11),
                 wraplength=420, justify="center").pack(pady=4, padx=16)
        def _restore_grab():
            if current_grab and current_grab.winfo_exists():
                try: current_grab.grab_set()
                except: pass
        def done():
            if s.get("id") and s["id"] != "test":
                self.d.mark_done(s["id"])
            r.destroy()
            _restore_grab()
            # v5.9.7: refresh TODAY score immediately
            if self.app and hasattr(self.app, "_update_score"):
                try: self.app.after(0, self.app._update_score)
                except: pass
        def later():
            r.destroy()
            _restore_grab()
            # Schedule a re-notify after snooze minutes
            sid = s.get("id", "")
            if sid and sid != "test":
                threading.Timer(snooze * 60, lambda: self._renotify(s)).start()
        bf = tk.Frame(r, bg=r["bg"]); bf.pack(pady=18)
        tk.Button(bf, text="I DID IT", bg=color, fg="#0E0E14", font=("Segoe UI",12,"bold"),
                  relief="flat", cursor="hand2", padx=24, pady=10, command=done).pack(side="left", padx=8)
        tk.Button(bf, text=f"Later ({snooze}min)", bg=r["bg"], fg="#8B8B9A", font=("Segoe UI",11),
                  relief="flat", cursor="hand2", padx=20, pady=10, command=later).pack(side="left", padx=8)
        r.protocol("WM_DELETE_WINDOW", later)  # X button = snooze
        try: r.grab_set()
        except: pass
        # v5.9.9 FIX: use wait_window instead of mainloop (avoids re-entrant event loops)
        self.app.wait_window(r) if self.app else r.wait_window()

    def _renotify(self, s):
        """Re-notify a streak after snooze (called by Timer thread)."""
        # v5.9.9 FIX: don't re-notify if the streak was deleted
        if not self.d.get_streak(s.get("id", "")): return
        today = dt.date.today().isoformat()
        if today in hist_dates(s): return  # already done
        self.notify(s)

    def _rage_popup(self, title, body, s, snooze=5):
        """Rage mode popup: must answer questions to dismiss. Shuts down PC after 5 min of inactivity."""
        sid = s.get("id", "")
        if sid in self._active_rage: return  # already showing
        if self.app:
            self.app.after(0, lambda: self._rage_dialog(title, body, s, snooze))
        else:
            threading.Thread(target=self._rage_dialog, args=(title, body, s, snooze), daemon=True).start()

    def _rage_dialog(self, title, body, s, snooze=5):
        sid = s.get("id", "")
        # v5.9.7: release any active grab so this dialog is clickable.
        current_grab = None
        if self.app:
            try: current_grab = self.app.grab_current()
            except: current_grab = None
            if current_grab:
                try: current_grab.grab_release()
                except: pass
        # Use per-streak rage questions, fall back to global
        questions = s.get("rage_questions", []) or self.d.settings.get("rage_questions", ["What did you just do?", "How do you feel about it?"])
        if not questions:
            questions = ["Type 'done' to confirm you did it."]
        r = tk.Toplevel(); r.title("RAGE MODE - " + title); r.attributes("-topmost", True)
        r.configure(bg="#1A0000"); r.resizable(False, False)  # v5.9.9: fixed size
        sw, sh = r.winfo_screenwidth(), r.winfo_screenheight()
        r.geometry(f"520x480+{(sw-520)//2}+{(sh-480)//2}")
        r.overrideredirect(False)
        tk.Frame(r, bg="#FF0000", height=10).pack(fill="x")
        tk.Label(r, text="RAGE MODE", bg="#1A0000", fg="#FF0000", font=("Impact",24,"bold")).pack(pady=(16,4))
        tk.Label(r, text=title, bg="#1A0000", fg="#FFFFFF", font=("Segoe UI",14,"bold")).pack(pady=(0,8))
        tk.Label(r, text=body, bg="#1A0000", fg="#FFAAAA", font=("Segoe UI",11),
                 wraplength=460, justify="center").pack(pady=4, padx=20)
        tk.Label(r, text="Answer ALL questions to stop the alarm:", bg="#1A0000", fg="#FFD600",
                 font=("Segoe UI",10,"bold")).pack(pady=(12,4))
        entries = []
        qf = tk.Frame(r, bg="#1A0000"); qf.pack(fill="x", padx=20, pady=4)
        for i, q in enumerate(questions):
            tk.Label(qf, text=f"Q{i+1}: {q}", bg="#1A0000", fg="#FFFFFF", font=("Segoe UI",9),
                     anchor="w").pack(fill="x", pady=(4,0))
            e = tk.Entry(qf, bg="#330000", fg="#FFFFFF", insertbackground="#FFFFFF", relief="flat",
                         font=("Segoe UI",10), highlightthickness=1, highlightbackground="#FF0000")
            e.pack(fill="x", ipady=4, pady=(0,8))
            entries.append(e)
        # Countdown timer for PC shutdown
        countdown = {"remaining": 300}  # 5 minutes
        timer_label = tk.Label(r, text="", bg="#1A0000", fg="#FF0000", font=("Segoe UI",12,"bold"))
        timer_label.pack(pady=(4,8))
        def update_timer():
            # v5.9.9 FIX: check if dialog still exists before updating
            if not r.winfo_exists(): return
            if countdown["remaining"] <= 0:
                timer_label.configure(text="SHUTTING DOWN...")
                self._shutdown_pc()
                return
            mins, secs = divmod(countdown["remaining"], 60)
            timer_label.configure(text=f"PC shuts down in: {mins:02d}:{secs:02d}")
            countdown["remaining"] -= 1
            r.after(1000, update_timer)
        update_timer()
        def submit():
            answers = [e.get().strip() for e in entries]
            if any(len(a) < 2 for a in answers):
                messagebox.showerror("Incomplete", "Answer ALL questions with at least 2 characters.", parent=r)
                return
            if s.get("id") and s["id"] != "test":
                self.d.mark_done(s["id"])
            self._active_rage.pop(sid, None)
            r.destroy()
        tk.Button(r, text="I DID IT - SUBMIT ANSWERS", bg="#FF0000", fg="#FFFFFF", font=("Segoe UI",12,"bold"),
                  relief="flat", cursor="hand2", padx=32, pady=12, command=submit).pack(pady=(8,16))
        r.protocol("WM_DELETE_WINDOW", lambda: None)  # prevent closing via X
        try: r.grab_set()
        except: pass
        self._active_rage[sid] = r
        r.mainloop()
        self._active_rage.pop(sid, None)
        # v5.9.7: restore the grab that was active before the rage dialog opened
        if current_grab and current_grab.winfo_exists():
            try: current_grab.grab_set()
            except: pass

    def _shutdown_pc(self):
        """Force shutdown the PC (rage mode timeout)."""
        try:
            if os.name == "nt":
                os.system("shutdown /s /t 30 /c \"DILA RAGE MODE: You ignored your streak. PC shutting down in 30 seconds.\"")
            else:
                os.system("shutdown -h +1")
        except: pass

    def eod(self):
        today = dt.date.today().isoformat()
        e, t = self.d.daily_points(today)
        if t == 0: return
        pct = int(e * 100 / t)
        lines = [random.choice(self.d.settings.get("eod_openers", ["Today:"])), ""]
        for s in self.d.streaks:
            if not is_due(s): continue
            done = today in hist_dates(s)
            w = max(1, int(s.get("weight", 1)))
            lines.append(f"  {'OK' if done else 'X'}  {s['name']}  (+{w if done else 0}/{w} pts)")
        lines.append(f"\nTotal: {e}/{t} pts ({pct}%)")
        if pct == 100: lines.append("FLAWLESS VICTORY!")
        elif pct >= 70: lines.append("Solid day. Tomorrow: full send.")
        elif pct >= 40: lines.append("Mixed bag.")
        else: lines.append("The bed won. Try again tomorrow.")
        body = "\n".join(lines)
        if self.tts:
            threading.Thread(target=self._speak, args=(body,), daemon=True).start()
        if HAS_TOAST:
            threading.Thread(target=self._toast, args=(f"End of Day - {dt.date.today().strftime('%b %d')}", body, {"color":"#7C5CFF","id":"eod"}), daemon=True).start()
        threading.Thread(target=self._popup, args=(f"End of Day - {dt.date.today().strftime('%b %d')}", body, {"color":"#7C5CFF","id":"eod"}), daemon=True).start()


# ============================================================
# SCHEDULER
# ============================================================

class Scheduler(threading.Thread):
    def __init__(self, d, n):
        super().__init__(daemon=True)
        self.d = d; self.n = n; self.running = True; self.paused = False

    def run(self):
        while self.running:
            if self.paused: time.sleep(30); continue
            try: self._check(); self._eod()
            except Exception as e: print(f"Sched: {e}")
            for _ in range(60):
                if not self.running: return
                time.sleep(1)

    def _check(self):
        now = dt.datetime.now()
        today = dt.date.today().isoformat()
        for s in self.d.streaks:
            if not is_due(s): continue
            stype = s.get("type", "once")
            if stype == "once" and today in hist_dates(s): continue
            if stype == "multi":
                cnt, tgt = self.d.count_done(s["id"], today)
                if cnt >= tgt: continue
            times = s.get("times", [])
            if not times: continue
            last = s.get("last_notified", "")
            last_min = -1
            if last.startswith(today):
                try:
                    lh, lm = int(last[11:13]), int(last[14:16])
                    last_min = lh * 60 + lm
                except: pass
            cur_min = now.hour * 60 + now.minute
            for t_str in times:
                try:
                    th, tm = int(t_str[:2]), int(t_str[3:5])
                    cfg_min = th * 60 + tm
                except: continue
                # Fire if the configured time has arrived AND we haven't
                # already notified at/after that time today
                if cfg_min <= cur_min and cfg_min > last_min:
                    self.n.notify(s)
                    s["last_notified"] = now.isoformat()
                    self.d.save()
                    break

    def _eod(self):
        et = self.d.settings.get("eod_time", "22:00")
        today = dt.date.today().isoformat()
        if self.d.settings.get("eod_done") == today: return
        if dt.datetime.now().strftime("%H:%M") == et:
            self.n.eod()
            self.d.settings["eod_done"] = today
            self.d.save()

    def stop(self): self.running = False


# ============================================================
# AUTOSTART
# ============================================================

def set_autostart(en):
    if not HAS_WINREG: return False
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
        if en:
            winreg.SetValueEx(k, APP_NAME, 0, winreg.REG_SZ, f'"{sys.executable}" "{os.path.abspath(__file__)}"')
        else:
            try: winreg.DeleteValue(k, APP_NAME)
            except FileNotFoundError: pass
        winreg.CloseKey(k); return True
    except: return False

def is_autostart():
    if not HAS_WINREG: return False
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_READ)
        try: winreg.QueryValueEx(k, APP_NAME); winreg.CloseKey(k); return True
        except FileNotFoundError: winreg.CloseKey(k); return False
    except: return False


# ============================================================
# STREAK DIALOG
# ============================================================

class StreakDialog(tk.Toplevel):
    def __init__(self, parent, d, t, streak=None):
        super().__init__(parent)
        self.d = d; self.t = t; self.streak = streak or {}; self.result = None
        self.title("Edit Task" if streak else "New Task")
        self.configure(bg=t.bg)
        self.transient(parent); self.grab_set()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = 520, 760
        if h > sh * 0.95: h = int(sh * 0.95)
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{max(0,(sh-h)//2-20)}")
        self.resizable(False, False)  # v5.9.9: fixed size
        sf = ScrollFrame(self, t); sf.pack(fill="both", expand=True)
        self._build(sf.inner)
        if self.streak: self._load()

    def _build(self, c):
        t = self.t; c.columnconfigure(0, weight=1); r = 0
        tk.Label(c, text="TASK SETUP", bg=t.bg, fg=t.accent, font=t.f(4, True)).grid(row=r, column=0, sticky="w", pady=(18,16), padx=24); r+=1

        tk.Label(c, text="Name", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        self.name = tk.StringVar()
        tk.Entry(c, textvariable=self.name, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                 font=t.f(1), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24, ipady=6); r+=1

        tk.Label(c, text="Description", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        self.desc = tk.Text(c, height=3, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                            font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                            highlightcolor=t.accent, wrap="word")
        self.desc.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24); r+=1

        # Type
        tk.Label(c, text="Type", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        tf = tk.Frame(c, bg=t.bg); tf.grid(row=r, column=0, sticky="ew", pady=(2,4), padx=24)
        self.type = tk.StringVar(value="once")
        tk.Radiobutton(tf, text="Once per day", variable=self.type, value="once", bg=t.bg, fg=t.fg,
                       selectcolor=t.card, activebackground=t.bg, activeforeground=t.fg, font=t.f(0),
                       command=self._on_type).pack(side="left", padx=(0,16))
        tk.Radiobutton(tf, text="Multiple per day", variable=self.type, value="multi", bg=t.bg, fg=t.fg,
                       selectcolor=t.card, activebackground=t.bg, activeforeground=t.fg, font=t.f(0),
                       command=self._on_type).pack(side="left", padx=(0,12))
        tk.Radiobutton(tf, text="Infinite per day", variable=self.type, value="infinite", bg=t.bg, fg=t.fg,
                       selectcolor=t.card, activebackground=t.bg, activeforeground=t.fg, font=t.f(0),
                       command=self._on_type).pack(side="left")
        r+=1
        self.tgt_frame = tk.Frame(c, bg=t.bg)
        tk.Label(self.tgt_frame, text="Target count:", bg=t.bg, fg=t.muted, font=t.f(-1)).pack(side="left")
        self.target = tk.IntVar(value=3)
        tk.Spinbox(self.tgt_frame, from_=2, to=100, textvariable=self.target, width=5, bg=t.card,
                   fg=t.fg, relief="flat", font=t.f(0)).pack(side="left", padx=8)
        self._on_type(); r+=1

        # Color
        tk.Label(c, text="Color", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        cf = tk.Frame(c, bg=t.bg); cf.grid(row=r, column=0, sticky="ew", pady=(2,4), padx=24)
        self.color = tk.StringVar(value=NEON[0])
        sg = tk.Frame(cf, bg=t.bg); sg.pack(side="left")
        for i, col in enumerate(NEON):
            tk.Button(sg, bg=col, relief="flat", width=3, height=1, cursor="hand2",
                      command=lambda c=col: self.color.set(c)).grid(row=i//8, column=i%8, padx=3, pady=3)
        tk.Button(cf, text="Custom...", bg=t.card, fg=t.fg, relief="flat", cursor="hand2", font=t.f(-1),
                  command=lambda: self.color.set(colorchooser.askcolor(self.color.get())[1] or self.color.get())).pack(side="left", padx=8)
        r+=1

        # Schedule
        tk.Label(c, text="Schedule", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        sdf = tk.Frame(c, bg=t.bg); sdf.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24)
        self.sched = tk.StringVar(value="daily")
        for l, v in [("Daily","daily"),("Weekly","weekly"),("Every N days","custom")]:
            tk.Radiobutton(sdf, text=l, variable=self.sched, value=v, bg=t.bg, fg=t.fg, selectcolor=t.card,
                           activebackground=t.bg, activeforeground=t.fg, font=t.f(0),
                           command=self._on_sched).pack(side="left", padx=(0,16))
        r+=1
        self.wd_frame = tk.Frame(c, bg=t.bg)
        self.wd = tk.IntVar(value=0)
        for i, d in enumerate(WEEKDAYS):
            tk.Radiobutton(self.wd_frame, text=d, variable=self.wd, value=i, bg=t.bg, fg=t.fg,
                           selectcolor=t.card, activebackground=t.bg, activeforeground=t.fg,
                           font=t.f(-1)).pack(side="left", padx=(0,8))
        self.iv_frame = tk.Frame(c, bg=t.bg)
        tk.Label(self.iv_frame, text="Every", bg=t.bg, fg=t.fg, font=t.f(0)).pack(side="left")
        self.interval = tk.IntVar(value=3)
        tk.Spinbox(self.iv_frame, from_=1, to=365, textvariable=self.interval, width=5, bg=t.card,
                   fg=t.fg, relief="flat", font=t.f(0)).pack(side="left", padx=8)
        tk.Label(self.iv_frame, text="days, starting", bg=t.bg, fg=t.fg, font=t.f(0)).pack(side="left", padx=(8,0))
        self.start = tk.StringVar(value=dt.date.today().isoformat())
        tk.Entry(self.iv_frame, textvariable=self.start, width=12, bg=t.card, fg=t.fg, relief="flat",
                 font=t.f(0)).pack(side="left", padx=8)
        self._on_sched(); r+=1

        # Times
        tk.Label(c, text="Notify at (HH:MM, comma-separated)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        self.times = tk.StringVar(value="09:00, 20:00")
        tk.Entry(c, textvariable=self.times, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                 font=t.f(1), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24, ipady=6); r+=1

        # Modes
        tk.Label(c, text="Notification modes", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        mf = tk.Frame(c, bg=t.bg); mf.grid(row=r, column=0, sticky="ew", pady=(2,4), padx=24)
        self.modes = {"sound": tk.BooleanVar(value=True), "tts": tk.BooleanVar(value=False), "toast": tk.BooleanVar(value=True), "popup": tk.BooleanVar(value=True)}
        for l, k in [("Sound","sound"),("Voice","tts"),("Toast","toast"),("Popup","popup")]:
            tk.Checkbutton(mf, text=l, variable=self.modes[k], bg=t.bg, fg=t.fg, selectcolor=t.card,
                           activebackground=t.bg, activeforeground=t.fg, font=t.f(0)).pack(side="left", padx=(0,12))
        r+=1

        # Intensity level
        tk.Label(c, text="Notification intensity", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(8,0)); r+=1
        intf = tk.Frame(c, bg=t.bg); intf.grid(row=r, column=0, sticky="ew", pady=(2,4), padx=24)
        self.intensity = tk.StringVar(value="normal")
        for l, v, desc in [("Cute","cute","Just a toast"),("Normal","normal","Toast + popup, repeats"),("Aggressive","aggressive","TTS speaks, savage phrases"),("Rage","rage","Max volume, questions, PC shutdown")]:
            tk.Radiobutton(intf, text=l, variable=self.intensity, value=v, bg=t.bg, fg=t.fg, selectcolor=t.card,
                           activebackground=t.bg, activeforeground=t.fg, font=t.f(0)).pack(side="left", padx=(0,8))
        r+=1

        # Snooze duration
        tk.Label(c, text="Snooze (minutes - re-notify if you click Later)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        sf3 = tk.Frame(c, bg=t.bg); sf3.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24)
        self.snooze = tk.IntVar(value=5)
        tk.Spinbox(sf3, from_=1, to=120, textvariable=self.snooze, width=5, bg=t.card, fg=t.fg,
                   relief="flat", font=t.f(0)).pack(side="left")
        r+=1

        # Rage questions (only shown for rage intensity, but always available in dialog)
        tk.Label(c, text="Rage Questions (one per line - must answer all to dismiss rage popup)",
                 bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(8,0)); r+=1
        self.rage_q = tk.Text(c, height=3, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                              font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                              highlightcolor=t.accent, wrap="word")
        self.rage_q.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24); r+=1

        # Tags
        tk.Label(c, text="Tags (e.g. #work #fitness - links in Map)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        self.tags = tk.StringVar()
        tk.Entry(c, textvariable=self.tags, bg=t.card, fg=t.warn, insertbackground=t.fg, relief="flat",
                 font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24, ipady=6); r+=1

        # Weight
        tk.Label(c, text="Weight (1-10, points per completion)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        wf = tk.Frame(c, bg=t.bg); wf.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24)
        self.weight = tk.IntVar(value=3)
        tk.Spinbox(wf, from_=1, to=10, textvariable=self.weight, width=5, bg=t.card, fg=t.fg,
                   relief="flat", font=t.f(0)).pack(side="left")
        r+=1

        # Forgiveness
        tk.Label(c, text="Forgiveness (missed days that don't break streak)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        ff = tk.Frame(c, bg=t.bg); ff.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24)
        self.forg = tk.IntVar(value=0)
        tk.Spinbox(ff, from_=0, to=10, textvariable=self.forg, width=5, bg=t.card, fg=t.fg,
                   relief="flat", font=t.f(0)).pack(side="left")
        r+=1

        # Tone
        tk.Label(c, text="Phrase tone", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        tf2 = tk.Frame(c, bg=t.bg); tf2.grid(row=r, column=0, sticky="ew", pady=(2,12), padx=24)
        self.tone = tk.StringVar(value="mixed")
        for l, v in [("Mixed","mixed"),("Wholesome","wholesome"),("Savage","savage")]:
            tk.Radiobutton(tf2, text=l, variable=self.tone, value=v, bg=t.bg, fg=t.fg, selectcolor=t.card,
                           activebackground=t.bg, activeforeground=t.fg, font=t.f(0)).pack(side="left", padx=(0,16))
        r+=1

        # Custom phrases
        tk.Label(c, text="Custom phrases (one per line)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        self.phrases = tk.Text(c, height=3, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                               font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                               highlightcolor=t.accent, wrap="word")
        self.phrases.grid(row=r, column=0, sticky="ew", pady=(2,16), padx=24); r+=1

        # Buttons
        bf = tk.Frame(c, bg=t.bg); bf.grid(row=r, column=0, sticky="ew", pady=(0,20), padx=24)
        tk.Button(bf, text="Cancel", bg=t.card, fg=t.muted, relief="flat", font=t.f(0), cursor="hand2",
                  padx=20, pady=8, command=self.destroy).pack(side="right", padx=(8,0))
        tk.Button(bf, text="Save", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(0, True),
                  cursor="hand2", padx=24, pady=8, command=self._save).pack(side="right")

    def _on_type(self):
        self.tgt_frame.grid_forget()
        if self.type.get() == "multi":
            self.tgt_frame.grid(row=5, column=0, sticky="ew", pady=(0,8), padx=24)

    def _on_sched(self):
        self.wd_frame.grid_forget(); self.iv_frame.grid_forget()
        if self.sched.get() == "weekly":
            self.wd_frame.grid(row=8, column=0, sticky="ew", pady=(0,8), padx=24)
        elif self.sched.get() == "custom":
            self.iv_frame.grid(row=8, column=0, sticky="ew", pady=(0,8), padx=24)

    def _load(self):
        s = self.streak
        self.name.set(s.get("name", ""))
        self.desc.insert("1.0", s.get("description", ""))
        self.type.set(s.get("type", "once"))
        self.target.set(s.get("target", 3))
        self._on_type()
        self.color.set(s.get("color", NEON[0]))
        sc = s.get("schedule", {"type":"daily"})
        self.sched.set(sc.get("type","daily"))
        self.wd.set(sc.get("day", 0))
        self.interval.set(sc.get("interval", 3))
        self.start.set(sc.get("start", dt.date.today().isoformat()))
        self._on_sched()
        self.times.set(", ".join(s.get("times", ["09:00","20:00"])))
        for k, v in s.get("modes", {"sound":True,"toast":True,"popup":True}).items():
            if k in self.modes: self.modes[k].set(v)
        self.weight.set(s.get("weight", 3))
        self.forg.set(s.get("forgiveness", 0))
        self.tone.set(s.get("tone", "mixed"))
        self.intensity.set(s.get("intensity", "normal"))
        self.snooze.set(s.get("snooze", 5))
        self.tags.set(s.get("tags", ""))
        self.phrases.insert("1.0", "\n".join(s.get("phrases", [])))
        rq = s.get("rage_questions", [])
        self.rage_q.insert("1.0", "\n".join(rq) if rq else "\n".join(self.d.settings.get("rage_questions", ["What did you just do?", "How do you feel about it?"])))

    def _save(self):
        name = self.name.get().strip()
        if not name:
            messagebox.showerror("Missing", "Give your streak a name.", parent=self); return
        times = [t.strip() for t in self.times.get().split(",") if t.strip()]
        for t in times:
            if not valid_time(t):
                messagebox.showerror("Bad time", f"'{t}' is not HH:MM.", parent=self); return
        modes = {k: v.get() for k, v in self.modes.items()}  # v5.9.9 FIX: keep False values
        if not modes:
            messagebox.showerror("No mode", "Pick at least one notification mode.", parent=self); return
        sc = {"type": self.sched.get()}
        if sc["type"] == "weekly": sc["day"] = self.wd.get()
        elif sc["type"] == "custom":
            sc["interval"] = max(1, self.interval.get())
            try: pd(self.start.get()); sc["start"] = self.start.get()
            except: sc["start"] = dt.date.today().isoformat()
        self.result = {
            "name": name, "description": self.desc.get("1.0","end").strip(),
            "type": self.type.get(), "target": max(2, self.target.get()) if self.type.get()=="multi" else 0,
            "color": self.color.get(), "schedule": sc, "times": times, "modes": modes,
            "weight": max(1, min(10, self.weight.get())), "forgiveness": max(0, self.forg.get()),
            "tone": self.tone.get(), "phrases": [p.strip() for p in self.phrases.get("1.0","end").splitlines() if p.strip()],
            "intensity": self.intensity.get(), "snooze": max(1, self.snooze.get()),
            "rage_questions": [q.strip() for q in self.rage_q.get("1.0","end").splitlines() if q.strip()],
            "tags": self.tags.get().strip(),
        }
        if self.streak:
            self.result["history"] = self.streak.get("history", {})
            self.result["id"] = self.streak.get("id")
            self.result["created"] = self.streak.get("created")
            self.result["last_notified"] = self.streak.get("last_notified", "")
        self.destroy()


# ============================================================
# STREAKS VIEW
# ============================================================

class StreaksView(tk.Frame):
    def __init__(self, parent, d, t, n, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.d = d; self.t = t; self.n = n
        self.sel = None
        self.cal = None
        self._build()

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        body = tk.Frame(self, bg=t.bg); body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=0, minsize=300); body.columnconfigure(1, weight=1); body.rowconfigure(0, weight=1)
        left = tk.Frame(body, bg=t.panel); left.grid(row=0, column=0, sticky="nsew", padx=(0,1))
        tk.Label(left, text="YOUR TASKS", bg=t.panel, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", padx=20, pady=(16,8))
        ls = ScrollFrame(left, t); ls.pack(fill="both", expand=True, padx=8, pady=(0,12))
        self.list = ls.inner
        right = tk.Frame(body, bg=t.bg); right.grid(row=0, column=1, sticky="nsew")
        ds = ScrollFrame(right, t); ds.pack(fill="both", expand=True, padx=4, pady=4)
        self.detail = ds.inner; self.detail.columnconfigure(0, weight=1)
        self._refresh_list()
        if not self.sel: self._empty()

    def _empty(self):
        t = self.t
        for w in self.detail.winfo_children(): w.destroy()
        e = tk.Frame(self.detail, bg=t.bg); e.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        tk.Label(e, text="DILA", bg=t.bg, fg=t.dim, font=t.f(20, True)).pack(pady=(80,8))
        tk.Label(e, text="No task selected.\nClick '+ New Task' to begin.", bg=t.bg, fg=t.muted,
                 font=t.f(2), justify="center").pack()

    def _refresh_list(self):
        t = self.t
        for w in self.list.winfo_children(): w.destroy()
        if not self.d.streaks:
            tk.Label(self.list, text="No tasks yet.\nHit '+ New Task' above.", bg=t.panel, fg=t.dim,
                     font=t.f(0), justify="center", wraplength=240).pack(pady=40, padx=12)
            return
        for s in self.d.streaks:
            self._card(s).pack(fill="x", pady=4, padx=4)

    def _card(self, s):
        t = self.t
        color = s.get("color", t.accent)
        bg = t.hover if s["id"] == self.sel else t.card
        card = tk.Frame(self.list, bg=bg, cursor="hand2"); card.pack_propagate(False); card.configure(height=72)
        tk.Frame(card, bg=color, width=4).pack(side="left", fill="y")
        info = tk.Frame(card, bg=bg); info.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        name = s.get("name", "?"); c = current_streak(s)
        today = dt.date.today().isoformat()
        cnt, tgt = self.d.count_done(s["id"], today)
        done = cnt >= tgt and cnt > 0; due = is_due(s)
        w = max(1, int(s.get("weight", 1)))
        nr = tk.Frame(info, bg=bg); nr.pack(fill="x")
        tk.Label(nr, text=name, bg=bg, fg=t.fg, font=t.f(1, True), anchor="w").pack(side="left")
        tk.Label(nr, text=f"  {w}pts", bg=bg, fg=t.muted, font=t.f(-2, True)).pack(side="left", padx=(4,0))
        if s.get("type") == "multi" and cnt > 0:
            tk.Label(nr, text=f"  ({cnt}/{tgt})", bg=bg, fg=(t.success if done else t.warn), font=t.f(-2, True)).pack(side="left", padx=(4,0))
        elif s.get("type") == "infinite" and cnt > 0:
            tk.Label(nr, text=f"  ({cnt}x)", bg=bg, fg=t.success, font=t.f(-2, True)).pack(side="left", padx=(4,0))
        sc = t.success if done else (t.warn if due else t.muted)
        if s.get("type") == "multi":
            st = f"Day {c} - {cnt}/{tgt} done" if cnt > 0 else (f"Day {c} - due!" if due else f"Day {c} - resting")
        elif s.get("type") == "infinite":
            st = f"Day {c} - {cnt}x today" if cnt > 0 else (f"Day {c} - due!" if due else f"Day {c} - resting")
        else:
            st = f"Day {c} - done OK" if done else (f"Day {c} - due!" if due else f"Day {c} - resting")
        tk.Label(info, text=st, bg=bg, fg=sc, font=t.f(-1), anchor="w").pack(fill="x")
        def sel(e=None):
            self.sel = s["id"]; self._refresh_list(); self._show(s["id"])
        card.bind("<Button-1>", sel)
        for ch in card.winfo_children():
            ch.bind("<Button-1>", sel)
            for gc in ch.winfo_children(): gc.bind("<Button-1>", sel)
        return card

    def _show(self, sid):
        t = self.t
        s = self.d.get_streak(sid)
        if not s: self._empty(); return
        for w in self.detail.winfo_children(): w.destroy()
        color = s.get("color", t.accent); name = s.get("name", "Streak")
        c = current_streak(s); l = longest_streak(s)
        today = dt.date.today().isoformat()
        cnt, tgt = self.d.count_done(sid, today)
        done = cnt >= tgt and cnt > 0; due = is_due(s)
        w = max(1, int(s.get("weight", 1)))
        h = tk.Frame(self.detail, bg=t.bg); h.grid(row=0, column=0, sticky="ew", padx=20, pady=(20,8))
        h.columnconfigure(0, weight=1)
        l2 = tk.Frame(h, bg=t.bg); l2.grid(row=0, column=0, sticky="w")
        cv = tk.Canvas(l2, width=44, height=44, bg=t.bg, highlightthickness=0)
        cv.create_oval(2,2,42,42, fill=color, outline=""); cv.pack(side="left", padx=(0,12))
        tk.Label(l2, text=name, bg=t.bg, fg=t.fg, font=t.f(12, True)).pack(side="left")
        r2 = tk.Frame(h, bg=t.bg); r2.grid(row=0, column=1, sticky="e")
        tk.Button(r2, text="Edit", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=14, pady=6, command=lambda: self._edit(sid)).pack(side="left", padx=(8,0))
        tk.Button(r2, text="Delete", bg=t.card, fg=t.danger, relief="flat", font=t.f(0), cursor="hand2",
                  padx=14, pady=6, command=lambda: self._del(sid)).pack(side="left")
        if s.get("description", "").strip():
            tk.Label(self.detail, text=s["description"], bg=t.bg, fg=t.muted, font=t.f(0),
                     wraplength=600, justify="left").grid(row=1, column=0, sticky="ew", padx=20, pady=(4,8))
        st = tk.Frame(self.detail, bg=t.bg); st.grid(row=2, column=0, sticky="ew", padx=20, pady=(8,8))
        for i in range(4): st.columnconfigure(i, weight=1, uniform="s")
        self._stat(st, 0, "CURRENT", str(c), color)
        self._stat(st, 1, "LONGEST", str(l), t.accent)
        self._stat(st, 2, "WEIGHT", f"{w} pts", t.warn)
        type_label = f"Multi x{tgt}" if s.get("type")=="multi" else ("Infinite" if s.get("type")=="infinite" else "Once")
        self._stat(st, 3, "TYPE", type_label, t.success)
        af = tk.Frame(self.detail, bg=t.bg); af.grid(row=3, column=0, sticky="ew", padx=20, pady=8)
        stype = s.get("type", "once")
        if stype == "infinite":
            btn_text = f"DONE TODAY: {cnt}x  (click to add +1)" if cnt > 0 else "MARK DONE (+1)"
            btn_bg = t.card if cnt > 0 else color
            btn_fg = t.success if cnt > 0 else "#0E0E14"
            tk.Button(af, text=btn_text, bg=btn_bg, fg=btn_fg, relief="flat", font=t.f(3, True),
                      cursor="hand2", padx=24, pady=12, command=lambda: self._toggle(sid)).pack()
            if cnt > 0:
                tk.Label(af, text=f"Today's count: {cnt} completions", bg=t.bg, fg=t.muted, font=t.f(0)).pack(pady=(4,0))
        elif stype == "multi":
            if cnt >= tgt and cnt > 0:
                btn_text = f"DONE TODAY ({cnt}/{tgt}) - click to reset"
                tk.Button(af, text=btn_text, bg=t.card, fg=t.success, relief="flat", font=t.f(3, True),
                          cursor="hand2", padx=24, pady=12, command=lambda: self._toggle(sid)).pack()
            elif due:
                btn_text = f"MARK DONE ({cnt}/{tgt})"
                tk.Button(af, text=btn_text, bg=color, fg="#0E0E14", relief="flat", font=t.f(3, True),
                          cursor="hand2", padx=24, pady=12, command=lambda: self._toggle(sid)).pack()
            else:
                tk.Label(af, text="Not due today - enjoy the rest day.", bg=t.bg, fg=t.muted, font=t.f(1)).pack(pady=8)
        else:
            if done:
                tk.Button(af, text="DONE TODAY OK", bg=t.card, fg=t.success, relief="flat", font=t.f(4, True),
                          cursor="hand2", padx=24, pady=12, command=lambda: self._toggle(sid)).pack()
            elif due:
                tk.Button(af, text="MARK DONE TODAY", bg=color, fg="#0E0E14", relief="flat", font=t.f(4, True),
                          cursor="hand2", padx=24, pady=12, command=lambda: self._toggle(sid)).pack()
            else:
                tk.Label(af, text="Not due today - enjoy the rest day.", bg=t.bg, fg=t.muted, font=t.f(1)).pack(pady=8)
        cw = tk.Frame(self.detail, bg=t.bg); cw.grid(row=4, column=0, sticky="ew", padx=20, pady=(8,0))
        tk.Label(cw, text="LAST 52 WEEKS - click to toggle", bg=t.bg, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", pady=(0,4))
        self.cal = Heatmap(cw, self.d, t, sid, 52)
        self.cal.pack(fill="x")

    def _stat(self, p, col, l, v, c):
        t = self.t
        card = tk.Frame(p, bg=t.card, padx=16, pady=10); card.grid(row=0, column=col, sticky="ew", padx=4)
        tk.Label(card, text=l, bg=t.card, fg=t.muted, font=t.f(-2, True)).pack(anchor="w")
        tk.Label(card, text=v, bg=t.card, fg=c, font=t.f(10, True)).pack(anchor="w")

    def _toggle(self, sid):
        s = self.d.get_streak(sid)
        if not s: return
        today = dt.date.today().isoformat()
        stype = s.get("type", "once")
        if stype == "multi":
            cnt, tgt = self.d.count_done(sid, today)
            if cnt >= tgt and cnt > 0:
                self.d.unmark(sid, today)
            else:
                self.d.mark_done(sid, today)
        elif stype == "infinite":
            self.d.mark_done(sid, today)
        else:
            if today in hist_dates(s):
                self.d.unmark(sid, today)
            else:
                self.d.mark_done(sid, today)
        self._refresh_list(); self._show(sid)
        # v5.9.7: refresh TODAY score immediately
        try:
            app = self.winfo_toplevel()
            if hasattr(app, "_update_score"): app._update_score()
        except: pass

    def new(self):
        dlg = StreakDialog(self.winfo_toplevel(), self.d, self.t)
        self.wait_window(dlg)
        if dlg.result:
            self.d.add_streak(dlg.result)
            self.sel = self.d.streaks[-1]["id"]
            self._refresh_list(); self._show(self.sel)

    def _edit(self, sid):
        s = self.d.get_streak(sid)
        if not s: return
        dlg = StreakDialog(self.winfo_toplevel(), self.d, self.t, s)
        self.wait_window(dlg)
        if dlg.result:
            self.d.update_streak(sid, dlg.result)
            self._refresh_list(); self._show(sid)

    def _del(self, sid):
        s = self.d.get_streak(sid)
        if not s: return
        if messagebox.askyesno("Delete", f"Delete '{s.get('name','?')}'?"):
            self.d.delete_streak(sid)
            if self.sel == sid: self.sel = None
            self._refresh_list(); self._empty()
            # v5.9.7: refresh TODAY score immediately
            try:
                app = self.winfo_toplevel()
                if hasattr(app, "_update_score"): app._update_score()
            except: pass

    def refresh(self):
        self._refresh_list()
        if self.sel: self._show(self.sel)


# ============================================================
# HEATMAP
# ============================================================

class Heatmap(tk.Frame):
    """GitHub-style contribution heatmap. Supports per-streak (binary) and global (intensity) views."""
    def __init__(self, parent, d, t, sid=None, weeks=52, **kw):
        super().__init__(parent, bg=t.panel, **kw)
        self.d = d; self.t = t; self.sid = sid; self.weeks = weeks
        self._build()

    def _intensity_color(self, base, ratio):
        """Return base color blended toward bg by (1-ratio). 5 buckets like GitHub."""
        t = self.t
        if ratio <= 0: return t.card
        # 4 intensity levels
        if ratio < 0.25: r = 0.25
        elif ratio < 0.50: r = 0.50
        elif ratio < 0.75: r = 0.75
        else: r = 1.0
        return blend(t.card, base, r)

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        today = dt.date.today()
        # Show full year: Jan 1 to Dec 31
        start = today.replace(month=1, day=1)
        # Align to Monday of the starting week
        start = start - dt.timedelta(days=start.weekday())
        # Calculate weeks to cover full year (Jan 1 to Dec 31)
        dec31 = today.replace(month=12, day=31)
        self.weeks = (dec31 - start).days // 7 + 1
        # Use historical max for global heatmap so deleted streaks don't shrink colors
        if self.sid:
            s = self.d.get_streak(self.sid)
            max_pts = 1
            base_color = s.get("color", t.accent) if s else t.accent
        else:
            max_pts = self.d.historical_max_points()
            base_color = t.accent

        # Body: day labels (Mon/Wed/Fri) + cells (no month labels header)
        body = tk.Frame(self, bg=t.panel); body.pack(fill="x", padx=10, pady=(8, 4))
        day_labels = ["Mon", "", "Wed", "", "Fri", "", "Sun"]
        for row in range(7):
            lbl = day_labels[row]
            if lbl:
                tk.Label(body, text=lbl, bg=t.panel, fg=t.dim, font=t.f(-3), width=3, anchor="e").grid(
                    row=row + 1, column=0, padx=(0, 4), sticky="e")
            else:
                tk.Label(body, text="", bg=t.panel, width=3).grid(row=row + 1, column=0)
        for col in range(self.weeks):
            for row in range(7):
                d = start + dt.timedelta(days=col * 7 + row)
                if d > dt.date.today().replace(month=12, day=31): continue
                iso = d.isoformat()
                if self.sid:
                    s = self.d.get_streak(self.sid)
                    cnt, tgt = self.d.count_done(self.sid, iso) if s else (0, 0)
                    due = is_due(s, d) if s else False
                    if s and not streak_existed_on(s, d):
                        bg = t.bg
                    elif cnt > 0:
                        stype = s.get("type", "once") if s else "once"
                        if stype == "multi":
                            ratio = cnt / max(1, tgt)
                        elif stype == "infinite":
                            ratio = min(1.0, cnt / 5.0)
                        else:
                            ratio = 1.0
                        bg = self._intensity_color(base_color, ratio)
                    elif due:
                        bg = t.hover
                    else:
                        bg = t.card
                else:
                    e, tot = self.d.daily_points(iso)
                    if e > 0:
                        ratio = e / tot if tot > 0 else 1.0
                        bg = self._intensity_color(base_color, ratio)
                    else:
                        bg = t.card
                cell = tk.Label(body, bg=bg, width=2, height=1, relief="flat", font=t.f(-4),
                                cursor="hand2" if self.sid else "arrow")
                cell.grid(row=row + 1, column=col + 1, padx=1, pady=1)
                # Tooltip on hover
                if self.sid:
                    s = self.d.get_streak(self.sid)
                    cnt, tgt = self.d.count_done(self.sid, iso) if s else (0, 1)
                    if s and s.get("type") == "multi" and cnt > 0:
                        tip = f"{iso}: {cnt}/{tgt}"
                    elif s and s.get("type") == "infinite" and cnt > 0:
                        tip = f"{iso}: {cnt}x done"
                    elif self.sid and iso in hist_dates(s or {}):
                        tip = f"{iso}: done"
                    elif self.sid and due:
                        tip = f"{iso}: due"
                    else:
                        tip = f"{iso}: -"
                else:
                    e, tot = self.d.daily_points(iso)
                    tip = f"{iso}: {e}/{tot} pts"
                cell.bind("<Enter>", lambda e, tip=tip, lbl=cell: self._show_tip(lbl, tip))
                cell.bind("<Leave>", lambda e, lbl=cell: self._hide_tip(lbl))
                if self.sid:
                    cell.bind("<Button-1>", lambda e, iso=iso: self._click(iso))

        # Legend
        legend = tk.Frame(self, bg=t.panel); legend.pack(fill="x", padx=10, pady=(2, 8))
        tk.Label(legend, text="Less", bg=t.panel, fg=t.dim, font=t.f(-3)).pack(side="left", padx=(0, 4))
        for r in [0, 0.25, 0.5, 0.75, 1.0]:
            c = t.card if r == 0 else self._intensity_color(base_color, r)
            tk.Label(legend, bg=c, width=2, height=1, relief="flat").pack(side="left", padx=1)
        tk.Label(legend, text="More", bg=t.panel, fg=t.dim, font=t.f(-3)).pack(side="left", padx=(4, 0))

    def _show_tip(self, lbl, text):
        try:
            lbl.tip = tk.Toplevel(lbl)
            lbl.tip.wm_overrideredirect(True)
            lbl.tip.wm_geometry(f"+{lbl.winfo_rootx() + 15}+{lbl.winfo_rooty() + 15}")
            tk.Label(lbl.tip, text=text, bg="#000", fg="#FFF", font=self.t.f(-2),
                     padx=6, pady=2).pack()
        except: pass

    def _hide_tip(self, lbl):
        try:
            if hasattr(lbl, "tip") and lbl.tip:
                lbl.tip.destroy(); lbl.tip = None
        except: pass

    def _click(self, iso):
        s = self.d.get_streak(self.sid)
        if not s: return
        today_iso = dt.date.today().isoformat()
        # Only allow toggling today (and past dates) — but be permissive
        stype = s.get("type", "once")
        if stype == "multi":
            cnt, tgt = self.d.count_done(self.sid, iso)
            if cnt >= tgt and cnt > 0:
                self.d.unmark(self.sid, iso)
            else:
                self.d.mark_done(self.sid, iso)
        elif stype == "infinite":
            self.d.mark_done(self.sid, iso)
        else:
            if iso in hist_dates(s):
                self.d.unmark(self.sid, iso)
            else:
                self.d.mark_done(self.sid, iso)
        self._build()
        # v5.9.7: refresh TODAY score + StreaksView immediately
        try:
            app = self.winfo_toplevel()
            if hasattr(app, "_update_score"): app._update_score()
            if hasattr(app, "tabs") and "Tasks" in app.tabs:
                sv = app.tabs["Tasks"]
                if hasattr(sv, "_refresh_list"): sv._refresh_list()
                if sv.sel: sv._show(sv.sel)
            # v5.9.9 FIX: also refresh Calendar + Stats
            if hasattr(app, "tabs"):
                if "Calendar" in app.tabs and hasattr(app.tabs["Calendar"], "refresh"):
                    app.tabs["Calendar"].refresh()
                if "Stats" in app.tabs and hasattr(app.tabs["Stats"], "refresh"):
                    app.tabs["Stats"].refresh()
        except: pass


# ============================================================
# NOTES VIEW (WYSIWYG + Markdown preview)
# ============================================================

class NotesView(tk.Frame):
    def __init__(self, parent, d, t, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.d = d; self.t = t
        self.cur = None
        self._imgs = []
        self._transition_type = "fade"  # v5.9.9: default present-mode transition
        self._build()

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        body = tk.Frame(self, bg=t.bg); body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=0, minsize=280); body.columnconfigure(1, weight=1); body.rowconfigure(0, weight=1)

        # Sidebar
        sb = tk.Frame(body, bg=t.panel); sb.grid(row=0, column=0, sticky="nsew", padx=(0,1))
        tk.Label(sb, text="NOTES & NOTEBOOKS", bg=t.panel, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", padx=16, pady=(16,8))
        sf = tk.Frame(sb, bg=t.panel); sf.pack(fill="x", padx=12, pady=(0,8))
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *a: self._refresh_list())
        tk.Entry(sf, textvariable=self.search, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                 font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).pack(fill="x", ipady=4)
        bf2 = tk.Frame(sb, bg=t.panel); bf2.pack(fill="x", padx=12, pady=(0,8))
        tk.Button(bf2, text="+ New Note", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(-1, True),
                  cursor="hand2", padx=8, pady=4, command=self._new).pack(side="left", fill="x", expand=True)
        tk.Button(bf2, text="+ Notebook", bg=t.card, fg=t.fg, relief="flat", font=t.f(-1),
                  cursor="hand2", padx=8, pady=4, command=self._new_notebook).pack(side="left", padx=(4,0))
        ls = ScrollFrame(sb, t); ls.pack(fill="both", expand=True, padx=8, pady=(0,12))
        self.list = ls.inner

        # Editor
        ed = tk.Frame(body, bg=t.bg); ed.grid(row=0, column=1, sticky="nsew")
        ed.columnconfigure(0, weight=1); ed.rowconfigure(0, weight=0); ed.rowconfigure(1, weight=0); ed.rowconfigure(2, weight=0); ed.rowconfigure(3, weight=1)

        # Title bar
        tb = tk.Frame(ed, bg=t.bg); tb.grid(row=0, column=0, sticky="ew", padx=20, pady=(16,8))
        tb.columnconfigure(0, weight=1); tb.columnconfigure(1, weight=0); tb.columnconfigure(2, weight=0)
        self.title_var = tk.StringVar()
        self.title_var.trace_add("write", lambda *a: self._on_title())
        tk.Entry(tb, textvariable=self.title_var, bg=t.bg, fg=t.fg, insertbackground=t.fg, relief="flat",
                 font=t.f(4, True), highlightthickness=0).grid(row=0, column=0, sticky="ew", ipady=4)
        # Notebook dropdown
        self.nb_var = tk.StringVar(value="(no notebook)")
        self.nb_menu = tk.OptionMenu(tb, self.nb_var, "(no notebook)")
        self.nb_menu.configure(bg=t.card, fg=t.fg, relief="flat", font=t.f(-1), highlightthickness=0, width=15)
        self.nb_menu.grid(row=0, column=1, sticky="e", padx=(8,0))
        # Tags field
        self.tags_var = tk.StringVar()
        self.tags_var.trace_add("write", lambda *a: self._on_tags())
        tk.Entry(tb, textvariable=self.tags_var, bg=t.card, fg=t.warn, insertbackground=t.fg, relief="flat",
                 font=t.f(-1), width=16, highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).grid(row=0, column=2, sticky="e", ipady=4, padx=(8,0))
        tk.Button(tb, text="Delete", bg=t.card, fg=t.danger, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=4, command=self._del).grid(row=0, column=3, padx=(8,0))

        # Toolbar (row 1: actions)
        toolbar = tk.Frame(ed, bg=t.panel, height=44); toolbar.grid(row=1, column=0, sticky="ew", padx=20, pady=(0,2))
        toolbar.pack_propagate(False)
        buttons = [
            ("+ Insert", t.accent, "#0E0E14", True, self._insert_menu),
            ("Math Kit", t.card, t.fg, False, self._math_kit),
            ("Graph", t.card, t.fg, False, self._graph_calc),
            ("Split", t.card, t.fg, False, self._split_at_cursor),
            ("Draw", t.card, t.fg, False, self._draw),
            ("Present", t.card, t.fg, False, self._present),
            ("⤢", t.card, t.accent, False, self._transitions_menu),
            ("Run Code", t.card, t.success, False, self._run_code),
            ("Screenshot", t.card, t.fg, False, self._screenshot),
        ]
        for label, bg, fg, bold, cmd in buttons:
            tk.Button(toolbar, text=label, bg=bg, fg=fg, relief="flat", font=t.f(0, bold),
                      cursor="hand2", padx=10, pady=6, command=cmd).pack(side="left", padx=2, pady=6)
        tk.Button(toolbar, text="Download", bg=t.card, fg=t.warn, relief="flat", font=t.f(0),
                  cursor="hand2", padx=10, pady=6, command=self._download).pack(side="right", padx=(2,8), pady=6)

        # Formatting toolbar (row 2: Word-like bold/italic/font/size/etc.)
        fmt = tk.Frame(ed, bg=t.panel, height=40); fmt.grid(row=2, column=0, sticky="ew", padx=20, pady=(0,4))
        fmt.pack_propagate(False)
        # Font family dropdown
        self._font_var = tk.StringVar(value="Segoe UI")
        font_options = ["Segoe UI", "Arial", "Calibri", "Cambria", "Times New Roman", "Georgia",
                        "Consolas", "Courier New", "Verdana", "Tahoma", "Trebuchet MS",
                        "Comic Sans MS", "Impact", "Bookman Old Style", "Garamond",
                        "Helvetica", "Lucida Console", "Microsoft Sans Serif"]
        ff = tk.OptionMenu(fmt, self._font_var, *font_options, command=self._apply_font_family)
        ff.configure(bg=t.card, fg=t.fg, relief="flat", font=t.f(-1), highlightthickness=0)
        ff.pack(side="left", padx=2, pady=6)
        # Font size dropdown
        self._size_var = tk.IntVar(value=12)
        sizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 48, 72]
        sf_menu = tk.OptionMenu(fmt, self._size_var, *sizes, command=self._apply_font_size)
        sf_menu.configure(bg=t.card, fg=t.fg, relief="flat", font=t.f(-1), highlightthickness=0)
        sf_menu.pack(side="left", padx=2, pady=6)
        # Separator
        tk.Label(fmt, text="|", bg=t.panel, fg=t.dim, font=t.f(0)).pack(side="left", padx=6)
        # Format buttons
        fmt_buttons = [
            ("B", "bold", t.f(1, True)),
            ("I", "italic", (t.font, t.fsize, "italic")),
            ("U", "underline", (t.font, t.fsize, "underline")),
            ("S", "strike", (t.font, t.fsize, "overstrike")),
        ]
        for label, tag_name, font in fmt_buttons:
            tk.Button(fmt, text=label, bg=t.card, fg=t.fg, relief="flat", font=font,
                      cursor="hand2", padx=10, pady=2,
                      command=lambda tn=tag_name: self._toggle_tag(tn)).pack(side="left", padx=2, pady=6)
        tk.Label(fmt, text="|", bg=t.panel, fg=t.dim, font=t.f(0)).pack(side="left", padx=6)
        # Color button
        tk.Button(fmt, text="Color", bg=t.card, fg=t.fg, relief="flat", font=t.f(-1),
                  cursor="hand2", padx=8, pady=2, command=self._apply_color).pack(side="left", padx=2, pady=6)
        # Alignment
        for label, align in [("Left", "left"), ("Center", "center"), ("Right", "right")]:
            tk.Button(fmt, text=label, bg=t.card, fg=t.fg, relief="flat", font=t.f(-1),
                      cursor="hand2", padx=6, pady=2,
                      command=lambda a=align: self._apply_align(a)).pack(side="left", padx=2, pady=6)

        # Content area (row 3)
        self.content_frame = tk.Frame(ed, bg=t.bg); self.content_frame.grid(row=3, column=0, sticky="nsew", padx=20, pady=(0,20))
        self.content_frame.columnconfigure(0, weight=1); self.content_frame.rowconfigure(0, weight=1)
        self._empty_state()

    def _empty_state(self):
        t = self.t
        for w in self.content_frame.winfo_children(): w.destroy()
        tk.Label(self.content_frame, text="No note selected.\nClick '+ New Note' to begin.", bg=t.bg,
                 fg=t.muted, font=t.f(2), justify="center").grid(row=0, column=0, pady=80)

    def _refresh_list(self):
        t = self.t
        for w in self.list.winfo_children(): w.destroy()
        q = self.search.get().lower().strip()
        notebooks = self.d.get_notebooks()
        notes = self.d.notes
        if q:
            notes = [n for n in notes if q in n["title"].lower() or q in n.get("content","").lower() or q in n.get("tags","").lower()]
            notebooks = [nb for nb in notebooks if q in nb.get("name","").lower() or q in nb.get("tags","").lower()]
        # Show notebooks with their notes as a tree
        for nb in notebooks:
            nb_card = tk.Frame(self.list, bg=t.card, cursor="hand2")
            nb_card.pack(fill="x", pady=2, padx=4)
            tk.Label(nb_card, text=f"\U0001F4D6  {nb.get('name','?')}", bg=nb_card["bg"], fg=t.accent, font=t.f(0, True),
                     anchor="w").pack(fill="x", padx=12, pady=(6,2))
            if nb.get("tags"):
                tk.Label(nb_card, text=nb["tags"], bg=nb_card["bg"], fg=t.warn, font=t.f(-2),
                         anchor="w").pack(fill="x", padx=12, pady=(0,4))
            nb_notes = [n for n in notes if n.get("notebook_id") == nb["id"]]
            for n in sorted(nb_notes, key=lambda x: x.get("modified",""), reverse=True):
                self._note_card(n, indent=20)
        # Show unassigned notes
        unassigned = [n for n in notes if not n.get("notebook_id")]
        if unassigned and notebooks:
            tk.Label(self.list, text="Unassigned", bg=t.panel, fg=t.dim, font=t.f(-1, True),
                     anchor="w").pack(fill="x", padx=12, pady=(8,4))
        for n in sorted(unassigned, key=lambda x: x.get("modified",""), reverse=True):
            self._note_card(n, indent=0)
        if not notes and not notebooks:
            tk.Label(self.list, text="No notes yet.\nClick '+ New Note' to begin.", bg=t.panel, fg=t.dim, font=t.f(0),
                     justify="center").pack(pady=40, padx=12)

    def _note_card(self, n, indent=0):
        t = self.t
        card = tk.Frame(self.list, bg=t.hover if n["id"]==self.cur else t.card, cursor="hand2")
        card.pack(fill="x", pady=2, padx=4+indent)
        title_text = n["title"] or "Untitled"
        if n.get("tags"):
            title_text += f"  {n['tags']}"
        tk.Label(card, text=title_text, bg=card["bg"], fg=t.fg, font=t.f(0, True),
                 anchor="w").pack(fill="x", padx=12, pady=(6,2))
        # Show splits as sub-items (parsed from content markers)
        content = n.get("content", "") or ""
        split_names = re.findall(r'^===SPLIT:([^|]+)\|', content, re.MULTILINE)
        if split_names:
            split_preview = "  \u2502".join(s.strip()[:12] for s in split_names[:3])
            if len(split_names) > 3:
                split_preview += f"  (+{len(split_names)-3})"
            tk.Label(card, text=f"\u2514 {split_preview}", bg=card["bg"], fg=t.muted, font=t.f(-2),
                     anchor="w").pack(fill="x", padx=16, pady=(0,2))
        preview = (n.get("content","")[:60]).replace("\n"," ")
        tk.Label(card, text=preview, bg=card["bg"], fg=t.dim, font=t.f(-1), anchor="w",
                 wraplength=220, justify="left").pack(fill="x", padx=12, pady=(0,6))
        def sel(e=None, nid=n["id"]):
            self._select(nid)
        card.bind("<Button-1>", sel)
        for ch in card.winfo_children(): ch.bind("<Button-1>", sel)

    def _new_notebook(self):
        name = simpledialog.askstring("New Notebook", "Notebook name:", parent=self)
        if not name: return
        tags = simpledialog.askstring("Tags", "Tags (e.g. #work #project):", parent=self) or ""
        self.d.add_notebook(name, tags)
        self._refresh_list()

    def _new(self):
        n = self.d.add_note("Untitled", "")
        self.cur = n["id"]
        self._refresh_list(); self._load(n)
        self.title_var.set("")
        self._focus_editor()

    def _select(self, nid):
        n = self.d.get_note(nid)
        if not n: return
        # v5.10: flush any pending save from the current note before switching
        if self.cur and self.cur != nid:
            self._flush_pending_save()
        self.cur = nid
        self._refresh_list(); self._load(n)

    def _load(self, n):
        t = self.t
        self.title_var.set(n["title"])
        self.tags_var.set(n.get("tags", ""))
        self._refresh_notebook_menu()
        nb_id = n.get("notebook_id")
        if nb_id:
            nb = self.d.get_notebook(nb_id)
            self.nb_var.set(nb.get("name", "(unknown)") if nb else "(no notebook)")
        else:
            self.nb_var.set("(no notebook)")
        # v5.10: reset tracking BEFORE destroying widgets, so event handlers
        # from old widgets see empty lists and return early.
        self._section_widgets = []   # one tk.Text per section
        self._section_meta = []
        self._embed_raws = {}        # {widget_path: raw_markdown} for inline embeds
        self._embed_widgets = []     # refs to prevent GC
        for w in self.content_frame.winfo_children(): w.destroy()
        # v5.10: Single WYSIWYG mode. Each section is ONE Text widget with inline
        # embedded rich content (images, code blocks, tables, diagrams, media).
        # Text flows naturally around embeds — like Word. Everything is editable.
        self._render_sections(n.get("content", ""))

    def _get_full_content(self):
        """v5.10: Reassemble raw markdown from all section Text widgets.
        Walks each widget with dump() — text portions come from the widget,
        embedded windows come from _embed_raws. Zero data loss."""
        if not hasattr(self, "_section_widgets") or not self._section_widgets:
            return ""
        parts = []
        for sec_idx, widget in enumerate(self._section_widgets):
            try:
                if not widget.winfo_exists(): continue
            except: continue
            content = self._get_section_content(widget)
            if sec_idx == 0 and self._section_meta[sec_idx].get("name") == "Intro":
                parts.append(content)
            else:
                meta = self._section_meta[sec_idx]
                marker = f"===SPLIT:{meta['name']}|{meta['bg']}|{meta.get('tags','')}==="
                parts.append(marker)
                parts.append(content)
        return "\n".join(parts)

    def _get_section_content(self, widget):
        """Walk a Text widget with dump() and reconstruct raw markdown.
        Text items -> use text directly. Window items -> look up raw in _embed_raws."""
        result = []
        try:
            for kind, value, index in widget.dump("1.0", "end-1c"):
                if kind == "text":
                    result.append(value)
                elif kind == "window":
                    raw = self._embed_raws.get(value, "")
                    result.append(raw)
        except: pass
        return "".join(result)

    def _add_section(self):
        """Add a new split section at the bottom of the note."""
        if not hasattr(self, "_section_widgets"):
            messagebox.showinfo("No Note", "Open a note first."); return
        t = self.t
        # Ask for section name + tags
        dlg = tk.Toplevel(self); dlg.title("New Section")
        dlg.configure(bg=t.bg); dlg.transient(self); dlg.grab_set()
        dlg.resizable(False, False)
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        _w, _h = 380, 240
        dlg.geometry(f"{_w}x{_h}+{(sw-_w)//2}+{(sh-_h)//2}")
        dlg.lift(); dlg.focus_force()
        tk.Label(dlg, text="Section name:", bg=t.bg, fg=t.fg, font=t.f(0, True)).pack(anchor="w", padx=18, pady=(18,4))
        name_var = tk.StringVar(value=f"Section {len(self._section_widgets) + 1}")
        name_entry = tk.Entry(dlg, textvariable=name_var, bg=t.card, fg=t.fg, insertbackground=t.fg,
                 relief="flat", font=t.f(0), highlightthickness=1,
                 highlightbackground=t.border, highlightcolor=t.accent)
        name_entry.pack(fill="x", padx=18, ipady=5)
        name_entry.focus_set()
        name_entry.select_range(0, "end")
        tk.Label(dlg, text="Tags (e.g. #part2 #notes):", bg=t.bg, fg=t.fg, font=t.f(0, True)).pack(anchor="w", padx=18, pady=(12,4))
        tags_var = tk.StringVar()
        tk.Entry(dlg, textvariable=tags_var, bg=t.card, fg=t.warn, insertbackground=t.fg,
                 relief="flat", font=t.f(0), highlightthickness=1,
                 highlightbackground=t.border, highlightcolor=t.accent).pack(fill="x", padx=18, ipady=5)
        result = {"name": None, "tags": ""}
        def ok():
            result["name"] = name_var.get().strip()
            result["tags"] = tags_var.get().strip()
            dlg.destroy()
        def cancel(): dlg.destroy()
        bf = tk.Frame(dlg, bg=t.bg); bf.pack(side="right", padx=18, pady=14)
        tk.Button(bf, text="Cancel", bg=t.card, fg=t.muted, relief="flat", font=t.f(0),
                  cursor="hand2", padx=14, pady=7, command=cancel).pack(side="left", padx=4)
        tk.Button(bf, text="Pick Color & Add", bg=t.accent, fg="#0E0E14", relief="flat",
                  font=t.f(0, True), cursor="hand2", padx=14, pady=7, command=ok).pack(side="left", padx=4)
        dlg.bind("<Return>", lambda e: ok())
        dlg.bind("<Escape>", lambda e: cancel())
        self.wait_window(dlg)
        name = result["name"]
        if not name: return
        tags = result["tags"]
        _color_result = colorchooser.askcolor(t.accent, title="Section divider color")
        bg_color = _color_result[1]
        if not bg_color: return  # v5.9.9 FIX: user cancelled color picker — abort
        # v5.9.9 FIXED: cancel any pending save timer, then build content string directly.
        # Was appending to _section_meta without a matching editor, causing _get_full_content
        # to skip the new section entirely. Now we append the marker to the content string.
        if self._content_timer: self._content_timer.cancel(); self._content_timer = None
        n = self.d.get_note(self.cur)
        if not n: return
        current_content = self._get_full_content()
        marker = f"===SPLIT:{name}|{bg_color}|{tags}==="
        new_content = current_content.rstrip("\n") + "\n" + marker + "\n"
        n["content"] = new_content
        self.d.update_note(self.cur, content=new_content)
        self._load(n)

    def _delete_section(self, idx):
        """Delete a section (merge its content into the previous section)."""
        if not hasattr(self, "_section_widgets"): return
        if idx <= 0 or idx >= len(self._section_widgets):
            return  # can't delete the first (Intro) section
        if not messagebox.askyesno("Delete Section",
                f"Delete section '{self._section_meta[idx]['name']}'?\nIts content will be merged into the previous section."):
            return
        # Cancel any pending save
        if self._content_timer: self._content_timer.cancel(); self._content_timer = None
        # Merge: append current section's content to previous section
        prev_content = self._get_section_content(self._section_widgets[idx - 1])
        cur_content = self._get_section_content(self._section_widgets[idx])
        merged = prev_content.rstrip("\n") + "\n" + cur_content
        # Rebuild full content with the merge applied
        n = self.d.get_note(self.cur)
        if n:
            new_parts = []
            for si in range(len(self._section_widgets)):
                if si == idx: continue  # skip deleted section
                if si == idx - 1:
                    sec_content = merged
                else:
                    sec_content = self._get_section_content(self._section_widgets[si])
                if si == 0 and self._section_meta[si].get("name") == "Intro":
                    new_parts.append(sec_content)
                else:
                    meta = self._section_meta[si]
                    new_parts.append(f"===SPLIT:{meta['name']}|{meta['bg']}|{meta.get('tags','')}===")
                    new_parts.append(sec_content)
            n["content"] = "\n".join(new_parts)
            self.d.save()
            self._load(n)
            self._cleanup_map_splits_for_note(n["id"])
            self._refresh_map()

    def _focus_editor(self):
        if hasattr(self, "editor"):
            self.editor.focus_set()
            self.editor.delete("1.0", "end")

    def _on_title(self):
        if not self.cur: return
        self.d.update_note(self.cur, title=self.title_var.get().strip() or "Untitled")
        self._refresh_list()

    def _on_tags(self):
        if not self.cur: return
        self.d.update_note(self.cur, tags=self.tags_var.get())
        self._refresh_list()

    def _refresh_notebook_menu(self):
        """Rebuild the notebook dropdown with current notebooks."""
        if not hasattr(self, "nb_menu"): return
        self.nb_menu["menu"].delete(0, "end")
        notebooks = self.d.get_notebooks()
        options = ["(no notebook)"] + [nb.get("name", "?") for nb in notebooks]
        for opt in options:
            self.nb_menu["menu"].add_command(label=opt, command=lambda v=opt: self._on_notebook(v))

    def _on_notebook(self, name):
        if not self.cur: return
        n = self.d.get_note(self.cur)
        if not n: return
        if name == "(no notebook)":
            n["notebook_id"] = None
        else:
            for nb in self.d.get_notebooks():
                if nb.get("name") == name:
                    n["notebook_id"] = nb["id"]; break
        self.d.save()
        self._refresh_list()

    def _refresh_map(self):
        """v5.10: Refresh the Map tab if it exists (so deleted splits/notes disappear)."""
        try:
            app = self.winfo_toplevel()
            if hasattr(app, "tabs") and "Map" in app.tabs:
                if hasattr(app.tabs["Map"], "refresh"):
                    app.tabs["Map"].refresh()
        except: pass

    def _cleanup_map_for_deleted_note(self, note_id):
        """v5.10: When a note is hard-deleted, remove all stale map entries for it
        and its splits: soft-delete entries, removed edges, saved positions,
        custom colors, and transparency settings."""
        self._cleanup_map_entries(note_id, clean_note=True)

    def _cleanup_map_splits_for_note(self, note_id):
        """v5.10: When a split is deleted from a note, clean up ALL split-related map
        entries for that note. Split IDs are index-based (noteId_split0, split1, ...),
        so deleting one shifts the indices of the rest — all split entries must be cleared."""
        self._cleanup_map_entries(note_id, clean_note=False)

    def _cleanup_map_entries(self, note_id, clean_note):
        """v5.10: Core cleanup logic. If clean_note=True, also remove note-level entries."""
        try:
            s = self.d.settings
            nid = note_id
            split_prefix = nid + "_split"
            # 1. Remove from map_deleted_nodes
            deleted_nodes = s.get("map_deleted_nodes", [])
            def _should_remove_dn(dn):
                if dn.get("type") == "split" and dn.get("id", "").startswith(split_prefix):
                    return True
                if clean_note and dn.get("type") == "note" and dn.get("id") == nid:
                    return True
                return False
            deleted_nodes = [dn for dn in deleted_nodes if not _should_remove_dn(dn)]
            s["map_deleted_nodes"] = deleted_nodes
            # Also update GraphMapView's in-memory copy
            try:
                app = self.winfo_toplevel()
                if hasattr(app, "tabs") and "Map" in app.tabs:
                    gm = app.tabs["Map"]
                    gm._deleted_nodes = [dn for dn in gm._deleted_nodes if not _should_remove_dn(dn)]
            except: pass
            # 2. Remove from map_removed_edges (any edge involving this note's splits, or the note itself)
            removed_edges = s.get("map_removed_edges", [])
            def _should_remove_edge(de):
                f = de.get("from", ""); t = de.get("to", "")
                if f.startswith(f"split:{split_prefix}") or t.startswith(f"split:{split_prefix}"):
                    return True
                if clean_note and (f.startswith(f"note:{nid}") or t.startswith(f"note:{nid}")):
                    return True
                return False
            removed_edges = [de for de in removed_edges if not _should_remove_edge(de)]
            s["map_removed_edges"] = removed_edges
            # 3. Remove saved positions
            positions = s.get("map_positions", {})
            keys_to_del = [k for k in positions
                           if k.startswith(f"split:{split_prefix}")
                           or (clean_note and k == f"note:{nid}")]
            for k in keys_to_del: del positions[k]
            s["map_positions"] = positions
            # 4. Remove custom colors + transparency
            for setting_key in ("map_node_colors", "map_node_transparency",
                                "map_edge_colors", "map_edge_transparency"):
                d2 = s.get(setting_key, {})
                keys_to_del = [k for k in d2
                               if k.startswith(f"split:{split_prefix}")
                               or (clean_note and (k == f"note:{nid}" or k.startswith(f"note:{nid}-")))
                               or ("-split:" + split_prefix) in k
                               or (clean_note and ("-note:" + nid) in k)]
                for k in keys_to_del: del d2[k]
                s[setting_key] = d2
            self.d.save()
        except: pass

    _content_timer = None
    def _on_content(self):
        if not self.cur: return
        if self._content_timer: self._content_timer.cancel()
        import threading as th
        nid = self.cur  # v5.9.9 FIX: capture nid NOW so switching notes doesn't corrupt
        content = self._get_full_content()
        # v5.9.9 FIX: schedule on main thread to avoid concurrent JSON writes
        def _do_save():
            if self.cur == nid:  # only save if we're still on the same note
                self.d.update_note(nid, content=content)
        self._content_timer = th.Timer(0.5, lambda: self.after(0, _do_save) if self.winfo_exists() else None)
        self._content_timer.start()

    def _flush_pending_save(self):
        """v5.10: Cancel any pending debounced save and save immediately.
        Called before mode switches / note switches to prevent data loss."""
        if self._content_timer:
            self._content_timer.cancel(); self._content_timer = None
        if self.cur:
            content = self._get_full_content()
            n = self.d.get_note(self.cur)
            if n:
                n["content"] = content
                self.d.update_note(self.cur, content=content)

    def _style_split_markers(self):
        """No longer needed — splits are now real section dividers, not text markers."""
        pass

    # ============================================================
    # v5.10: INLINE-EMBED WYSIWYG EDITOR (Word-like)
    # One Text widget per section. Rich content (images, code blocks, tables,
    # diagrams, media) is embedded INLINE via window_create. Text flows naturally
    # around embeds. Everything is editable. Zero data loss (dump() reconstructs
    # raw markdown from text + _embed_raws lookup).
    # ============================================================

    def _render_sections(self, content):
        """v5.10: Render content into sections, each with ONE Text widget.
        Rich elements are embedded inline via window_create."""
        t = self.t
        self._imgs = []
        sections = self._parse_splits(content)
        sf = ScrollFrame(self.content_frame, t)
        sf.grid(row=0, column=0, sticky="nsew")
        inner = sf.inner
        for i, section in enumerate(sections):
            self._section_meta.append({
                "name": section.get("name", "Section"),
                "bg": section.get("bg", t.accent) or t.accent,
                "tags": section.get("tags", ""),
            })
            sec_frame = tk.Frame(inner, bg=t.bg)
            sec_frame.pack(fill="x", pady=(0, 4))
            # Section header bar (colored divider)
            is_intro = (i == 0 and section.get("name") == "Intro")
            if not is_intro:
                hdr_bg = section.get("bg", t.accent) or t.accent
                header = tk.Frame(sec_frame, bg=hdr_bg, height=30)
                header.pack(fill="x", pady=(12, 2))
                header.pack_propagate(False)
                hdr_text = f"  \u25C6  {section.get('name', 'Section')}  "
                if section.get("tags"):
                    hdr_text += f"  {section['tags']}"
                tk.Label(header, text=hdr_text, bg=hdr_bg, fg="#FFFFFF",
                         font=t.f(0, True)).pack(side="left", pady=5)
                x_btn = tk.Label(header, text="  \u2715  ", bg=hdr_bg, fg="#FFFFFF",
                                 font=t.f(0), cursor="hand2")
                x_btn.pack(side="right", pady=5)
                _sec_idx = len(self._section_meta) - 1
                x_btn.bind("<Button-1>", lambda e, idx=_sec_idx: self._delete_section(idx))
                # v5.10: right-click on header to resize section
                header.bind("<Button-3>", lambda e, idx=_sec_idx, w=None: self._section_header_menu(e, idx))
            # Section Text widget — one continuous editable document
            ed = tk.Text(sec_frame, bg=t.card, fg=t.fg, insertbackground=t.fg,
                         relief="flat", font=t.f(1), wrap="word", undo=True,
                         highlightthickness=1, highlightbackground=t.border,
                         highlightcolor=t.accent, padx=12, pady=12, spacing1=4, spacing3=4,
                         height=max(4, min(30, len(section.get("content","").split("\n")) + 2)))
            ed.pack(fill="both", expand=True, pady=2)
            # Configure formatting tags
            self._configure_text_tags(ed)
            # Render content with inline embeds
            self._render_section_content(ed, section.get("content", ""))
            # Bindings
            ed.bind("<KeyRelease>", lambda e, w=ed: (self._on_section_edit(w), self._apply_live_formatting(w), self._auto_fit_section_widget(w)))
            ed.bind("<FocusIn>", lambda e, w=ed: setattr(self, "editor", w))
            self._section_widgets.append(ed)
            # v5.10: auto-fit section height to content (after widgets are realized)
            self.after(200, lambda w=ed: self._auto_fit_section_widget(w))
        # Set self.editor to the first section widget
        if self._section_widgets:
            self.editor = self._section_widgets[0]
        # "+ Add Section" button at the bottom
        tk.Button(inner, text="+  Add Section (Split)", bg=t.accent, fg="#0E0E14",
                  relief="flat", font=t.f(0, True), cursor="hand2", padx=16, pady=8,
                  command=self._add_section).pack(fill="x", pady=10)

    def _configure_text_tags(self, widget):
        """v5.12: Configure markdown formatting tags on a Text widget.
        Full heading hierarchy (H1-H6), blockquote with left border, list bullets,
        task-list checkboxes, strikethrough, clickable links, block math, etc.
        Also wires up link click + hover bindings."""
        t = self.t
        # Headings — clear visual hierarchy. H1/H2 get extra top spacing.
        widget.tag_configure("h1", font=t.f(5, True), foreground=t.accent,
                             spacing1=14, spacing3=8)
        widget.tag_configure("h2", font=t.f(3, True), foreground=t.fg,
                             spacing1=12, spacing3=6)
        widget.tag_configure("h3", font=t.f(2, True), foreground=t.fg,
                             spacing1=10, spacing3=4)
        widget.tag_configure("h4", font=t.f(1, True), foreground=t.fg,
                             spacing1=8, spacing3=3)
        widget.tag_configure("h5", font=t.f(0, True), foreground=t.muted,
                             spacing1=6, spacing3=2)
        widget.tag_configure("h6", font=t.f(-1, True), foreground=t.muted,
                             spacing1=6, spacing3=2)
        # H1/H2 underline separator (a thin colored line below the heading)
        widget.tag_configure("h1_sep", foreground=t.accent, borderwidth=0,
                             spacing1=0, spacing3=2)
        widget.tag_configure("h2_sep", foreground=t.border, borderwidth=0,
                             spacing1=0, spacing3=2)
        # Inline formatting
        widget.tag_configure("bold", font=t.f(1, True))
        widget.tag_configure("italic", font=(t.font, t.fsize, "italic"))
        widget.tag_configure("bold_italic", font=(t.font, t.fsize + 1, "bold italic"))
        widget.tag_configure("strike", font=(t.font, t.fsize, "overstrike"))
        widget.tag_configure("code", font=("Consolas", t.fsize),
                             background="#0D0D14", foreground=t.success,
                             lmargin1=2, lmargin2=2, rmargin=2,
                             spacing1=1, spacing3=1)
        # Links — blue, underline, hover effect, clickable
        widget.tag_configure("link", foreground="#5AA8FF", underline=True)
        widget.tag_configure("link_hover", foreground="#8FC4FF", underline=True,
                             background=t.hover)
        # Wiki-links [[note]] — accent colored
        widget.tag_configure("wikilink", foreground=t.accent, underline=True)
        # Tags #word
        widget.tag_configure("tag", foreground=t.warn)
        # Blockquote — left border via 'lmargin1' + colored background tint.
        # Tk Text tags don't support real borders; we emulate with a thick
        # colored left margin and a slightly different background.
        widget.tag_configure("quote", foreground=t.muted,
                             lmargin1=24, lmargin2=24,
                             spacing1=4, spacing3=4,
                             background=t.hover,
                             font=(t.font, t.fsize, "italic"))
        widget.tag_configure("quote_marker", foreground=t.accent,
                             font=t.f(0, True))
        # Horizontal rule — full-width dim line
        widget.tag_configure("hr", foreground=t.border,
                             spacing1=8, spacing3=8,
                             overstrike=False)
        # Math
        widget.tag_configure("math", font=("Cambria Math", t.fsize + 1),
                             foreground=t.accent, background=t.hover)
        widget.tag_configure("math_block", font=("Cambria Math", t.fsize + 3),
                             foreground=t.accent, background=t.hover,
                             spacing1=8, spacing3=8, justify="center")
        # Lists — indentation handled per-level via lmargin
        widget.tag_configure("list_bullet", lmargin1=20, lmargin2=20,
                             spacing1=2, spacing3=2)
        widget.tag_configure("list_marker", foreground=t.muted,
                             font=t.f(0, True))
        widget.tag_configure("task_done", foreground=t.muted,
                             overstrike=True, lmargin1=20, lmargin2=20)
        widget.tag_configure("task_todo", lmargin1=20, lmargin2=20)
        widget.tag_configure("task_check", foreground=t.success,
                             font=t.f(0, True))
        # Markdown marker (de-emphasized #, >, -, etc.)
        widget.tag_configure("md_marker", foreground=t.dim, font=t.f(-2))
        # Safe-HTML inline tags rendered as their text equivalent
        widget.tag_configure("html_tag", foreground=t.dim,
                             font=("Consolas", max(8, t.fsize - 1)))
        # Paragraph spacing
        widget.tag_configure("para", spacing1=4, spacing3=6)

        # v5.12: Wire up link click + hover handlers (idempotent — Tk dedupes
        # identical bindings, and tag bindings are per-widget).
        widget.tag_bind("link", "<Button-1>", self._on_link_click)
        widget.tag_bind("link", "<Enter>", self._on_link_enter)
        widget.tag_bind("link", "<Leave>", self._on_link_leave)
        widget.tag_bind("wikilink", "<Button-1>", self._on_wikilink_click)
        widget.tag_bind("wikilink", "<Enter>", self._on_link_enter)
        widget.tag_bind("wikilink", "<Leave>", self._on_link_leave)

    # v5.12: link click / hover handlers
    def _on_link_click(self, e):
        """Open the URL under the cursor in the default browser."""
        try:
            w = e.widget
            # Get the index range of the clicked 'link' tag
            cur = w.index("current")
            # Walk back to find the start of the link tag run
            ranges = w.tag_ranges("link")
            url = None
            # ranges is a tuple of (start, end, start, end, ...)
            for i in range(0, len(ranges), 2):
                if str(ranges[i]) <= cur <= str(ranges[i + 1]):
                    url = w.get(ranges[i], ranges[i + 1])
                    break
            if not url:
                # Fall back to current line text
                url = w.get("current linestart", "current lineend")
                m = re.search(r'(https?://[^\s)]+)', url)
                url = m.group(1) if m else None
            if not url:
                return
            # If it's [text](url) form, the visible text is just 'text' —
            # so also scan the line for the underlying URL.
            line = w.get("current linestart", "current lineend")
            m = re.search(r'\[([^\]]+)\]\(([^)]+)\)', line)
            if m:
                # Check if the click is within the [text] part
                text_start = m.start(1)
                text_end = m.end(2) + 1  # include the (url)
                cur_col = int(cur.split(".")[1])
                if m.start(1) <= cur_col <= m.end(1):
                    url = m.group(2)
            # Strip surrounding markdown
            url = url.strip()
            if url.startswith("[") and "](" in url:
                url = url.split("](")[1].rstrip(")")
            if url and (url.startswith("http://") or url.startswith("https://")
                        or url.startswith("file://") or url.startswith("www.")):
                if url.startswith("www."):
                    url = "https://" + url
                import webbrowser
                webbrowser.open(url)
        except Exception:
            pass

    def _on_wikilink_click(self, e):
        """Open the note named by [[wikilink]] if it exists."""
        try:
            w = e.widget
            cur = w.index("current")
            ranges = w.tag_ranges("wikilink")
            for i in range(0, len(ranges), 2):
                if str(ranges[i]) <= cur <= str(ranges[i + 1]):
                    text = w.get(ranges[i], ranges[i + 1])
                    # Strip [[ ]]
                    name = text.strip().lstrip("[").rstrip("]").strip()
                    note = self.d.get_note_by_title(name) if hasattr(self, "d") else None
                    if note:
                        self._select(note["id"])
                    else:
                        messagebox.showinfo("Note not found",
                                            f"No note named '{name}'.")
                    return
        except Exception:
            pass

    def _on_link_enter(self, e):
        try: e.widget.tag_add("link_hover", "current")
        except: pass

    def _on_link_leave(self, e):
        try: e.widget.tag_remove("link_hover", "1.0", "end")
        except: pass

    def _render_section_content(self, widget, content):
        """v5.10: Render markdown into a Text widget. Raw markdown text is KEPT (markers
        visible but styled) with formatting tags applied on top via _apply_live_formatting.
        Rich elements (code, tables, diagrams) embedded via window_create.
        Images/audio/video embedded inline via window_create.
        This preserves the raw markdown in the widget text so save has zero data loss."""
        t = self.t
        widget.delete("1.0", "end")
        lines = content.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            # Code block / diagram (block-level embed)
            if stripped.startswith("```"):
                lang_full = stripped[3:].strip()
                size = None
                if "|" in lang_full:
                    parts = lang_full.split("|", 1)
                    lang = parts[0].strip()
                    try: size = int(parts[1].strip())
                    except: size = None
                else:
                    lang = lang_full
                code_lines = []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    code_lines.append(lines[i]); i += 1
                i += 1  # skip closing ```
                code = "\n".join(code_lines)
                widget.insert("end", "\n")
                if lang in ("diagram", "flowchart", "mermaid"):
                    self._embed_diagram(widget, code, size=size)
                else:
                    self._embed_code_block(widget, lang, code, size=size)
                widget.insert("end", "\n")
                continue
            # Table (block-level embed)
            if stripped.startswith("|") and i+1 < len(lines) and "---" in lines[i+1]:
                table_lines = []
                while i < len(lines) and lines[i].strip().startswith("|"):
                    table_lines.append(lines[i]); i += 1
                widget.insert("end", "\n")
                self._embed_table(widget, table_lines)
                widget.insert("end", "\n")
                continue
            # Regular text line — insert RAW markdown text (markers kept).
            # Formatting tags applied after by _apply_live_formatting.
            # If line contains images/audio/video, embed them inline.
            if re.search(r'(!\[[^\]]*\]\([^)]+\)|\{+audio:[^}]+\}+|\{+video:[^}]+\}+)', stripped):
                self._render_line_with_embeds(widget, line)
                widget.insert("end", "\n")
            else:
                widget.insert("end", line + "\n")
            i += 1
        # Apply live formatting tags to all text
        self._apply_live_formatting(widget)

    def _render_line_with_embeds(self, widget, line):
        """v5.10: Render a line with inline images/audio/video. Text parts are inserted
        RAW (markers visible) — formatting tags applied later by _apply_live_formatting."""
        embed_pattern = re.compile(r'(!\[[^\]]*\]\([^)]+\)|\{+audio:[^}]+\}+|\{+video:[^}]+\}+)')
        parts = embed_pattern.split(line)
        for part in parts:
            if not part: continue
            if part.startswith("!["):
                im = re.match(r'!\[([^\]]*)\]\(([^)]+)\)', part)
                if im:
                    alt_full = im.group(1)
                    path = im.group(2)
                    img_size = None
                    alt = alt_full
                    if "|" in alt_full:
                        p = alt_full.split("|", 1)
                        alt = p[0].strip()
                        try: img_size = int(p[1].strip())
                        except: img_size = None
                    self._embed_image(widget, path, alt, size=img_size)
                else:
                    widget.insert("end", part)
            elif part.startswith("{audio:") or part.startswith("{{audio:"):
                am = re.match(r'\{+audio:([^}]+)\}+', part)
                if am:
                    self._embed_media(widget, "audio", am.group(1))
                else:
                    widget.insert("end", part)
            elif part.startswith("{video:") or part.startswith("{{video:"):
                vm = re.match(r'\{+video:([^}]+)\}+', part)
                if vm:
                    self._embed_media(widget, "video", vm.group(1))
                else:
                    widget.insert("end", part)
            else:
                # Insert raw text — tags applied by _apply_live_formatting
                widget.insert("end", part)

    _live_fmt_timer = None

    def _apply_live_formatting(self, widget):
        """v5.12: Apply formatting tags to raw markdown text in the widget.
        Tags don't modify text content — just visual styling on top.
        Handles: H1-H6 (with H1/H2 separator), bold, italic, bold-italic,
        strikethrough, inline code, [[wikilinks]], [text](url) links, bare URLs,
        #tags, $inline math$, $$block math$$, > blockquotes, ---/***/___ HR,
        unordered/ordered/nested/task lists, safe HTML subset.
        Debounced to reduce flicker while typing."""
        # v5.12: debounce — coalesce rapid KeyRelease events into one pass.
        # We keep the debounce per-instance (single _live_fmt_timer).
        if hasattr(self, "_live_fmt_timer") and self._live_fmt_timer:
            try: self._live_fmt_timer.cancel()
            except: pass
        import threading as _th
        def _do():
            try:
                if widget.winfo_exists():
                    self.after(0, lambda: self._apply_live_formatting_now(widget))
            except: pass
        self._live_fmt_timer = _th.Timer(0.05, _do)
        self._live_fmt_timer.start()

    def _apply_live_formatting_now(self, widget):
        """Actual formatting pass — runs on the UI thread, debounced."""
        t = self.t
        # Remove old format tags (v5.12: extended set)
        for tag in ("h1", "h2", "h3", "h4", "h5", "h6",
                    "h1_sep", "h2_sep",
                    "bold", "italic", "bold_italic", "strike", "code",
                    "link", "wikilink", "tag",
                    "quote", "quote_marker",
                    "hr", "math", "math_block",
                    "list_bullet", "list_marker",
                    "task_done", "task_todo", "task_check",
                    "md_marker", "html_tag", "para"):
            widget.tag_remove(tag, "1.0", "end")
        # Get total lines
        try:
            end_line = int(widget.index("end-1c").split(".")[0])
        except: return
        # First pass: detect block-math $$...$$ regions (so we don't double-tag)
        block_math_lines = set()
        i = 1
        while i <= end_line:
            line_text = widget.get(f"{i}.0", f"{i}.end")
            stripped = line_text.strip()
            if stripped == "$$" or stripped.startswith("$$") and stripped.endswith("$$") and len(stripped) > 4:
                # Single-line $$...$$ block
                if stripped.startswith("$$") and stripped.endswith("$$") and len(stripped) > 4:
                    widget.tag_add("md_marker", f"{i}.0", f"{i}.2")
                    widget.tag_add("md_marker", f"{i}.end-2", f"{i}.end")
                    widget.tag_add("math_block", f"{i}.2", f"{i}.end-2")
                    block_math_lines.add(i)
                    i += 1; continue
                # Multi-line: $$ on its own line, find closing $$
                start_line = i
                j = i + 1
                while j <= end_line:
                    if widget.get(f"{j}.0", f"{j}.end").strip() == "$$":
                        break
                    j += 1
                if j <= end_line:
                    # Mark opening + closing $$ as markers
                    widget.tag_add("md_marker", f"{start_line}.0", f"{start_line}.end")
                    widget.tag_add("md_marker", f"{j}.0", f"{j}.end")
                    # Mark inner lines as math_block
                    for k in range(start_line + 1, j):
                        widget.tag_add("math_block", f"{k}.0", f"{k}.end")
                        block_math_lines.add(k)
                    block_math_lines.add(start_line); block_math_lines.add(j)
                    i = j + 1; continue
            i += 1

        # Second pass: block-level tags (per line) + inline tags
        for ln in range(1, end_line + 1):
            if ln in block_math_lines: continue  # already tagged
            line_text = widget.get(f"{ln}.0", f"{ln}.end")
            stripped = line_text.strip()
            if not stripped:
                continue  # skip blank lines (no tags needed)
            # Headings — count leading #
            if re.match(r'^#{1,6}\s', line_text):
                m = re.match(r'^(#{1,6})\s+(.*)$', line_text)
                if m:
                    level = len(m.group(1))
                    head_text = m.group(2)
                    tag_name = f"h{level}"
                    marker_end = len(m.group(1)) + 1  # "# " length
                    widget.tag_add("md_marker", f"{ln}.0", f"{ln}.{marker_end}")
                    widget.tag_add(tag_name, f"{ln}.{marker_end}", f"{ln}.end")
                    # H1/H2 separator: we can't draw a real line below, but we
                    # add a faint overstrike on the heading's trailing newline
                    # via spacing3 (already set on the tag). For a visible
                    # separator, we'd need to insert an actual hr line — but
                    # that would change the raw markdown. So we rely on the
                    # larger spacing3 + accent color to convey hierarchy.
                    continue
            # Horizontal rules: ---, ***, ___ (3+ chars, only that on the line)
            if re.match(r'^(-{3,}|\*{3,}|_{3,})$', stripped):
                widget.tag_add("hr", f"{ln}.0", f"{ln}.end")
                # Replace visual with a long dash line via tag (text stays raw)
                continue
            # Blockquote: > text  (also >> nested, etc.)
            qm = re.match(r'^(\s*)(>+)\s?(.*)$', line_text)
            if qm:
                marker_end = len(qm.group(1)) + len(qm.group(2)) + 1
                widget.tag_add("md_marker", f"{ln}.0", f"{ln}.{marker_end}")
                widget.tag_add("quote", f"{ln}.{marker_end}", f"{ln}.end")
                continue
            # Task list: - [x] or - [ ] (and * / + prefixes)
            tm = re.match(r'^(\s*)([-*+])\s+\[([ xX])\]\s+(.*)$', line_text)
            if tm:
                indent = len(tm.group(1))
                marker_start = indent
                marker_end = indent + 2  # "- "
                box_start = marker_end
                box_end = box_start + 3  # "[x]" or "[ ]"
                text_start = box_end + 1
                widget.tag_add("md_marker", f"{ln}.{marker_start}", f"{ln}.{marker_end}")
                widget.tag_add("task_check", f"{ln}.{box_start}", f"{ln}.{box_end}")
                if tm.group(3).lower() == "x":
                    widget.tag_add("task_done", f"{ln}.{text_start}", f"{ln}.end")
                else:
                    widget.tag_add("task_todo", f"{ln}.{text_start}", f"{ln}.end")
                # Still process inline formatting on the task text below
            # Unordered list: -, *, + (with optional indent)
            elif re.match(r'^(\s*)([-*+])\s+', line_text):
                lm = re.match(r'^(\s*)([-*+])\s+(.*)$', line_text)
                indent = len(lm.group(1))
                marker_end = indent + 2
                widget.tag_add("md_marker", f"{ln}.0", f"{ln}.{marker_end}")
                widget.tag_add("list_bullet", f"{ln}.{marker_end}", f"{ln}.end")
            # Ordered list: 1. 2. etc.
            elif re.match(r'^(\s*)(\d+\.)\s+', line_text):
                lm = re.match(r'^(\s*)(\d+\.)\s+(.*)$', line_text)
                indent = len(lm.group(1))
                marker_end = indent + len(lm.group(2)) + 1
                widget.tag_add("md_marker", f"{ln}.0", f"{ln}.{marker_end}")
                widget.tag_add("list_bullet", f"{ln}.{marker_end}", f"{ln}.end")

        # Third pass: inline tags — walk dump for text segments.
        # We process inline tags on ALL lines except block-math lines.
        for kind, value, index in widget.dump("1.0", "end-1c"):
            if kind != "text": continue
            start_line = int(index.split(".")[0])
            start_col = int(index.split(".")[1])
            if start_line in block_math_lines: continue
            lines_in_seg = value.split("\n")
            for offset, seg_line in enumerate(lines_in_seg):
                ln = start_line + offset
                if ln in block_math_lines: continue
                col = start_col if offset == 0 else 0
                if not seg_line: continue
                # Bold-italic: ***text***  (must be checked before ** and *)
                for m in re.finditer(r'\*\*\*([^*]+)\*\*\*', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("bold_italic", f"{ln}.{s}", f"{ln}.{e}")
                    # Also tag the inner text (without markers) with bold+italic
                    inner_s = s + 3; inner_e = e - 3
                    widget.tag_add("bold", f"{ln}.{inner_s}", f"{ln}.{inner_e}")
                    widget.tag_add("italic", f"{ln}.{inner_s}", f"{ln}.{inner_e}")
                # Bold: **text**  (skip if part of ***text***)
                for m in re.finditer(r'(?<!\*)\*\*([^*]+)\*\*(?!\*)', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("bold", f"{ln}.{s}", f"{ln}.{e}")
                # Italic: *text*  (not **)
                for m in re.finditer(r'(?<!\*)\*([^*]+)\*(?!\*)', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("italic", f"{ln}.{s}", f"{ln}.{e}")
                # Strikethrough: ~~text~~
                for m in re.finditer(r'~~([^~]+)~~', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("strike", f"{ln}.{s}", f"{ln}.{e}")
                # Inline code: `text`
                for m in re.finditer(r'`([^`]+)`', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("code", f"{ln}.{s}", f"{ln}.{e}")
                # Wiki-links: [[text]]
                for m in re.finditer(r'\[\[([^\]]+)\]\]', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("wikilink", f"{ln}.{s}", f"{ln}.{e}")
                # Markdown links: [text](url)  — tag the [text] part as link
                for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)', seg_line):
                    s = col + m.start(); e = col + m.end()
                    # Tag the whole [text](url) span as link, so clicks anywhere
                    # in the visible text open the URL. The URL part is hidden
                    # by the small font on the md_marker? No — it's all visible.
                    # Better: tag just the [text] portion (without brackets) as
                    # link, and leave (url) as plain text. Users can still click
                    # the text to open the URL.
                    text_s = col + m.start(1)
                    text_e = col + m.end(1)
                    widget.tag_add("link", f"{ln}.{text_s}", f"{ln}.{text_e}")
                    # Store URL in a per-tag data attribute via tag_lower is not
                    # possible in Tk; the click handler re-parses the line.
                # Bare URLs: https://... or http://... or www....
                for m in re.finditer(r'(?:https?://|www\.)[^\s)]+', seg_line):
                    s = col + m.start(); e = col + m.end()
                    # Don't double-tag if already inside a [text](url) link
                    existing = widget.tag_names(f"{ln}.{s}")
                    if "link" not in existing:
                        widget.tag_add("link", f"{ln}.{s}", f"{ln}.{e}")
                # Tags: #word  (but not inside code blocks or URLs)
                for m in re.finditer(r'#([A-Za-z_][\w-]*)', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("tag", f"{ln}.{s}", f"{ln}.{e}")
                # Inline math: $...$  (not $$, not block-math)
                for m in re.finditer(r'(?<!\$)\$([^$\n]+)\$(?!\$)', seg_line):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("math", f"{ln}.{s}", f"{ln}.{e}")
                # Safe HTML inline tags: <b>, </b>, <i>, </i>, <u>, </u>,
                # <em>, </em>, <strong>, </strong>, <br>, <br/>, <hr>, <hr/>
                for m in re.finditer(r'</?(?:b|i|u|em|strong|br|hr)\s*/?>', seg_line, re.IGNORECASE):
                    s = col + m.start(); e = col + m.end()
                    widget.tag_add("html_tag", f"{ln}.{s}", f"{ln}.{e}")

    def _embed_image(self, widget, path, alt, at="end", size=None):
        """Embed an image inline. size = width in px (optional)."""
        t = self.t
        frame = tk.Frame(widget, bg=t.card)
        img_label = None
        if os.path.exists(path) and HAS_PIL:
            try:
                img = Image.open(path)
                max_w = 500
                target_w = size if size else min(img.width, max_w)
                if img.width > target_w or size:
                    ratio = target_w / img.width
                    img = img.resize((target_w, int(img.height * ratio)), Image.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self._imgs.append(photo)
                img_label = tk.Label(frame, image=photo, bg=t.card)
                img_label.pack(pady=2)
                if alt:
                    tk.Label(frame, text=alt, bg=t.card, fg=t.muted, font=t.f(-1)).pack()
            except:
                tk.Label(frame, text=f"[Image: {path}]", bg=t.card, fg=t.muted, font=t.f(0)).pack(pady=4)
        else:
            tk.Label(frame, text=f"[Image: {path}]", bg=t.card, fg=t.muted, font=t.f(0)).pack(pady=4)
        widget.window_create(at, window=frame)
        # v5.10: store raw with size if set
        raw = f"![{alt}|{size}]({path})" if size else f"![{alt}]({path})"
        self._embed_raws[str(frame)] = raw
        self._embed_widgets.append(frame)
        # v5.10: right-click context menu for resize / move / delete
        self._bind_sticker_menu(frame, widget, "image", {"path": path, "alt": alt, "size": size})

    def _embed_code_block(self, widget, lang, code, at="end", size=None):
        """Embed a code block (header + Run/Copy + editable code) inline. size = height in lines."""
        t = self.t
        frame = tk.Frame(widget, bg=t.card)
        hdr = tk.Frame(frame, bg=t.hover)
        hdr.pack(fill="x")
        tk.Label(hdr, text=f" [{lang or 'code'}] ", bg=t.hover, fg=t.warn,
                 font=t.f(-1, True)).pack(side="left", padx=8, pady=4)
        if lang in ("python", "py", "html", "js", "javascript", "css"):
            def run():
                self._run_block(code_text.get("1.0", "end-1c"), lang)
            tk.Button(hdr, text=f"Run {lang}", bg=t.accent, fg="#0E0E14", relief="flat",
                      font=t.f(-1, True), cursor="hand2", padx=8, pady=2, command=run).pack(side="right", padx=4)
            def cp():
                self.clipboard_clear(); self.clipboard_append(code_text.get("1.0", "end-1c"))
            tk.Button(hdr, text="Copy", bg=t.card, fg=t.fg, relief="flat", font=t.f(-1),
                      cursor="hand2", padx=8, pady=2, command=cp).pack(side="right", padx=2)
        # v5.10: use size for height if provided
        h = size if size else max(3, min(20, len(code.split("\n")) + 1))
        code_text = tk.Text(frame, bg="#0D0D14", fg=t.success, relief="flat",
                            font=("Consolas", t.fsize), wrap="word", padx=12, pady=10,
                            height=h,
                            insertbackground=t.success, highlightthickness=1,
                            highlightbackground=t.border, highlightcolor=t.accent)
        code_text.pack(fill="x")
        code_text.insert("1.0", code)
        def on_code_edit():
            new_code = code_text.get("1.0", "end-1c")
            self._embed_raws[str(frame)] = f"```{lang}|{h}\n{new_code}\n```" if size else f"```{lang}\n{new_code}\n```"
            self._on_content()
        code_text.bind("<KeyRelease>", lambda e: on_code_edit())
        widget.window_create(at, window=frame)
        self._embed_raws[str(frame)] = f"```{lang}|{size}\n{code}\n```" if size else f"```{lang}\n{code}\n```"
        self._embed_widgets.append(frame)
        self._bind_sticker_menu(frame, widget, "code", {"lang": lang, "size": size, "code_text": code_text})

    def _embed_table(self, widget, table_lines, at="end"):
        """v5.10: Embed an EDITABLE table with Entry widgets. Cells are editable inline.
        Add/remove rows and columns with buttons. Right-click a cell for color."""
        t = self.t
        frame = tk.Frame(widget, bg=t.card)
        hdr = tk.Frame(frame, bg=t.hover)
        hdr.pack(fill="x")
        tk.Label(hdr, text=" [table] ", bg=t.hover, fg=t.warn,
                 font=t.f(-1, True)).pack(side="left", padx=8, pady=4)
        table_state = {"lines": list(table_lines), "cell_colors": {}}
        grid_frame = tk.Frame(frame, bg=t.card)
        grid_frame.pack(fill="x", padx=4, pady=4)
        entries = []  # 2D list of Entry widgets

        def parse_lines(lines):
            rows = []
            for line in lines:
                if "---" in line: continue
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                rows.append(cells)
            return rows

        def rebuild_lines(rows):
            if not rows: return []
            n_cols = len(rows[0])
            result = ["| " + " | ".join(rows[0]) + " |"]
            result.append("| " + " | ".join("---" for _ in range(n_cols)) + " |")
            for row in rows[1:]:
                # Pad row to n_cols
                while len(row) < n_cols: row.append("")
                result.append("| " + " | ".join(row[:n_cols]) + " |")
            return result

        def update_raw():
            table_state["lines"] = rebuild_lines(parse_lines(table_state["lines"]))
            self._embed_raws[str(frame)] = "\n".join(table_state["lines"])
            self._on_content()

        def render_grid():
            for w in grid_frame.winfo_children(): w.destroy()
            entries.clear()
            rows = parse_lines(table_state["lines"])
            if not rows: return
            for r in range(len(rows)):
                row_entries = []
                for c in range(len(rows[r])):
                    e = tk.Entry(grid_frame, bg=t.card, fg=t.fg, insertbackground=t.fg,
                                relief="flat", font=t.f(-1), width=12,
                                highlightthickness=1, highlightbackground=t.border,
                                highlightcolor=t.accent, justify="center")
                    e.grid(row=r, column=c, padx=1, pady=1, sticky="ew")
                    e.insert(0, rows[r][c])
                    # Apply cell color if set
                    color_key = f"{r},{c}"
                    if color_key in table_state.get("cell_colors", {}):
                        e.configure(bg=table_state["cell_colors"][color_key])
                    # Right-click for color
                    e.bind("<Button-3>", lambda ev, rr=r, cc=c: self._table_cell_color(ev, rr, cc, table_state, render_grid))
                    # Update on edit
                    def on_edit(ev, rr=r, cc=c):
                        rows = parse_lines(table_state["lines"])
                        if rr < len(rows) and cc < len(rows[rr]):
                            rows[rr][cc] = ev.widget.get()
                            table_state["lines"] = rebuild_lines(rows)
                            self._embed_raws[str(frame)] = "\n".join(table_state["lines"])
                            self._on_content()
                    e.bind("<KeyRelease>", on_edit)
                    row_entries.append(e)
                entries.append(row_entries)
            # Make columns expand
            for c in range(len(rows[0]) if rows else 0):
                grid_frame.columnconfigure(c, weight=1)

        def add_row():
            rows = parse_lines(table_state["lines"])
            if not rows: return
            n_cols = len(rows[0])
            rows.append(["" for _ in range(n_cols)])
            table_state["lines"] = rebuild_lines(rows)
            render_grid()
            update_raw()

        def add_col():
            rows = parse_lines(table_state["lines"])
            for row in rows:
                row.append("")
            table_state["lines"] = rebuild_lines(rows)
            render_grid()
            update_raw()

        def del_row():
            rows = parse_lines(table_state["lines"])
            if len(rows) > 1:
                rows.pop()
                table_state["lines"] = rebuild_lines(rows)
                render_grid()
                update_raw()

        def del_col():
            rows = parse_lines(table_state["lines"])
            if rows and len(rows[0]) > 1:
                for row in rows:
                    row.pop()
                table_state["lines"] = rebuild_lines(rows)
                render_grid()
                update_raw()

        render_grid()
        # Add/remove row/col buttons
        btn_frame = tk.Frame(frame, bg=t.card)
        btn_frame.pack(fill="x", pady=2)
        for label, cmd, bg, fg in [("+ Row", add_row, t.accent, "#0E0E14"),
                                     ("+ Col", add_col, t.accent, "#0E0E14"),
                                     ("- Row", del_row, t.card, t.fg),
                                     ("- Col", del_col, t.card, t.fg)]:
            tk.Button(btn_frame, text=label, bg=bg, fg=fg, relief="flat", font=t.f(-1, True),
                      cursor="hand2", padx=8, pady=2, command=cmd).pack(side="left", padx=2)
        widget.window_create(at, window=frame)
        self._embed_raws[str(frame)] = "\n".join(table_lines)
        self._embed_widgets.append(frame)
        self._bind_sticker_menu(frame, widget, "table", {})

    def _table_cell_color(self, e, r, c, table_state, render_grid):
        """v5.10: Right-click a table cell to set its background color."""
        menu = tk.Menu(self, tearoff=0, bg=self.t.card, fg=self.t.fg,
                      activebackground=self.t.hover, activeforeground=self.t.fg,
                      font=self.t.f(0), borderwidth=0)
        def set_color():
            color = colorchooser.askcolor(e.widget["bg"])[1]
            if color:
                if "cell_colors" not in table_state:
                    table_state["cell_colors"] = {}
                table_state["cell_colors"][f"{r},{c}"] = color
                render_grid()
        def reset_color():
            if "cell_colors" in table_state:
                table_state["cell_colors"].pop(f"{r},{c}", None)
                render_grid()
        menu.add_command(label="Set cell color...", command=set_color)
        menu.add_command(label="Reset cell color", command=reset_color)
        try: menu.tk_popup(e.x_root, e.y_root)
        finally: menu.grab_release()

    def _embed_diagram(self, widget, code, at="end", size=None):
        """v5.12: Embed a diagram as a TRUE LIVE EDITOR.
        The canvas is the primary view. The source-code editor is HIDDEN by
        default — click the canvas (or the 'Edit' chip in the header) to
        reveal an inline editor; the diagram re-renders on every keystroke.
        Clicking outside the editor (or pressing Escape) collapses it again.
        No permanent duplicate raw-text widget below the canvas."""
        t = self.t
        frame = tk.Frame(widget, bg=t.card)
        # Header with 'Edit' toggle chip
        hdr = tk.Frame(frame, bg=t.hover)
        hdr.pack(fill="x")
        tk.Label(hdr, text=" [diagram] ", bg=t.hover, fg=t.warn,
                 font=t.f(-1, True)).pack(side="left", padx=8, pady=4)
        # The 'Edit' chip — clicking toggles the source editor
        edit_chip = tk.Label(hdr, text=" \u270E Edit ", bg=t.accent, fg="#0E0E14",
                             font=t.f(-1, True), cursor="hand2", padx=8, pady=2)
        edit_chip.pack(side="right", padx=4, pady=4)
        # Canvas — the primary rendered view
        cv = tk.Canvas(frame, bg=t.card, highlightthickness=1,
                       highlightbackground=t.border, cursor="hand2")
        cv.pack(fill="x", pady=2)
        diagram_state = {"code": code, "cv": cv, "size": size,
                         "editor_visible": False}
        def re_render():
            cv.delete("all")
            self._draw_diagram_on_canvas(cv, diagram_state["code"],
                                         width=diagram_state.get("size"))
        re_render()

        # Hidden source editor — packed only when toggled on.
        code_editor = tk.Text(frame, bg="#0D0D14", fg=t.success, relief="flat",
                              font=("Consolas", 10), wrap="word", padx=8, pady=6,
                              height=6, insertbackground=t.success,
                              highlightthickness=1, highlightbackground=t.border,
                              highlightcolor=t.accent)
        code_editor.insert("1.0", code)

        def sync_raw():
            sz = diagram_state.get("size")
            if sz:
                self._embed_raws[str(frame)] = f"```diagram|{sz}\n{diagram_state['code']}\n```"
            else:
                self._embed_raws[str(frame)] = f"```diagram\n{diagram_state['code']}\n```"

        def show_editor():
            if diagram_state["editor_visible"]: return
            diagram_state["editor_visible"] = True
            code_editor.pack(fill="x", pady=(2, 0))
            edit_chip.configure(text=" \u2715 Close ", bg=t.danger, fg="#FFFFFF")
            try: code_editor.focus_set()
            except: pass

        def hide_editor():
            if not diagram_state["editor_visible"]: return
            diagram_state["editor_visible"] = False
            code_editor.pack_forget()
            edit_chip.configure(text=" \u270E Edit ", bg=t.accent, fg="#0E0E14")
            # Re-render once more in case the user edited text but didn't trigger KeyRelease
            diagram_state["code"] = code_editor.get("1.0", "end-1c")
            re_render()
            sync_raw()
            self._on_content()

        def toggle_editor(_e=None):
            if diagram_state["editor_visible"]: hide_editor()
            else: show_editor()

        edit_chip.bind("<Button-1>", toggle_editor)
        # Clicking the canvas also reveals the editor (feels like editing one object)
        cv.bind("<Button-1>", lambda e: show_editor() if not diagram_state["editor_visible"] else None)
        # Escape collapses the editor
        code_editor.bind("<Escape>", lambda e: hide_editor())
        # Live re-render on every keystroke
        def on_code_edit(_e=None):
            diagram_state["code"] = code_editor.get("1.0", "end-1c")
            re_render()
            sync_raw()
            self._on_content()
        code_editor.bind("<KeyRelease>", on_code_edit)

        widget.window_create(at, window=frame)
        sync_raw()
        self._embed_widgets.append(frame)
        self._bind_sticker_menu(frame, widget, "diagram",
                                {"state": diagram_state, "re_render": re_render})

    def _draw_diagram_on_canvas(self, cv, code, width=None):
        """Draw a flowchart diagram on a Canvas. width = optional canvas width override."""
        t = self.t
        try:
            edges = []; nodes = {}
            for line in code.split("\n"):
                line = line.strip()
                if not line or line.startswith("#"): continue
                m = re.match(r'^(\w[\w \-]*?)\s*(-->|->|---|-\.|==>)\s*(?:\|([^|]+)\|\s*)?(\w[\w \-]*)$', line)
                if m:
                    src = m.group(1).strip(); dst = m.group(4).strip()
                    label = (m.group(3) or "").strip()
                    if src not in nodes: nodes[src] = {"name": src}
                    if dst not in nodes: nodes[dst] = {"name": dst}
                    edges.append((src, dst, label))
                elif line and line not in nodes:
                    nodes[line] = {"name": line}
            if not nodes:
                cv.configure(width=200, height=40)
                cv.create_text(100, 20, text="[Empty diagram]", fill=t.muted, font=t.f(0))
                return
            node_list = list(nodes.keys())
            n = len(node_list)
            # v5.10: if width is specified, scale cell_w to fit
            if width:
                cols = max(1, int(math.ceil(math.sqrt(n))))
                rows = max(1, int(math.ceil(n / cols)))
                cell_h = 60
                pad = 20
                cell_w = max(80, (width - pad * 2) // max(cols, 1))
                cw = width
                ch = rows * cell_h + pad * 2
            else:
                cols = max(1, int(math.ceil(math.sqrt(n))))
                rows = max(1, int(math.ceil(n / cols)))
                cell_w, cell_h = 130, 60
                pad = 30
                cw = cols * cell_w + pad * 2
                ch = rows * cell_h + pad * 2
            cv.configure(width=cw, height=ch)
            for idx, name in enumerate(node_list):
                r = idx // cols; c = idx % cols
                x = pad + c * cell_w + cell_w // 2
                y = pad + r * cell_h + cell_h // 2
                nodes[name]["pos"] = (x, y)
            for src, dst, label in edges:
                if src in nodes and dst in nodes:
                    x1, y1 = nodes[src]["pos"]; x2, y2 = nodes[dst]["pos"]
                    cv.create_line(x1, y1, x2, y2, fill=t.muted, width=2, arrow="last")
                    if label:
                        mx, my = (x1 + x2) // 2, (y1 + y2) // 2
                        cv.create_text(mx, my - 8, text=label, fill=t.warn, font=t.f(-2))
            for name, info in nodes.items():
                x, y = info["pos"]
                w = max(60, len(name) * 8 + 16)
                cv.create_rectangle(x - w//2, y - 16, x + w//2, y + 16,
                                    fill=t.hover, outline=t.accent, width=2)
                cv.create_text(x, y, text=name, fill=t.fg, font=t.f(-1, True))
        except: pass

    def _embed_media(self, widget, mtype, path, at="end"):
        """Embed audio/video inline with a Play button."""
        t = self.t
        frame = tk.Frame(widget, bg=t.hover, padx=12, pady=8)
        icon = "\u25B6" if mtype == "video" else "\u266A"
        tk.Label(frame, text=f" {icon} {mtype.title()}: {os.path.basename(path)}",
                 bg=t.hover, fg=t.fg, font=t.f(0)).pack(side="left")
        if not os.path.exists(path):
            tk.Label(frame, text=" (file not found)", bg=t.hover, fg=t.danger,
                     font=t.f(-1)).pack(side="left")
        def play():
            try: os.startfile(path)
            except Exception as e: messagebox.showerror("Error", str(e))
        tk.Button(frame, text="Play", bg=t.accent, fg="#0E0E14", relief="flat",
                  font=t.f(-1, True), cursor="hand2", padx=16, pady=4,
                  command=play).pack(side="right", padx=4)
        widget.window_create(at, window=frame)
        self._embed_raws[str(frame)] = f"{{{mtype}:{path}}}"
        self._embed_widgets.append(frame)
        self._bind_sticker_menu(frame, widget, "media", {})

    # ----------------------------------------------------------------
    # v5.10: Sticker context menu (resize / move / delete)
    # ----------------------------------------------------------------
    def _bind_sticker_menu(self, frame, parent_widget, sticker_type, extra):
        """Bind a right-click context menu to an embedded sticker frame."""
        def on_right_click(e):
            menu = tk.Menu(self, tearoff=0, bg=self.t.card, fg=self.t.fg,
                          activebackground=self.t.hover, activeforeground=self.t.fg,
                          font=self.t.f(0), borderwidth=0)
            if sticker_type == "image":
                menu.add_command(label="Resize...", command=lambda: self._resize_image(frame, parent_widget, extra))
            elif sticker_type == "code":
                menu.add_command(label="Resize...", command=lambda: self._resize_code(frame, parent_widget, extra))
            elif sticker_type == "diagram":
                menu.add_command(label="Resize...", command=lambda: self._resize_diagram(frame, parent_widget, extra))
            menu.add_separator()
            menu.add_command(label="Delete", command=lambda: self._delete_sticker(frame, parent_widget))
            try: menu.tk_popup(e.x_root, e.y_root)
            finally: menu.grab_release()
        frame.bind("<Button-3>", on_right_click)
        for child in frame.winfo_children():
            child.bind("<Button-3>", on_right_click)
            for grandchild in child.winfo_children():
                grandchild.bind("<Button-3>", on_right_click)

    def _resize_image(self, frame, parent_widget, extra):
        """Resize an image sticker — ask for width in px."""
        cur = extra.get("size") or 500
        val = simpledialog.askinteger("Resize Image", "Width in pixels:", parent=self,
                                      initialvalue=cur, minvalue=50, maxvalue=2000)
        if not val: return
        # Update the raw markdown with the new size and re-render
        raw = self._embed_raws.get(str(frame), "")
        m = re.match(r'!\[([^\]]*)\](?:\|(\d+))?\(([^)]+)\)', raw)
        if m:
            alt = m.group(1)
            path = m.group(3)
            self._embed_raws[str(frame)] = f"![{alt}|{val}]({path})"
            self._rerender_section_with_sticker_change(parent_widget)

    def _resize_code(self, frame, parent_widget, extra):
        """Resize a code sticker — ask for height in lines."""
        cur = extra.get("size") or extra["code_text"].cget("height")
        val = simpledialog.askinteger("Resize Code Block", "Height (lines):", parent=self,
                                      initialvalue=cur, minvalue=3, maxvalue=60)
        if not val: return
        # Update the raw markdown with the new size and re-render
        raw = self._embed_raws.get(str(frame), "")
        m = re.match(r'```(\w+)(?:\|(\d+))?\n(.*)```', raw, re.DOTALL)
        if m:
            lang = m.group(1)
            code = m.group(3)
            self._embed_raws[str(frame)] = f"```{lang}|{val}\n{code}```"
            self._rerender_section_with_sticker_change(parent_widget)

    def _resize_diagram(self, frame, parent_widget, extra):
        """Resize a diagram sticker — ask for width in px."""
        state = extra.get("state", {})
        cur = state.get("size") or 400
        val = simpledialog.askinteger("Resize Diagram", "Width in pixels:", parent=self,
                                      initialvalue=cur, minvalue=100, maxvalue=2000)
        if not val: return
        raw = self._embed_raws.get(str(frame), "")
        m = re.match(r'```diagram(?:\|(\d+))?\n(.*)```', raw, re.DOTALL)
        if m:
            code = m.group(2)
            self._embed_raws[str(frame)] = f"```diagram|{val}\n{code}```"
            self._rerender_section_with_sticker_change(parent_widget)

    def _move_sticker(self, frame, parent_widget, direction):
        """Move a sticker up (-1) or down (+1) by swapping with adjacent block."""
        # Get current section content, find the sticker's raw, move it, re-render
        content = self._get_section_content(parent_widget)
        raw = self._embed_raws.get(str(frame), "")
        if not raw: return
        # Split content into blocks (by newlines, but keep embeds as single blocks)
        # Find the line(s) that match the raw
        lines = content.split("\n")
        # Find the index of the raw in the lines
        # For multi-line embeds (code/diagram/table), find the start line
        raw_lines = raw.split("\n")
        match_start = -1
        for i in range(len(lines) - len(raw_lines) + 1):
            if lines[i:i+len(raw_lines)] == raw_lines:
                match_start = i
                break
        if match_start == -1: return
        match_end = match_start + len(raw_lines)
        # The block is lines[match_start:match_end], possibly with a preceding empty line
        # Find the swap target
        if direction == -1:
            # Move up: swap with the block above (skip empty lines)
            target = match_start - 1
            while target >= 0 and lines[target].strip() == "":
                target -= 1
            if target < 0: return
            # Find start of the target block (single line for text, multi-line for embeds)
            # For simplicity, just swap the raw block with the line above (after skipping empties)
            target_start = target
            target_end = target + 1
        else:
            # Move down: swap with the block below
            target = match_end
            while target < len(lines) and lines[target].strip() == "":
                target += 1
            if target >= len(lines): return
            target_start = target
            target_end = target + 1
        # Swap: remove raw block, insert after/before target
        block = lines[match_start:match_end]
        target_block = lines[target_start:target_end]
        new_lines = lines[:min(match_start, target_start)]
        if direction == -1:
            new_lines += block + [""] + target_block
            new_lines += lines[match_end:]
        else:
            new_lines += target_block + [""] + block
            new_lines += lines[match_end:] if match_end > target_end else lines[target_end:]
        new_content = "\n".join(new_lines)
        # Save and re-render
        self._apply_content_to_section(parent_widget, new_content)

    def _delete_sticker(self, frame, parent_widget):
        """Delete a sticker from the section."""
        content = self._get_section_content(parent_widget)
        raw = self._embed_raws.get(str(frame), "")
        if not raw: return
        new_content = content.replace(raw, "")
        # Clean up multiple blank lines
        new_content = re.sub(r'\n{3,}', '\n\n', new_content)
        self._apply_content_to_section(parent_widget, new_content)

    def _rerender_section_with_sticker_change(self, parent_widget):
        """Re-render a section from its current content (after _embed_raws was updated)."""
        content = self._get_section_content(parent_widget)
        self._apply_content_to_section(parent_widget, content)

    def _apply_content_to_section(self, parent_widget, new_content):
        """Replace a section's content and re-render it. Saves and updates."""
        # Find which section this widget belongs to
        sec_idx = None
        for i, w in enumerate(self._section_widgets):
            if w is parent_widget:
                sec_idx = i
                break
        if sec_idx is None: return
        # Re-render the whole note (simplest way to ensure consistency)
        # Build full content with the updated section
        parts = []
        for si, widget in enumerate(self._section_widgets):
            if si == sec_idx:
                sec_content = new_content
            else:
                sec_content = self._get_section_content(widget)
            if si == 0 and self._section_meta[si].get("name") == "Intro":
                parts.append(sec_content)
            else:
                meta = self._section_meta[si]
                parts.append(f"===SPLIT:{meta['name']}|{meta['bg']}|{meta.get('tags','')}===")
                parts.append(sec_content)
        full_content = "\n".join(parts)
        n = self.d.get_note(self.cur)
        if n:
            n["content"] = full_content
            self.d.update_note(self.cur, content=full_content)
            self._load(n)

    def _on_section_edit(self, widget):
        """Trigger debounced save on text edit."""
        self._on_content()

    def _section_header_menu(self, e, sec_idx):
        """v5.10: Right-click menu on a section header — resize section height."""
        if sec_idx < 0 or sec_idx >= len(self._section_widgets): return
        t = self.t
        menu = tk.Menu(self, tearoff=0, bg=t.card, fg=t.fg,
                      activebackground=t.hover, activeforeground=t.fg,
                      font=t.f(0), borderwidth=0)
        menu.add_command(label="Set section height...", command=lambda: self._resize_section(sec_idx))
        menu.add_command(label="Expand to fit content", command=lambda: self._auto_fit_section(sec_idx))
        try: menu.tk_popup(e.x_root, e.y_root)
        finally: menu.grab_release()

    def _resize_section(self, sec_idx):
        """v5.10: Set a section's Text widget height (in lines)."""
        widget = self._section_widgets[sec_idx]
        cur = widget.cget("height")
        val = simpledialog.askinteger("Section Height", "Height (lines):", parent=self,
                                      initialvalue=cur, minvalue=4, maxvalue=80)
        if val and widget.winfo_exists():
            widget.configure(height=val)

    def _auto_fit_section(self, sec_idx):
        """v5.10: Auto-fit a section's height to its content."""
        widget = self._section_widgets[sec_idx]
        if not widget.winfo_exists(): return
        self._auto_fit_section_widget(widget)

    def _auto_fit_section_widget(self, widget):
        """v5.10: Auto-fit a Text widget's height to fit ALL content precisely.
        Uses bbox to measure actual pixel height (including embedded windows),
        then sets height so the section ends exactly 2 lines after the last element."""
        try:
            if not widget.winfo_exists(): return
            # Temporarily set height large so all content is laid out
            widget.configure(height=200)
            widget.update_idletasks()
            # Measure the actual content bottom using bbox of the last character
            end_bbox = widget.bbox("end-1c")
            if end_bbox:
                content_bottom = end_bbox[1] + end_bbox[3]  # y + height
            else:
                content_bottom = 100
            # Also check embedded windows — find the lowest one
            for kind, value, index in widget.dump("1.0", "end-1c"):
                if kind == "window":
                    for w in getattr(self, "_embed_widgets", []):
                        try:
                            if str(w) == value and w.winfo_exists():
                                # Get the window's bbox in the Text widget
                                win_bbox = widget.bbox(index)
                                if win_bbox:
                                    win_bottom = win_bbox[1] + win_bbox[3]
                                    if win_bottom > content_bottom:
                                        content_bottom = win_bottom
                                break
                        except: pass
            # Get the default line height
            font = widget.cget("font")
            try:
                linespace = int(widget.tk.call("font", "metrics", font, "-linespace"))
            except:
                linespace = 20
            if linespace > 0:
                # Content height in lines (rounded up) + 2 lines buffer
                needed_lines = (content_bottom + linespace - 1) // linespace + 2
                widget.configure(height=max(4, min(200, needed_lines)))
            widget.update_idletasks()
        except: pass

    def _current_section_index(self):
        """Return the index of the section containing self.editor."""
        if not hasattr(self, "editor") or not self.editor: return None
        for i, w in enumerate(getattr(self, "_section_widgets", [])):
            if w is self.editor:
                return i
        if hasattr(self, "_section_widgets") and self._section_widgets:
            return len(self._section_widgets) - 1
        return None
    def _apply_markdown_formatting(self, widget):
        """v5.12: Apply live markdown formatting tags to a raw-markdown text widget.
        The widget keeps its raw markdown text (so saving is perfect), but visual
        formatting is applied on top: H1-H6 get sized/colored, **bold** renders bold,
        *italic* renders italic, ~~strike~~ renders strikethrough, `code` gets
        monospace+bg, #tags get colored, [[wikilinks]] and [text](url) get link
        styling, > quotes get indented, ---/***/___ get hr styling, lists get
        bullet markers, ```code blocks``` get dark bg, ![images] and {media} get
        distinct styling. Tags don't modify text content, so cursor is preserved."""
        t = self.t
        try:
            content = widget.get("1.0", "end-1c")
        except Exception:
            return
        # Configure formatting tags (md_ prefix avoids clashes with toolbar tags)
        # v5.12: extended with h4-h6, strike, bold_italic, lists, math_block
        widget.tag_configure("md_h1", font=t.f(5, True), foreground=t.accent, spacing1=14, spacing3=8)
        widget.tag_configure("md_h2", font=t.f(3, True), foreground=t.fg, spacing1=12, spacing3=6)
        widget.tag_configure("md_h3", font=t.f(2, True), foreground=t.fg, spacing1=10, spacing3=4)
        widget.tag_configure("md_h4", font=t.f(1, True), foreground=t.fg, spacing1=8, spacing3=3)
        widget.tag_configure("md_h5", font=t.f(0, True), foreground=t.muted, spacing1=6, spacing3=2)
        widget.tag_configure("md_h6", font=t.f(-1, True), foreground=t.muted, spacing1=6, spacing3=2)
        widget.tag_configure("md_bold", font=t.f(1, True))
        widget.tag_configure("md_italic", font=(t.font, t.fsize, "italic"))
        widget.tag_configure("md_bold_italic", font=(t.font, t.fsize + 1, "bold italic"))
        widget.tag_configure("md_strike", font=(t.font, t.fsize, "overstrike"))
        widget.tag_configure("md_code", font=("Consolas", t.fsize), background="#0D0D14", foreground=t.success)
        widget.tag_configure("md_codeblock", font=("Consolas", t.fsize), background="#0D0D14", foreground=t.success)
        widget.tag_configure("md_link", foreground="#5AA8FF", underline=True)
        widget.tag_configure("md_wikilink", foreground=t.accent, underline=True)
        widget.tag_configure("md_tag", foreground=t.warn)
        widget.tag_configure("md_quote", foreground=t.muted, lmargin1=24, lmargin2=24,
                             spacing1=4, spacing3=4, background=t.hover,
                             font=(t.font, t.fsize, "italic"))
        widget.tag_configure("md_hr", foreground=t.border, spacing1=8, spacing3=8)
        widget.tag_configure("md_math", font=("Cambria Math", t.fsize + 1),
                             foreground=t.accent, background=t.hover)
        widget.tag_configure("md_math_block", font=("Cambria Math", t.fsize + 3),
                             foreground=t.accent, background=t.hover,
                             spacing1=8, spacing3=8, justify="center")
        widget.tag_configure("md_img", foreground=t.accent, font=t.f(0, True))
        widget.tag_configure("md_media", foreground=t.warn, font=t.f(-1))
        widget.tag_configure("md_split", background=t.hover, font=t.f(1, True), foreground=t.muted)
        widget.tag_configure("md_list", lmargin1=20, lmargin2=20, spacing1=2, spacing3=2)
        widget.tag_configure("md_task_done", foreground=t.muted, overstrike=True,
                             lmargin1=20, lmargin2=20)
        widget.tag_configure("md_task_todo", lmargin1=20, lmargin2=20)
        widget.tag_configure("md_task_check", foreground=t.success, font=t.f(0, True))
        widget.tag_configure("md_html", foreground=t.dim,
                             font=("Consolas", max(8, t.fsize - 1)))
        # Remove old md_ tags
        for tag in widget.tag_names():
            if tag.startswith("md_"):
                widget.tag_remove(tag, "1.0", "end")
        lines = content.split("\n")
        in_codeblock = False
        in_block_math = False
        for line_num, line in enumerate(lines, 1):
            # Code block toggle
            stripped = line.strip()
            if stripped.startswith("```"):
                in_codeblock = not in_codeblock
                widget.tag_add("md_codeblock", f"{line_num}.0", f"{line_num}.end")
                continue
            if in_codeblock:
                widget.tag_add("md_codeblock", f"{line_num}.0", f"{line_num}.end")
                continue
            # Block math $$...$$ toggle
            if stripped == "$$":
                in_block_math = not in_block_math
                widget.tag_add("md_math_block", f"{line_num}.0", f"{line_num}.end")
                continue
            if in_block_math:
                widget.tag_add("md_math_block", f"{line_num}.0", f"{line_num}.end")
                continue
            # Split marker (stray markers in content)
            if re.match(r'^===SPLIT:', stripped):
                widget.tag_add("md_split", f"{line_num}.0", f"{line_num}.end")
                continue
            # Block-level: headers (H1-H6), hr (all variants), quotes, lists, tasks
            hm = re.match(r'^(#{1,6})\s+(.*)$', line)
            if hm:
                level = len(hm.group(1))
                widget.tag_add(f"md_h{level}", f"{line_num}.0", f"{line_num}.end")
                continue
            if re.match(r'^(-{3,}|\*{3,}|_{3,})$', stripped):
                widget.tag_add("md_hr", f"{line_num}.0", f"{line_num}.end")
                continue
            qm = re.match(r'^\s*(>+)\s?(.*)$', line)
            if qm and qm.group(1):
                widget.tag_add("md_quote", f"{line_num}.0", f"{line_num}.end")
                continue
            # Task list: - [x] / - [ ]
            tm = re.match(r'^(\s*)([-*+])\s+\[([ xX])\]\s+(.*)$', line)
            if tm:
                if tm.group(3).lower() == "x":
                    widget.tag_add("md_task_check", f"{line_num}.0", f"{line_num}.end")
                    widget.tag_add("md_task_done", f"{line_num}.0", f"{line_num}.end")
                else:
                    widget.tag_add("md_task_todo", f"{line_num}.0", f"{line_num}.end")
                continue
            # Unordered / ordered list
            if re.match(r'^(\s*)([-*+]|\d+\.)\s+', line):
                widget.tag_add("md_list", f"{line_num}.0", f"{line_num}.end")
                continue
            # Inline formatting
            # Bold-italic: ***text***
            for m in re.finditer(r'\*\*\*([^*]+)\*\*\*', line):
                widget.tag_add("md_bold_italic", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Bold: **text**
            for m in re.finditer(r'(?<!\*)\*\*([^*]+)\*\*(?!\*)', line):
                widget.tag_add("md_bold", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Italic: *text* (not **)
            for m in re.finditer(r'(?<!\*)\*([^*]+)\*(?!\*)', line):
                widget.tag_add("md_italic", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Strikethrough: ~~text~~
            for m in re.finditer(r'~~([^~]+)~~', line):
                widget.tag_add("md_strike", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Inline code: `text`
            for m in re.finditer(r'`([^`]+)`', line):
                widget.tag_add("md_code", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Wiki-links: [[text]]
            for m in re.finditer(r'\[\[([^\]]+)\]\]', line):
                widget.tag_add("md_wikilink", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Markdown links: [text](url) — tag the [text] portion as link
            for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)', line):
                widget.tag_add("md_link", f"{line_num}.{m.start(1)}", f"{line_num}.{m.end(1)}")
            # Bare URLs
            for m in re.finditer(r'(?:https?://|www\.)[^\s)]+', line):
                widget.tag_add("md_link", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Tags: #word
            for m in re.finditer(r'#([A-Za-z_][\w-]*)', line):
                widget.tag_add("md_tag", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Images: ![alt](path)
            for m in re.finditer(r'!\[([^\]]*)\]\(([^)]+)\)', line):
                widget.tag_add("md_img", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Media: {audio:path} or {video:path}
            for m in re.finditer(r'\{+(audio|video):([^}]+)\}+', line):
                widget.tag_add("md_media", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Inline math: $...$
            for m in re.finditer(r'(?<!\$)\$([^$\n]+)\$(?!\$)', line):
                widget.tag_add("md_math", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")
            # Safe HTML inline tags
            for m in re.finditer(r'</?(?:b|i|u|em|strong|br|hr)\s*/?>', line, re.IGNORECASE):
                widget.tag_add("md_html", f"{line_num}.{m.start()}", f"{line_num}.{m.end()}")

    def _render_markdown_into(self, widget, content):
        """v5.12: Render markdown content into a text widget with INLINE rich content:
        images (image_create), code blocks (with Run/Copy buttons), tables (Treeview),
        diagrams (Canvas), audio/video (Play buttons), H1-H6 headers, bold, italic,
        strikethrough, code, links, lists, blockquotes, math, etc.
        The widget is left in 'normal' state — the caller sets state='disabled' if needed."""
        t = self.t
        widget.delete("1.0", "end")
        # v5.12: full tag set (mirror of _configure_text_tags for preview mode)
        widget.tag_configure("h1", font=t.f(5, True), foreground=t.accent, spacing1=14, spacing3=8)
        widget.tag_configure("h2", font=t.f(3, True), foreground=t.fg, spacing1=12, spacing3=6)
        widget.tag_configure("h3", font=t.f(2, True), foreground=t.fg, spacing1=10, spacing3=4)
        widget.tag_configure("h4", font=t.f(1, True), foreground=t.fg, spacing1=8, spacing3=3)
        widget.tag_configure("h5", font=t.f(0, True), foreground=t.muted, spacing1=6, spacing3=2)
        widget.tag_configure("h6", font=t.f(-1, True), foreground=t.muted, spacing1=6, spacing3=2)
        widget.tag_configure("bold", font=t.f(1, True))
        widget.tag_configure("italic", font=(t.font, t.fsize, "italic"))
        widget.tag_configure("bold_italic", font=(t.font, t.fsize + 1, "bold italic"))
        widget.tag_configure("strike", font=(t.font, t.fsize, "overstrike"))
        widget.tag_configure("code", font=("Consolas", t.fsize), background="#0D0D14",
                             foreground=t.success, spacing1=1, spacing3=1)
        widget.tag_configure("link", foreground="#5AA8FF", underline=True)
        widget.tag_configure("wikilink", foreground=t.accent, underline=True)
        widget.tag_configure("tag", foreground=t.warn)
        widget.tag_configure("quote", foreground=t.muted, lmargin1=24, lmargin2=24,
                             spacing1=4, spacing3=4, background=t.hover,
                             font=(t.font, t.fsize, "italic"))
        widget.tag_configure("hr", foreground=t.border, spacing1=8, spacing3=8)
        widget.tag_configure("math", font=("Cambria Math", t.fsize + 1),
                             foreground=t.accent, background=t.hover)
        widget.tag_configure("math_block", font=("Cambria Math", t.fsize + 3),
                             foreground=t.accent, background=t.hover,
                             spacing1=8, spacing3=8, justify="center")
        widget.tag_configure("list_bullet", lmargin1=20, lmargin2=20, spacing1=2, spacing3=2)
        widget.tag_configure("task_done", foreground=t.muted, overstrike=True,
                             lmargin1=20, lmargin2=20)
        widget.tag_configure("task_todo", lmargin1=20, lmargin2=20)
        widget.tag_configure("task_check", foreground=t.success, font=t.f(0, True))
        widget.tag_configure("html_tag", foreground=t.dim,
                             font=("Consolas", max(8, t.fsize - 1)))
        # Wire link click + hover
        widget.tag_bind("link", "<Button-1>", self._on_link_click)
        widget.tag_bind("link", "<Enter>", self._on_link_enter)
        widget.tag_bind("link", "<Leave>", self._on_link_leave)
        widget.tag_bind("wikilink", "<Button-1>", self._on_wikilink_click)
        widget.tag_bind("wikilink", "<Enter>", self._on_link_enter)
        widget.tag_bind("wikilink", "<Leave>", self._on_link_leave)
        lines = content.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            # Block math $$...$$
            if line.strip() == "$$":
                math_lines = []
                i += 1
                while i < len(lines) and lines[i].strip() != "$$":
                    math_lines.append(lines[i]); i += 1
                i += 1  # skip closing $$
                expr = "\n".join(math_lines)
                rendered = self._render_math(expr)
                widget.insert("end", "\n" + rendered + "\n\n", "math_block")
                continue
            # Single-line block math: $$ expr $$
            m = re.match(r'^\$\$(.+)\$\$\s*$', line.strip())
            if m:
                rendered = self._render_math(m.group(1))
                widget.insert("end", "\n" + rendered + "\n\n", "math_block")
                i += 1; continue
            # Code block (also handles 'diagram' / 'mermaid' as diagrams)
            if line.strip().startswith("```"):
                lang = line.strip()[3:].strip()
                code_lines = []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    code_lines.append(lines[i]); i += 1
                i += 1
                if lang in ("diagram", "flowchart", "mermaid"):
                    self._insert_diagram_block(widget, "\n".join(code_lines))
                    continue
                widget.insert("end", f"[{lang or 'code'}]\n", "tag")
                widget.insert("end", "\n".join(code_lines) + "\n", "code")
                if lang in ("python", "py", "html", "js", "javascript", "css"):
                    bf = tk.Frame(widget, bg=t.card)
                    code_text = "\n".join(code_lines)
                    def run(c=code_text, l=lang):
                        self._run_block(c, l)
                    tk.Button(bf, text=f"Run {lang}", bg=t.accent, fg="#0E0E14", relief="flat",
                              font=t.f(-1, True), cursor="hand2", padx=12, pady=4,
                              command=run).pack(side="left")
                    def cp(c=code_text):
                        self.clipboard_clear(); self.clipboard_append(c)
                    tk.Button(bf, text="Copy", bg=t.card, fg=t.fg, relief="flat", font=t.f(-1),
                              cursor="hand2", padx=12, pady=4, command=cp).pack(side="left", padx=4)
                    widget.window_create("end", window=bf)
                    widget.insert("end", "\n\n")
                continue
            # Image
            m = re.match(r'^!\[([^\]]*)\]\(([^)]+)\)', line.strip())
            if m:
                alt, path = m.group(1), m.group(2)
                self._insert_image(widget, path, alt)
                i += 1; continue
            # Audio
            m = re.match(r'^\{+audio:([^}]+)\}+', line.strip())
            if m:
                self._insert_media(widget, "Audio", m.group(1))
                i += 1; continue
            # Video
            m = re.match(r'^\{+video:([^}]+)\}+', line.strip())
            if m:
                self._insert_media(widget, "Video", m.group(1))
                i += 1; continue
            # Split marker (stray markers — normally handled by section headers)
            m_split = re.match(r'^===SPLIT:([^|]+)\|([^|]*)(?:\|([^=]*))?===\s*$', line.strip())
            if m_split:
                sp_name = m_split.group(1).strip()
                sp_bg = m_split.group(2).strip() or "#1E1E2A"
                sp_tags = (m_split.group(3) or "").strip()
                div_tag = f"splitdiv_{abs(hash(sp_name))}"
                widget.tag_configure(div_tag, background=sp_bg, font=t.f(2, True),
                                     foreground="#FFFFFF", spacing1=10, spacing3=10,
                                     justify="center", relief="raised", borderwidth=2)
                widget.insert("end", "\n")
                label = f"  \u25C6  {sp_name}  \u25C6  "
                if sp_tags: label += f"   {sp_tags}"
                widget.insert("end", label + "\n", div_tag)
                widget.insert("end", "\n")
                i += 1; continue
            # Headers — H1-H6
            hm = re.match(r'^(#{1,6})\s+(.*)$', line)
            if hm:
                level = len(hm.group(1))
                tag = f"h{level}"
                widget.insert("end", hm.group(2) + "\n", tag)
                # H1/H2 get a separator line underneath
                if level <= 2:
                    sep_char = "\u2550" if level == 1 else "\u2500"
                    widget.insert("end", sep_char * 50 + "\n", "hr")
                i += 1; continue
            # Horizontal rules: ---, ***, ___ (3+ chars)
            if re.match(r'^(-{3,}|\*{3,}|_{3,})$', line.strip()):
                widget.insert("end", "\u2500" * 50 + "\n", "hr")
                i += 1; continue
            # Blockquote: > text  (also >>, with optional space)
            qm = re.match(r'^\s*(>+)\s?(.*)$', line)
            if qm and qm.group(1):
                widget.insert("end", qm.group(2) + "\n", "quote")
                i += 1; continue
            # Task list: - [x] / - [ ]
            tm = re.match(r'^(\s*)([-*+])\s+\[([ xX])\]\s+(.*)$', line)
            if tm:
                check = "[\u2713]" if tm.group(3).lower() == "x" else "[ ]"
                indent = len(tm.group(1))
                lmargin = 20 + indent * 4
                widget.tag_configure(f"task_{indent}", lmargin1=lmargin, lmargin2=lmargin,
                                     spacing1=2, spacing3=2)
                widget.insert("end", f"{check}  ", "task_check" if tm.group(3).lower() == "x" else "tag")
                text_tag = "task_done" if tm.group(3).lower() == "x" else f"task_{indent}"
                widget.insert("end", tm.group(4) + "\n", text_tag)
                i += 1; continue
            # Unordered list: -, *, +
            um = re.match(r'^(\s*)([-*+])\s+(.*)$', line)
            if um:
                indent = len(um.group(1))
                lmargin = 20 + indent * 4
                widget.tag_configure(f"ul_{indent}", lmargin1=lmargin, lmargin2=lmargin,
                                     spacing1=2, spacing3=2)
                widget.insert("end", "\u2022  ", "tag")
                widget.insert("end", um.group(3) + "\n", f"ul_{indent}")
                i += 1; continue
            # Ordered list: 1. 2. etc.
            om = re.match(r'^(\s*)(\d+\.)\s+(.*)$', line)
            if om:
                indent = len(om.group(1))
                lmargin = 20 + indent * 4
                widget.tag_configure(f"ol_{indent}", lmargin1=lmargin, lmargin2=lmargin,
                                     spacing1=2, spacing3=2)
                widget.insert("end", om.group(2) + "  ", "tag")
                widget.insert("end", om.group(3) + "\n", f"ol_{indent}")
                i += 1; continue
            # Table
            if line.strip().startswith("|") and i+1 < len(lines) and "---" in lines[i+1]:
                table_lines = []
                while i < len(lines) and lines[i].strip().startswith("|"):
                    table_lines.append(lines[i]); i += 1
                self._insert_table(widget, table_lines)
                continue
            elif line.strip():
                self._render_inline(widget, line)
                widget.insert("end", "\n")
            else:
                widget.insert("end", "\n")
            i += 1

    def _render_math(self, expr):
        """v5.12: Convert a LaTeX math expression to Unicode for display in tkinter.
        Improved coverage: blackboard bold, calligraphic, mathrm/text wrappers,
        left/right delimiters, binom, nth-root, more Greek variants, and better
        frac handling for nested cases."""
        if not expr: return ""
        s = expr
        # Strip \mathrm{...}, \text{...}, \mathit{...}, \mathbf{...} wrappers
        # (keep the inner text)
        for wrapper in ("mathrm", "text", "mathit", "mathbf", "mathsf", "mathtt",
                        "operatorname", "boxed", "textbf", "textit", "texttt"):
            s = re.sub(r'\\' + wrapper + r'\{([^{}]*)\}', r'\1', s)
        # Strip \left and \right modifiers (they're sizing hints, no glyph)
        s = s.replace(r"\left", "").replace(r"\right", "")
        # Strip \displaystyle, \scriptstyle, \textstyle, \limits, \nolimits
        for cmd in (r"\displaystyle", r"\scriptstyle", r"\textstyle",
                    r"\limits", r"\nolimits", r"\!", r"\,", r"\;", r"\:",
                    r"\quad", r"\qquad"):
            s = s.replace(cmd, " " if cmd in (r"\quad", r"\qquad", r"\,", r"\;", r"\:", r"\ ") else "")
        # Greek letters (lowercase + uppercase + variants)
        greek = {
            "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ", "epsilon": "ε",
            "varepsilon": "ε", "zeta": "ζ", "eta": "η", "theta": "θ", "vartheta": "ϑ",
            "iota": "ι", "kappa": "κ", "lambda": "λ", "mu": "μ", "nu": "ν", "xi": "ξ",
            "pi": "π", "varpi": "ϖ", "rho": "ρ", "varrho": "ϱ", "sigma": "σ", "varsigma": "ς",
            "tau": "τ", "upsilon": "υ", "phi": "φ", "varphi": "ϕ", "chi": "χ",
            "psi": "ψ", "omega": "ω",
            "Gamma": "Γ", "Delta": "Δ", "Theta": "Θ", "Lambda": "Λ", "Pi": "Π",
            "Sigma": "Σ", "Phi": "Φ", "Psi": "Ψ", "Omega": "Ω",
        }
        for k, v in greek.items():
            s = s.replace("\\" + k, v)
        # Blackboard bold: \mathbb{R} -> ℝ, etc.
        bb_map = {"R": "ℝ", "N": "ℕ", "Z": "ℤ", "Q": "ℚ", "C": "ℂ",
                  "H": "ℍ", "P": "ℙ", "1": "𝟙", "0": "𝟘"}
        def bb_repl(m):
            inner = m.group(1)
            return "".join(bb_map.get(c, c) for c in inner)
        s = re.sub(r'\\mathbb\{([^{}]+)\}', bb_repl, s)
        s = re.sub(r'\\Bbb\{([^{}]+)\}', bb_repl, s)
        # Calligraphic: \mathcal{L} -> 𝓛 (best-effort, fallback to italic L)
        cal_map = {"A":"𝓐","B":"𝓑","C":"𝓒","D":"𝓓","E":"𝓔","F":"𝓕","G":"𝓖","H":"𝓗",
                   "I":"𝓘","J":"𝓙","K":"𝓚","L":"𝓛","M":"𝓜","N":"𝓝","O":"𝓞","P":"𝓟",
                   "Q":"𝓠","R":"𝓡","S":"𝓢","T":"𝓣","U":"𝓤","V":"𝓥","W":"𝓦","X":"𝓧",
                   "Y":"𝓨","Z":"𝓩"}
        def cal_repl(m):
            return "".join(cal_map.get(c, c) for c in m.group(1))
        s = re.sub(r'\\mathcal\{([^{}]+)\}', cal_repl, s)
        # v5.12: sort by descending length so multi-char commands like
        # \int, \iint, \iiint are replaced before \in (which would otherwise
        # eat the 't' from \int). Also exclude \sqrt from this pass — it's
        # handled specially below (along with \sqrt[n]{x}) BEFORE this dict
        # replacement, so we don't double-process it.
        symbols = {
            "\\infty": "∞", "\\partial": "∂", "\\nabla": "∇", "\\hbar": "ℏ",
            "\\times": "×", "\\div": "÷", "\\pm": "±", "\\mp": "∓",
            "\\cdot": "·", "\\cdots": "⋯", "\\ldots": "…", "\\vdots": "⋮", "\\ddots": "⋱",
            "\\leq": "≤", "\\geq": "≥", "\\neq": "≠", "\\approx": "≈", "\\equiv": "≡",
            "\\sim": "∼", "\\simeq": "≃", "\\cong": "≅", "\\propto": "∝",
            "\\in": "∈", "\\notin": "∉", "\\ni": "∋",
            "\\subset": "⊂", "\\supset": "⊃", "\\subseteq": "⊆", "\\supseteq": "⊇",
            "\\cup": "∪", "\\cap": "∩", "\\emptyset": "∅", "\\varnothing": "∅",
            "\\forall": "∀", "\\exists": "∃", "\\nexists": "∄", "\\neg": "¬", "\\therefore": "∴",
            "\\because": "∵",
            "\\rightarrow": "→", "\\leftarrow": "←", "\\Rightarrow": "⇒", "\\Leftarrow": "⇐",
            "\\leftrightarrow": "↔", "\\Leftrightarrow": "⇔", "\\mapsto": "↦",
            "\\uparrow": "↑", "\\downarrow": "↓", "\\updownarrow": "↕",
            "\\to": "→", "\\circ": "∘", "\\bullet": "•", "\\star": "⋆",
            "\\int": "∫", "\\iint": "∬", "\\iiint": "∭", "\\oint": "∮",
            "\\sum": "∑", "\\prod": "∏", "\\coprod": "∐", "\\bigoplus": "⊕", "\\bigotimes": "⊗",
            "\\cbrt": "∛", "\\fourthroot": "∜",
            "\\angle": "∠", "\\perp": "⊥", "\\parallel": "∥", "\\triangle": "△", "\\circle": "○",
            "\\degree": "°", "\\prime": "′", "\\dprime": "″",
            "\\oplus": "⊕", "\\otimes": "⊗", "\\odot": "⊙", "\\ominus": "⊖", "\\oslash": "⊘",
            "\\vee": "∨", "\\wedge": "∧",
            "\\langle": "⟨", "\\rangle": "⟩", "\\lceil": "⌈", "\\rceil": "⌉",
            "\\lfloor": "⌊", "\\rfloor": "⌋",
            "\\aleph": "ℵ", "\\beth": "ℶ", "\\gimel": "ℷ", "\\daleth": "ℸ",
            "\\Re": "ℜ", "\\Im": "ℑ", "\\wp": "℘", "\\complement": "∁",
            "\\ell": "ℓ", "\\mho": "℧",
            "\\dagger": "†", "\\ddagger": "‡", "\\S": "§", "\\P": "¶",
            "\\colon": ":", "\\vert": "|", "\\Vert": "‖", "\\backslash": "\\",
            "\\top": "⊤", "\\bot": "⊥", "\\models": "⊨", "\\vdash": "⊢", "\\dashv": "⊣",
        }
        # v5.12: handle \sqrt[n]{x} and \sqrt{x} BEFORE the simple \sqrt -> √
        # replacement, so the [n] form is processed correctly.
        _sup_for_root = {"0":"⁰","1":"¹","2":"²","3":"³","4":"⁴","5":"⁵","6":"⁶","7":"⁷","8":"⁸","9":"⁹",
                         "+":"⁺","-":"⁻","=":"⁼","(":"⁽",")":"⁾","n":"ⁿ","i":"ⁱ"}
        s = re.sub(r'\\sqrt\[([^\[\]]+)\]\{([^{}]+)\}',
                   lambda m: "".join(_sup_for_root.get(c, c) for c in m.group(1)) + "√" + m.group(2),
                   s)
        s = s.replace("\\sqrt", "√")
        # Sort keys by descending length so longer commands win over shorter prefixes.
        for k in sorted(symbols.keys(), key=lambda s: -len(s)):
            s = s.replace(k, symbols[k])
        # Binom: \binom{n}{k} -> (n choose k)
        s = re.sub(r'\\binom\{([^{}]+)\}\{([^{}]+)\}', r'(\1 choose \2)', s)
        # Fractions: \frac{a}{b} -> a⁄b (using fraction slash)
        s = re.sub(r'\\frac\{([^{}]+)\}\{([^{}]+)\}', r'\1⁄\2', s)
        s = re.sub(r'\\dfrac\{([^{}]+)\}\{([^{}]+)\}', r'\1⁄\2', s)
        s = re.sub(r'\\tfrac\{([^{}]+)\}\{([^{}]+)\}', r'\1⁄\2', s)
        # Overline / underline: \overline{x} -> x̄ (combining macron U+0304)
        # Use lambdas to avoid re.sub's interpretation of \u escapes in repl strings
        s = re.sub(r'\\overline\{([^{}]+)\}', lambda m: m.group(1) + "\u0304", s)
        s = re.sub(r'\\bar\{([^{}]+)\}', lambda m: m.group(1) + "\u0304", s)
        s = re.sub(r'\\hat\{([^{}]+)\}', lambda m: m.group(1) + "\u0302", s)
        s = re.sub(r'\\vec\{([^{}]+)\}', lambda m: m.group(1) + "\u20d7", s)
        s = re.sub(r'\\dot\{([^{}]+)\}', lambda m: m.group(1) + "\u0307", s)
        s = re.sub(r'\\ddot\{([^{}]+)\}', lambda m: m.group(1) + "\u0308", s)
        s = re.sub(r'\\tilde\{([^{}]+)\}', lambda m: m.group(1) + "\u0303", s)
        # Subscripts: x_{ab} or x_a -> xₐᵦ (using unicode subscripts where possible)
        sub_map = {"0":"₀","1":"₁","2":"₂","3":"₃","4":"₄","5":"₅","6":"₆","7":"₇","8":"₈","9":"₉",
                   "+":"₊","-":"₋","=":"₌","(":"₍",")":"₎","a":"ₐ","e":"ₑ","h":"ₕ","i":"ᵢ","j":"ⱼ",
                   "k":"ₖ","l":"ₗ","m":"ₘ","n":"ₙ","o":"ₒ","p":"ₚ","r":"ᵣ","s":"ₛ","t":"ₜ","u":"ᵤ","v":"ᵥ","x":"ₓ"}
        def sub_repl(m):
            inner = m.group(1) if m.group(1) else m.group(2)
            return "".join(sub_map.get(c, c) for c in inner)
        s = re.sub(r'_\{([^{}]+)\}|_(\w)', sub_repl, s)
        # Superscripts: x^{ab} or x^a -> x^ab (using unicode superscripts where possible)
        sup_map = {"0":"⁰","1":"¹","2":"²","3":"³","4":"⁴","5":"⁵","6":"⁶","7":"⁷","8":"⁸","9":"⁹",
                   "+":"⁺","-":"⁻","=":"⁼","(":"⁽",")":"⁾","n":"ⁿ","i":"ⁱ"}
        def sup_repl(m):
            inner = m.group(1) if m.group(1) else m.group(2)
            return "".join(sup_map.get(c, c) for c in inner)
        s = re.sub(r'\^\{([^{}]+)\}|\^(\w)', sup_repl, s)
        # Clean up: collapse multiple spaces, strip trailing whitespace
        s = re.sub(r'  +', ' ', s).strip()
        return s

    def _render_math_legacy(self, expr):
        """Alias kept for any external callers — delegates to _render_math."""
        return self._render_math(expr)

    def _insert_diagram_block(self, widget, code):
        """Render a simple flowchart diagram on a Canvas. Syntax: A --> B, A -->|label| B, etc."""
        t = self.t
        try:
            # Parse lines: 'A --> B', 'A -->|text| B', 'A --- B', 'A -> B'
            edges = []
            nodes = {}
            for line in code.split("\n"):
                line = line.strip()
                if not line or line.startswith("#"): continue
                # Match: SOURCE (arrow) [label] DEST
                m = re.match(r'^(\w[\w \-]*?)\s*(-->|->|---|-\.|==>)\s*(?:\|([^|]+)\|\s*)?(\w[\w \-]*)$', line)
                if m:
                    src = m.group(1).strip(); dst = m.group(4).strip(); label = (m.group(3) or "").strip()
                    if src not in nodes: nodes[src] = {"name": src}
                    if dst not in nodes: nodes[dst] = {"name": dst}
                    edges.append((src, dst, label))
                else:
                    # standalone node declaration
                    if line and line not in nodes:
                        nodes[line] = {"name": line}
            if not nodes:
                widget.insert("end", "[Empty diagram]\n", "tag")
                return
            # Layout: simple grid
            node_list = list(nodes.keys())
            n = len(node_list)
            cols = max(1, int(math.ceil(math.sqrt(n))))
            rows = max(1, int(math.ceil(n / cols)))
            cell_w, cell_h = 130, 60
            pad = 30
            canvas_w = cols * cell_w + pad * 2
            canvas_h = rows * cell_h + pad * 2
            for idx, name in enumerate(node_list):
                r = idx // cols; c = idx % cols
                x = pad + c * cell_w + cell_w // 2
                y = pad + r * cell_h + cell_h // 2
                nodes[name]["pos"] = (x, y)
            # Draw on canvas
            df = tk.Frame(widget, bg=t.card)
            cv = tk.Canvas(df, bg=t.card, width=canvas_w, height=canvas_h, highlightthickness=1,
                           highlightbackground=t.border)
            cv.pack(pady=4)
            # Draw edges
            for src, dst, label in edges:
                if src not in nodes or dst not in nodes: continue
                x1, y1 = nodes[src]["pos"]; x2, y2 = nodes[dst]["pos"]
                cv.create_line(x1, y1, x2, y2, fill=t.muted, width=2, arrow="last")
                if label:
                    mx, my = (x1 + x2) // 2, (y1 + y2) // 2
                    cv.create_text(mx, my - 8, text=label, fill=t.warn, font=t.f(-2))
            # Draw nodes (as rounded rectangles)
            for name, info in nodes.items():
                x, y = info["pos"]
                w = max(60, len(name) * 8 + 16)
                cv.create_rectangle(x - w//2, y - 16, x + w//2, y + 16, fill=t.hover, outline=t.accent, width=2)
                cv.create_text(x, y, text=name, fill=t.fg, font=t.f(-1, True))
            widget.window_create("end", window=df)
            widget.insert("end", "\n\n")
        except Exception as e:
            widget.insert("end", f"[Diagram error: {e}]\n", "tag")

    def _render_inline(self, widget, line):
        """v5.12: Render a single line of markdown into the widget with inline tags.
        Handles: $math$, [[wikilinks]], [text](url), bare URLs, #tags, ***bold italic***,
        **bold**, *italic*, ~~strikethrough~~, `code`, and safe HTML tags."""
        # Order matters: longer markers first (*** before ** before *)
        pattern = re.compile(
            r'(\$\$[^$]+\$\$'                              # block math $$...$$ (rare inline)
            r'|\$[^$\n]+\$'                                # inline math $...$
            r'|\[\[[^\]]+\]\]'                            # [[wikilink]]
            r'|\[[^\]]+\]\([^)]+\)'                       # [text](url)
            r'|(?:https?://|www\.)[^\s)]+'                  # bare URL
            r'|\#\w+'                                       # #tag
            r'|\*\*\*[^*]+\*\*\*'                         # ***bold italic***
            r'|\*\*[^*]+\*\*'                              # **bold**
            r'|\*[^*]+\*'                                   # *italic*
            r'|~~[^~]+~~'                                    # ~~strikethrough~~
            r'|`[^`]+`'                                      # `code`
            r'|</?(?:b|i|u|em|strong|br|hr)\s*/?>)',         # safe HTML
            re.IGNORECASE)
        pos = 0
        for m in pattern.finditer(line):
            if m.start() > pos:
                widget.insert("end", line[pos:m.start()])
            tok = m.group()
            if tok.startswith("$$") and tok.endswith("$$") and len(tok) > 4:
                rendered = self._render_math(tok[2:-2])
                widget.insert("end", rendered, "math_block")
            elif tok.startswith("$") and tok.endswith("$") and len(tok) > 2:
                rendered = self._render_math(tok[1:-1])
                widget.insert("end", rendered, "math")
            elif tok.startswith("[[") and tok.endswith("]]"):
                widget.insert("end", tok[2:-2], "wikilink")
            elif tok.startswith("[") and "](" in tok and tok.endswith(")"):
                # [text](url) — insert the text with link tag, store URL via tag data
                mm = re.match(r'\[([^\]]+)\]\(([^)]+)\)', tok)
                if mm:
                    text, url = mm.group(1), mm.group(2)
                    # We insert just the visible text; click handler re-parses the line.
                    widget.insert("end", text, "link")
                else:
                    widget.insert("end", tok)
            elif tok.startswith("http://") or tok.startswith("https://") or tok.startswith("www."):
                widget.insert("end", tok, "link")
            elif tok.startswith("#"):
                widget.insert("end", tok, "tag")
            elif tok.startswith("***") and tok.endswith("***"):
                widget.insert("end", tok[3:-3], ("bold", "italic"))
            elif tok.startswith("**") and tok.endswith("**"):
                widget.insert("end", tok[2:-2], "bold")
            elif tok.startswith("*") and tok.endswith("*"):
                widget.insert("end", tok[1:-1], "italic")
            elif tok.startswith("~~") and tok.endswith("~~"):
                widget.insert("end", tok[2:-2], "strike")
            elif tok.startswith("`") and tok.endswith("`"):
                widget.insert("end", tok[1:-1], "code")
            elif tok.startswith("<") and tok.endswith(">"):
                # Safe HTML inline tag — render as a subtle marker so the user
                # sees it but it doesn't execute. <br>/<hr> add a line break/rule.
                low = tok.lower()
                if low in ("<br>", "<br/>", "<br />"):
                    widget.insert("end", "\n")
                elif low in ("<hr>", "<hr/>", "<hr />"):
                    widget.insert("end", "\u2500" * 40 + "\n", "hr")
                elif low in ("<b>", "<strong>"):
                    pass  # opening — rely on next-pass for closing
                else:
                    widget.insert("end", tok, "html_tag")
            else:
                widget.insert("end", tok)
            pos = m.end()
        if pos < len(line):
            widget.insert("end", line[pos:])

    def _insert_image(self, widget, path, alt):
        t = self.t
        try:
            if os.path.exists(path) and HAS_PIL:
                img = Image.open(path)
                max_w = 600
                if img.width > max_w:
                    ratio = max_w / img.width
                    img = img.resize((max_w, int(img.height * ratio)), Image.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self._imgs.append(photo)
                widget.image_create("end", image=photo)
                widget.insert("end", f"\n{alt}\n\n", "tag")
            else:
                widget.insert("end", f"[Image: {path}]\n", "tag")
        except Exception as e:
            widget.insert("end", f"[Image error: {e}]\n", "tag")

    def _insert_media(self, widget, mtype, path):
        """Insert an audio/video block. For video, show thumbnail (first frame) if possible, plus a Play button."""
        t = self.t
        fname = os.path.basename(path)
        exists = os.path.exists(path)
        mf = tk.Frame(widget, bg=t.hover, padx=12, pady=8)
        # Icon/text
        icon = "▶" if mtype == "Video" else "♪"
        tk.Label(mf, text=f" {icon} {mtype}: {fname}", bg=t.hover, fg=t.fg, font=t.f(0)).pack(side="left")
        if not exists:
            tk.Label(mf, text=" (file not found)", bg=t.hover, fg=t.danger, font=t.f(-1)).pack(side="left")
        def play(p=path):
            try: os.startfile(p)
            except Exception as e: messagebox.showerror("Error", str(e))
        tk.Button(mf, text="Play", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(-1, True),
                  cursor="hand2", padx=16, pady=4, command=play).pack(side="right", padx=4)
        widget.window_create("end", window=mf)
        # For videos, try to embed a thumbnail (first frame via PIL if it's an animated gif, else placeholder)
        if mtype == "Video" and exists and HAS_PIL:
            try:
                # PIL can extract first frame from GIF/animated; for MP4 we can't, but we show a placeholder image
                if path.lower().endswith((".gif", ".png", ".jpg", ".jpeg", ".bmp")):
                    img = Image.open(path)
                    max_w = 400
                    if img.width > max_w:
                        ratio = max_w / img.width
                        img = img.resize((max_w, int(img.height * ratio)), Image.LANCZOS)
                    photo = ImageTk.PhotoImage(img)
                    self._imgs.append(photo)
                    widget.insert("end", "\n")
                    widget.image_create("end", image=photo)
                    widget.insert("end", "\n")
            except: pass
        widget.insert("end", "\n\n")

    def _insert_table(self, widget, lines):
        """v5.12: Render a markdown table as a Treeview. Parses alignment markers
        (:---, ---:, :---:) and applies left/right/center anchor per column."""
        t = self.t
        rows = []
        aligns = []
        for idx, line in enumerate(lines):
            if "---" in line:
                # Separator row — parse alignment markers
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                for c in cells:
                    c = c.strip()
                    if c.startswith(":") and c.endswith(":"):
                        aligns.append("center")
                    elif c.endswith(":"):
                        aligns.append("e")
                    else:
                        aligns.append("w")
                continue
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            rows.append(cells)
        if not rows: return
        tf = tk.Frame(widget, bg=t.card)
        headers = rows[0]
        tree = ttk.Treeview(tf, columns=headers, show="headings", height=min(len(rows)-1, 10))
        anchor_map = {"w": "w", "e": "e", "center": "center"}
        for ci, h in enumerate(headers):
            tree.heading(h, text=h)
            anchor = anchor_map.get(aligns[ci], "center") if ci < len(aligns) else "center"
            tree.column(h, width=120, anchor=anchor)
        style = ttk.Style()
        style.configure("T.Treeview", background=t.card, foreground=t.fg, fieldbackground=t.card, borderwidth=0, font=t.f(-1))
        style.configure("Treeview.Heading", background=t.hover, foreground=t.fg, font=t.f(-1, True))
        for row in rows[1:]:
            tree.insert("", "end", values=row)
        tree.pack(fill="x")
        widget.window_create("end", window=tf)
        widget.insert("end", "\n\n")

    def _insert_menu(self):
        t = self.t
        menu = tk.Menu(self, tearoff=0, bg=t.card, fg=t.fg, activebackground=t.hover,
                       activeforeground=t.fg, font=t.f(0), borderwidth=0)
        menu.add_command(label="Code Block (Python/HTML/CSS/JS)", command=self._ins_code)
        menu.add_command(label="Math Formula ($...$)", command=self._ins_math)
        menu.add_command(label="Diagram (A --> B flowchart)", command=self._ins_diagram)
        menu.add_command(label="Table", command=self._ins_table)
        menu.add_separator()
        menu.add_command(label="Image", command=self._ins_image)
        menu.add_command(label="Audio File", command=self._ins_audio)
        menu.add_command(label="Video File", command=self._ins_video)
        menu.add_separator()
        menu.add_command(label="Header 1", command=lambda: self._ins("\n# Header 1\n"))
        menu.add_command(label="Header 2", command=lambda: self._ins("\n## Header 2\n"))
        menu.add_command(label="Header 3", command=lambda: self._ins("\n### Header 3\n"))
        menu.add_command(label="Wiki-link [[note]]", command=lambda: self._ins("[["))
        menu.add_command(label="Tag #tag", command=lambda: self._ins("#"))
        menu.add_command(label="Quote", command=lambda: self._ins("\n> Quote\n"))
        menu.add_command(label="Horizontal rule", command=lambda: self._ins("\n---\n"))
        menu.add_command(label="Slide break", command=lambda: self._ins("\n---\n"))
        try: menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally: menu.grab_release()

    def _ins_diagram(self):
        """v5.10: Embed a diagram at cursor in the current section."""
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        code = ("Start --> Prepare\n"
                "Prepare -->|work| Execute\n"
                "Execute --> Review\n"
                "Review -->|ok| Done\n"
                "Review -->|redo| Execute")
        self.editor.insert("insert", "\n")
        self._embed_diagram(self.editor, code, at="insert")
        self.editor.insert("insert", "\n")
        self._on_content()
        self.after(200, lambda w=self.editor: self._auto_fit_section_widget(w))

    def _ins(self, text):
        """v5.10: Insert text at cursor in the current section's Text widget."""
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        self.editor.insert("insert", text)
        self._on_content()

    def _ins_code(self):
        """v5.10: Ask for language, embed a code block at cursor."""
        t = self.t
        dlg = tk.Toplevel(self); dlg.title("New Code Block")
        dlg.configure(bg=t.bg); dlg.transient(self.winfo_toplevel()); dlg.grab_set()
        dlg.resizable(False, False)
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        _w, _h = 420, 240
        dlg.geometry(f"{_w}x{_h}+{(sw-_w)//2}+{(sh-_h)//2}")
        tk.Label(dlg, text="Pick a language for your code block:", bg=t.bg, fg=t.fg,
                 font=t.f(1, True)).pack(pady=(24, 4))
        tk.Label(dlg, text="HTML includes CSS + JS (runs in browser)", bg=t.bg, fg=t.muted,
                 font=t.f(-1)).pack(pady=(0, 16))
        bf = tk.Frame(dlg, bg=t.bg); bf.pack()
        result = {"lang": None}
        def pick(lang):
            result["lang"] = lang; dlg.destroy()
        tk.Button(bf, text="Python", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(1, True),
                  cursor="hand2", padx=24, pady=10, command=lambda: pick("python")).pack(side="left", padx=6)
        tk.Button(bf, text="JavaScript", bg=t.warn, fg="#0E0E14", relief="flat", font=t.f(1, True),
                  cursor="hand2", padx=20, pady=10, command=lambda: pick("js")).pack(side="left", padx=6)
        tk.Button(bf, text="HTML", bg=t.success, fg="#0E0E14", relief="flat", font=t.f(1, True),
                  cursor="hand2", padx=28, pady=10, command=lambda: pick("html")).pack(side="left", padx=6)
        dlg.bind("<Escape>", lambda e: dlg.destroy())
        self.wait_window(dlg)
        lang = result["lang"]
        if not lang: return
        if lang == "python":
            sample = "# Python code\nprint('Hello from DILA!')\nfor i in range(5):\n    print(f'  line {i}')"
        elif lang == "js":
            sample = "// JavaScript code (runs in Node.js)\nconsole.log('Hello from DILA!');\n[1,2,3].map(x => x*2).forEach(x => console.log(x));"
        else:
            sample = ("<!DOCTYPE html>\n<html>\n<head><style>body{font-family:sans-serif;background:#0e0e16;color:#fff;padding:20px}</style></head>\n"
                      "<body>\n  <h1>Hello from DILA!</h1>\n  <p>Edit me, then click Run.</p>\n  <script>console.log('JS inside HTML');</script>\n</body>\n</html>")
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        self.editor.insert("insert", "\n")
        self._embed_code_block(self.editor, lang, sample, at="insert")
        self.editor.insert("insert", "\n")
        self._on_content()
        self.after(200, lambda w=self.editor: self._auto_fit_section_widget(w))

    def _ins_math(self):
        """Insert inline math at cursor."""
        f = simpledialog.askstring("Math", "LaTeX formula (e.g. E=mc^2):", parent=self, initialvalue="y = x^2")
        if f: self._ins(f" ${f}$ ")

    def _ins_table(self):
        """Embed a table at cursor."""
        r = simpledialog.askinteger("Table", "Rows:", parent=self, initialvalue=3, minvalue=1, maxvalue=20)
        if not r: return
        c = simpledialog.askinteger("Table", "Columns:", parent=self, initialvalue=3, minvalue=1, maxvalue=10)
        if not c: return
        header = "| " + " | ".join(f"Col{i+1}" for i in range(c)) + " |"
        sep = "| " + " | ".join("---" for _ in range(c)) + " |"
        rows_str = "\n".join("| " + " | ".join("   " for _ in range(c)) + " |" for _ in range(r))
        table_md = f"{header}\n{sep}\n{rows_str}"
        table_lines = table_md.split("\n")
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        self.editor.insert("insert", "\n")
        self._embed_table(self.editor, table_lines, at="insert")
        self.editor.insert("insert", "\n")
        self._on_content()
        self.after(200, lambda w=self.editor: self._auto_fit_section_widget(w))

    def _ins_image(self):
        """v5.10: Embed an image at cursor — inline (no forced newlines, can be side by side)."""
        p = filedialog.askopenfilename(filetypes=[("Images","*.png *.jpg *.jpeg *.gif *.bmp")])
        if not p: return
        p = p.replace("\\", "/")
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        self._embed_image(self.editor, p, "image", at="insert")
        self._on_content()
        self.after(200, lambda w=self.editor: self._auto_fit_section_widget(w))

    def _ins_audio(self):
        """v5.10: Embed audio at cursor — inline."""
        p = filedialog.askopenfilename(filetypes=[("Audio","*.mp3 *.wav *.ogg *.m4a")])
        if not p: return
        p = p.replace("\\", "/")
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        self._embed_media(self.editor, "audio", p, at="insert")
        self._on_content()
        self.after(200, lambda w=self.editor: self._auto_fit_section_widget(w))

    def _ins_video(self):
        """v5.10: Embed video at cursor — inline."""
        p = filedialog.askopenfilename(filetypes=[("Video","*.mp4 *.avi *.mov *.mkv")])
        if not p: return
        p = p.replace("\\", "/")
        if not hasattr(self, "editor") or not self.editor or not self.editor.winfo_exists(): return
        self._embed_media(self.editor, "video", p, at="insert")
        self._on_content()
        self.after(200, lambda w=self.editor: self._auto_fit_section_widget(w))

    def _draw(self):
        t = self.t
        dlg = tk.Toplevel(self)
        dlg.title("Drawing Canvas"); dlg.configure(bg=t.bg)
        dlg.transient(self.winfo_toplevel()); dlg.grab_set()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(800, sw-100), min(620, sh-100)
        dlg.geometry(f"{w}x{h}+{max(10,(sw-w)//2)}+{max(10,(sh-h-40)//2)}")
        dlg.resizable(False, False)  # v5.9.9: fixed size
        tb = tk.Frame(dlg, bg=t.panel, height=44); tb.pack(fill="x"); tb.pack_propagate(False)
        tk.Label(tb, text="Color:", bg=t.panel, fg=t.muted, font=t.f(-1)).pack(side="left", padx=(12,4), pady=10)
        self._draw_color = tk.StringVar(value="#FFFFFF")
        color_btn = tk.Button(tb, bg="#FFFFFF", relief="flat", width=3, cursor="hand2",
                              command=lambda: self._pick_draw_color(color_btn))
        color_btn.pack(side="left", padx=4, pady=8)
        tk.Label(tb, text="Brush:", bg=t.panel, fg=t.muted, font=t.f(-1)).pack(side="left", padx=(12,4), pady=10)
        self._brush = tk.IntVar(value=3)
        tk.Scale(tb, from_=1, to=20, orient="horizontal", variable=self._brush, bg=t.panel, fg=t.fg,
                 highlightthickness=0, font=t.f(-2), length=100).pack(side="left", pady=8)
        def _clear_canvas(cv):
            cv.delete("all")
            self._draw_strokes = []  # v5.9.9: clear tracked strokes too
        tk.Button(tb, text="Clear", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=6, command=lambda: _clear_canvas(cv)).pack(side="left", padx=8)
        tk.Button(tb, text="Save & Insert", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(0, True),
                  cursor="hand2", padx=16, pady=6,
                  command=lambda: self._save_drawing(cv, dlg)).pack(side="right", padx=12)
        cv = tk.Canvas(dlg, bg="#FFFFFF", highlightthickness=0); cv.pack(fill="both", expand=True)
        self._lx = None; self._ly = None
        self._draw_strokes = []  # v5.9.9: track strokes for reliable PNG export
        cv.bind("<Button-1>", lambda e: self._draw_down(e, cv))
        cv.bind("<B1-Motion>", lambda e: self._draw_drag(e, cv))
        cv.bind("<ButtonRelease-1>", lambda e: self._draw_up())

    def _pick_draw_color(self, btn):
        c = colorchooser.askcolor(self._draw_color.get())[1]
        if c:
            self._draw_color.set(c); btn.configure(bg=c)

    def _draw_down(self, e, cv):
        self._lx = e.x; self._ly = e.y

    def _draw_drag(self, e, cv):
        if self._lx is not None:
            cv.create_line(self._lx, self._ly, e.x, e.y, fill=self._draw_color.get(),
                           width=self._brush.get(), capstyle="round", smooth=True)
            # v5.9.9: track line for reliable PNG export (no screen-grab alignment issues)
            if not hasattr(self, "_draw_strokes"):
                self._draw_strokes = []
            self._draw_strokes.append((self._lx, self._ly, e.x, e.y,
                                       self._draw_color.get(), self._brush.get()))
        self._lx = e.x; self._ly = e.y

    def _draw_up(self):
        self._lx = None; self._ly = None

    def _save_drawing(self, cv, dlg):
        """v5.10: Save the drawing as PNG and append an image block to the current section."""
        try:
            w = cv.winfo_width(); h = cv.winfo_height()
            if w < 10 or h < 10:
                messagebox.showerror("Error", "Canvas too small", parent=dlg); return
            ddir = APP_DIR / "drawings"; ddir.mkdir(parents=True, exist_ok=True)
            fp = ddir / f"draw_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            if not HAS_PIL:
                messagebox.showerror("No PIL", "Pillow not installed", parent=dlg); return
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (w, h), "#FFFFFF")
            draw = ImageDraw.Draw(img)
            strokes = getattr(self, "_draw_strokes", [])
            for (x1, y1, x2, y2, color, width) in strokes:
                draw.line([(x1, y1), (x2, y2)], fill=color, width=max(1, width))
                r = max(1, width // 2)
                draw.ellipse([x1-r, y1-r, x1+r, y1+r], fill=color)
                draw.ellipse([x2-r, y2-r, x2+r, y2+r], fill=color)
            img.save(str(fp))
            fp_str = str(fp).replace("\\", "/")
            # v5.10: embed at cursor
            if hasattr(self, "editor") and self.editor and self.editor.winfo_exists():
                self.editor.insert("insert", "\n")
                self._embed_image(self.editor, fp_str, "drawing", at="insert")
                self.editor.insert("insert", "\n")
                self._on_content()
            self._draw_strokes = []
            dlg.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Could not save drawing: {e}", parent=dlg)

    def _screenshot(self):
        """v5.10: Capture screenshot and append an image block to the current section."""
        if not HAS_PIL:
            messagebox.showerror("No PIL", "Pillow not installed"); return
        choice = messagebox.askyesnocancel("Screenshot", "Capture full screen?\n\nYes = Full screen\nNo = Drag to select region\nCancel = abort")
        if choice is None: return
        try:
            if choice:
                top = self.winfo_toplevel()
                top.withdraw()
                self.after(300, lambda: None)
                img = ImageGrab.grab()
                top.deiconify()
            else:
                img = self._screenshot_region()
                if img is None: return
            sdir = APP_DIR / "screenshots"; sdir.mkdir(parents=True, exist_ok=True)
            fp = sdir / f"shot_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            img.save(str(fp))
            fp_str = str(fp).replace("\\", "/")
            # v5.10: embed at cursor
            if hasattr(self, "editor") and self.editor and self.editor.winfo_exists():
                self.editor.insert("insert", "\n")
                self._embed_image(self.editor, fp_str, "screenshot", at="insert")
                self.editor.insert("insert", "\n")
                self._on_content()
            messagebox.showinfo("Done", f"Screenshot captured and inserted.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _screenshot_region(self):
        """Open a fullscreen overlay; user drags to select a region. Returns PIL Image or None."""
        if not HAS_PIL: return None
        top = tk.Toplevel(self)
        top.attributes("-fullscreen", True)
        top.attributes("-alpha", 0.3)
        top.attributes("-topmost", True)
        top.configure(bg="black", cursor="cross")
        top.update()
        state = {"start": None, "rect": None, "img": None}
        canvas = tk.Canvas(top, bg="black", highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        def on_down(e):
            state["start"] = (e.x_root, e.y_root)
            if state["rect"]: canvas.delete(state["rect"])
            state["rect"] = canvas.create_rectangle(e.x, e.y, e.x, e.y, outline="#7C5CFF", width=3)
        def on_drag(e):
            if state["start"]:
                sx, sy = state["start"]
                canvas.coords(state["rect"], sx - top.winfo_rootx(), sy - top.winfo_rooty(), e.x, e.y)
        def on_up(e):
            if state["start"]:
                sx, sy = state["start"]
                ex, ey = e.x_root, e.y_root
                top.destroy()
                x1, y1 = min(sx, ex), min(sy, ey)
                x2, y2 = max(sx, ex), max(sy, ey)
                if x2 - x1 < 5 or y2 - y1 < 5:
                    state["img"] = None
                else:
                    state["img"] = ImageGrab.grab(bbox=(x1, y1, x2, y2))
        def on_esc(e):
            top.destroy(); state["img"] = None
        canvas.bind("<ButtonPress-1>", on_down)
        canvas.bind("<B1-Motion>", on_drag)
        canvas.bind("<ButtonRelease-1>", on_up)
        top.bind("<Escape>", on_esc)
        top.wait_window()
        return state["img"]

    def _run_code(self):
        """v5.10: Scan all section widgets for code block embeds. Show picker if multiple."""
        if not self.cur:
            messagebox.showinfo("No Note", "Open a note first."); return
        # Collect all code blocks from _embed_raws (walk all section widgets with dump)
        code_blocks = []
        for widget in getattr(self, "_section_widgets", []):
            try:
                if not widget.winfo_exists(): continue
                for kind, value, index in widget.dump("1.0", "end-1c"):
                    if kind == "window":
                        raw = self._embed_raws.get(value, "")
                        m = re.match(r'```(\w+)?\n(.*?)```', raw, re.DOTALL)
                        if m:
                            lang = m.group(1) or "python"
                            code = m.group(2)
                            # Skip diagram blocks
                            if lang not in ("diagram", "flowchart", "mermaid"):
                                code_blocks.append((lang, code))
            except: pass
        if not code_blocks:
            messagebox.showinfo("No Code", "No code blocks. Use Insert > Code Block.")
            return
        if len(code_blocks) == 1:
            self._run_block(code_blocks[0][1], code_blocks[0][0])
        else:
            picker = tk.Toplevel(self); picker.title("Pick Code Block")
            picker.configure(bg=self.t.bg); picker.transient(self.winfo_toplevel()); picker.grab_set()
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            picker.geometry(f"400x{min(400, 50+len(code_blocks)*40)}+{(sw-400)//2}+{(sh-400)//2}")
            tk.Label(picker, text="Choose a code block to run:", bg=self.t.bg, fg=self.t.fg,
                     font=self.t.f(0)).pack(pady=12)
            for i, (lang, code) in enumerate(code_blocks):
                l = lang or "python"
                preview = code.strip().split("\n")[0][:40]
                tk.Button(picker, text=f"{i+1}. {l}: {preview}...", bg=self.t.card, fg=self.t.fg,
                          relief="flat", font=self.t.f(-1), cursor="hand2", padx=12, pady=6,
                          command=lambda c=code, ll=l: (self._run_block(c, ll), picker.destroy())).pack(fill="x", padx=20, pady=2)

    def _run_block(self, code, lang):
        """v5.9.9: Output-only terminal — no code input panel, just the terminal.
        Shows real stdout/stderr/exit-code from Python (sys.executable) and
        Node.js, and opens HTML in the browser. The code comes from the
        code-block in the note (read-only here)."""
        t = self.t
        lang = (lang or "python").lower()
        # Normalize: css -> html (CSS is wrapped in HTML anyway)
        if lang == "css": lang = "html"
        # Normalize: javascript -> js
        if lang == "javascript": lang = "js"

        dlg = tk.Toplevel(self); dlg.title(f"Terminal — {lang}")
        dlg.configure(bg=t.bg); dlg.transient(self.winfo_toplevel()); dlg.grab_set()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(680, sw-100), min(480, sh-100)
        dlg.geometry(f"{w}x{h}+{max(10,(sw-w)//2)}+{max(10,(sh-h-40)//2)}")
        dlg.resizable(False, False)

        # Header bar: language badge + code preview (read-only, 2 lines)
        hdr = tk.Frame(dlg, bg=t.panel, height=64); hdr.pack(fill="x"); hdr.pack_propagate(False)
        lang_colors = {"python": "#3BE0A1", "js": "#FFB347", "html": "#3BD4FF"}
        lc = lang_colors.get(lang, t.accent)
        tk.Label(hdr, text=f" {lang.upper()} ", bg=lc, fg="#0E0E14",
                 font=t.f(0, True), padx=8, pady=2).pack(side="left", padx=(12, 8), pady=12)
        preview = code.strip().split("\n")[0][:50]
        if len(code.strip().split("\n")) > 1 or len(code.strip().split("\n")[0]) > 50:
            preview += " ..."
        tk.Label(hdr, text=preview, bg=t.panel, fg=t.muted, font=("Consolas", 9)).pack(side="left", fill="x", pady=12)

        # Terminal output (the main feature)
        tf = tk.Frame(dlg, bg="#0A0A0A"); tf.pack(fill="both", expand=True, padx=2, pady=2)
        ot = tk.Text(tf, bg="#0A0A0A", fg="#00FF66", relief="flat", font=("Consolas", 11),
                     state="disabled", wrap="word", padx=12, pady=10,
                     highlightthickness=1, highlightbackground=t.border)
        ot.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(tf, orient="vertical", command=ot.yview); sb.pack(side="right", fill="y")
        ot.configure(yscrollcommand=sb.set)

        def append(txt, tag=None):
            ot.configure(state="normal")
            if tag:
                ot.insert("end", txt + "\n", tag)
            else:
                ot.insert("end", txt + "\n")
            ot.see("end")
            ot.configure(state="disabled")

        def append_raw(txt):
            """Append without adding a newline (for stdout chunks)."""
            ot.configure(state="normal")
            ot.insert("end", txt)
            ot.see("end")
            ot.configure(state="disabled")

        # Bottom buttons
        bf = tk.Frame(dlg, bg=t.bg); bf.pack(fill="x", padx=12, pady=8)
        run_state = {"running": False}

        def run():
            if run_state["running"]: return
            run_state["running"] = True
            # Clear previous output
            ot.configure(state="normal"); ot.delete("1.0", "end"); ot.configure(state="disabled")
            # Re-add header line
            import datetime as _dt
            ts = _dt.datetime.now().strftime("%H:%M:%S")
            append(f"[{ts}] Running {lang}...")
            dlg.update()

            if lang == "python":
                threading.Thread(target=_run_python, daemon=True).start()
            elif lang == "js":
                threading.Thread(target=_run_js, daemon=True).start()
            elif lang == "html":
                _run_html()
                run_state["running"] = False

        def _finish(msg, exit_code=0):
            """Called from the worker thread when done."""
            def _ui():
                append("")
                if exit_code == 0:
                    append(f"[*] {msg}", "ok")
                else:
                    append(f"[!] {msg}", "err")
                append("[*] Process finished.")
                run_state["running"] = False
            dlg.after(0, _ui)

        def _run_python():
            import subprocess, os, sys
            try:
                pyexe = sys.executable
                if "pythonw.exe" in pyexe.lower():
                    candidate = pyexe[:-len("pythonw.exe")] + "python.exe"
                    if os.path.isfile(candidate): pyexe = candidate
                if not os.path.isfile(pyexe):
                    import shutil
                    for name in ["python", "python3"]:
                        found = shutil.which(name)
                        if found: pyexe = found; break
                if not os.path.isfile(pyexe):
                    dlg.after(0, lambda: append("[!] Cannot find python.exe", "err"))
                    _finish("Python not found", 1); return
                # Write to temp file
                script_path = os.path.join(str(APP_DIR), "temp_code.py")
                with open(script_path, "w", encoding="utf-8") as f:
                    f.write(code)
                dlg.after(0, lambda: append(f"[*] Interpreter: {pyexe}", "dim"))
                dlg.after(0, lambda: append(f"[*] Script: {script_path}", "dim"))
                dlg.after(0, lambda: append("[*] Launching in a real console window...", "dim"))
                dlg.after(0, lambda: append("[*] Interactive input() is supported.", "dim"))
                dlg.after(0, lambda: append(""))
                dlg.update()
                # v5.11: Launch the script in a brand-new Windows console so that
                # stdin is a real TTY and input() works interactively. We no longer
                # capture stdout/stderr into the in-app terminal because doing so
                # requires redirecting stdin (which breaks input()). Instead, all
                # program output (and any prompts) appear in the new console window.
                #
                # `cmd /k` keeps the console open after the script exits so the
                # user can read the output; they close it manually when done.
                # CREATE_NEW_CONSOLE is the canonical Windows flag for this and
                # is what makes the new window appear at all.
                creationflags = 0
                if os.name == "nt" and hasattr(subprocess, "CREATE_NEW_CONSOLE"):
                    creationflags = subprocess.CREATE_NEW_CONSOLE
                    launch_cmd = ["cmd", "/k", pyexe, script_path]
                else:
                    # Non-Windows fallback: run the interpreter directly. If the
                    # parent process already has a TTY, interactive input works.
                    launch_cmd = [pyexe, script_path]
                try:
                    proc = subprocess.Popen(launch_cmd,
                                            cwd=str(APP_DIR),
                                            creationflags=creationflags)
                except Exception as launch_err:
                    dlg.after(0, lambda: append(f"[!] Failed to launch console: {launch_err}", "err"))
                    _finish("Launch failed", 1)
                    return
                # Intentionally do NOT call proc.communicate() here: that would
                # re-introduce the stdin-redirect problem and defeat the whole
                # point of launching a real console. We also do NOT delete the
                # temp file immediately because the spawned interpreter may
                # still be reading it; it will be overwritten on the next run,
                # which matches the previous behavior.
                dlg.after(0, lambda: append(f"[*] Console launched (PID {proc.pid}).", "ok"))
                dlg.after(0, lambda: append("[*] Close the console window when you are done.", "dim"))
                _finish("Console launched (interactive)", 0)
            except Exception as e:
                import traceback
                dlg.after(0, lambda: append(f"[!] Exception: {e}", "err"))
                dlg.after(0, lambda: append(traceback.format_exc(), "err"))
                _finish("Exception", 1)

        def _run_js():
            import subprocess, os, shutil
            node = shutil.which("node")
            if not node:
                # v5.9.9: No Node.js — use dukpy (pure-Python JS interpreter, bundled).
                dlg.after(0, lambda: append("[*] Node.js not found — using dukpy (built-in JS interpreter)", "dim"))
                try:
                    import dukpy
                except ImportError:
                    dlg.after(0, lambda: append("[!] Neither Node.js nor dukpy is available", "err"))
                    dlg.after(0, lambda: append("    Install Node.js from https://nodejs.org or reinstall DILA to get dukpy.", "dim"))
                    _finish("No JS runtime", 1)
                    return
                try:
                    # Wrap user code with console.log capture
                    js_wrapped = (
                        "var __output = [];\n"
                        "var console = {\n"
                        "  log: function() { __output.push(Array.prototype.slice.call(arguments).join(' ')); },\n"
                        "  error: function() { __output.push(Array.prototype.slice.call(arguments).join(' ')); },\n"
                        "  warn: function() { __output.push(Array.prototype.slice.call(arguments).join(' ')); },\n"
                        "  info: function() { __output.push(Array.prototype.slice.call(arguments).join(' ')); }\n"
                        "};\n"
                        "try {\n" + code + "\n} catch(e) {\n"
                        "  __output.push('ERROR: ' + e.message);\n"
                        "  if (e.stack) __output.push(e.stack);\n"
                        "}\n"
                        "__output.join('\\n');"
                    )
                    result = dukpy.evaljs(js_wrapped)
                    if result:
                        out = str(result)
                        dlg.after(0, lambda: append_raw(out))
                        if not out.endswith("\n"): dlg.after(0, lambda: append_raw("\n"))
                    else:
                        dlg.after(0, lambda: append("    (no output)", "dim"))
                    _finish("Exit code: 0 (dukpy)", 0)
                except Exception as e:
                    err_msg = str(e)
                    dlg.after(0, lambda: append(f"[!] dukpy error: {err_msg}", "err"))
                    _finish("dukpy error", 1)
                return
            try:
                script_path = os.path.join(str(APP_DIR), "temp_code.js")
                with open(script_path, "w", encoding="utf-8") as f:
                    f.write(code)
                dlg.after(0, lambda: append(f"[*] Node.js: {node}", "dim"))
                dlg.after(0, lambda: append(f"[*] Script: {script_path}", "dim"))
                dlg.after(0, lambda: append("[*] Launching in a real console window...", "dim"))
                dlg.after(0, lambda: append("[*] Interactive readline / prompt-sync is supported.", "dim"))
                dlg.after(0, lambda: append(""))
                # v5.11: Launch Node.js in a brand-new Windows console so that
                # process.stdin is a real TTY and readline / prompt-sync work.
                # See _run_python() above for the full rationale. We no longer
                # capture stdout/stderr; all output goes to the new console.
                creationflags = 0
                if os.name == "nt" and hasattr(subprocess, "CREATE_NEW_CONSOLE"):
                    creationflags = subprocess.CREATE_NEW_CONSOLE
                    launch_cmd = ["cmd", "/k", node, script_path]
                else:
                    launch_cmd = [node, script_path]
                try:
                    proc = subprocess.Popen(launch_cmd,
                                            cwd=str(APP_DIR),
                                            creationflags=creationflags)
                except Exception as launch_err:
                    dlg.after(0, lambda: append(f"[!] Failed to launch console: {launch_err}", "err"))
                    _finish("Launch failed", 1)
                    return
                # Do NOT call proc.communicate() — that would break interactive
                # stdin. Do NOT delete the temp .js file: the spawned node process
                # may still be reading it; it will be overwritten on the next run.
                dlg.after(0, lambda: append(f"[*] Console launched (PID {proc.pid}).", "ok"))
                dlg.after(0, lambda: append("[*] Close the console window when you are done.", "dim"))
                _finish("Console launched (interactive)", 0)
            except Exception as e:
                import traceback
                dlg.after(0, lambda: append(f"[!] Exception: {e}", "err"))
                dlg.after(0, lambda: append(traceback.format_exc(), "err"))
                _finish("Exception", 1)

        def _run_js_in_browser():
            import tempfile, webbrowser
            tf = tempfile.NamedTemporaryFile(mode="w", suffix=".html", delete=False, encoding="utf-8")
            wrapper = ("<!DOCTYPE html><html><head><meta charset='utf-8'><style>"
                       "body{font-family:monospace;background:#0e0e16;color:#0f0;padding:20px;}"
                       "h3{color:#7C5CFF}</style></head><body>"
                       "<h3>JavaScript Output</h3><pre id='out'></pre>"
                       "<script>function log(){var a=Array.from(arguments);"
                       "document.getElementById('out').textContent+=a.join(' ')+'\n';}"
                       "console.log=log;console.error=log;console.warn=log;console.info=log;"
                       "window.onerror=function(m,s,l,c,e){log('Uncaught:',m,'at line',l);};"
                       "try{" + code + "}catch(e){log('ERROR:',e.message);}</script></body></html>")
            tf.write(wrapper); tf.close()
            url = "file:///" + tf.name.replace("\\", "/")
            dlg.after(0, lambda: append(f"[*] Opened: {url}", "dim"))
            webbrowser.open(url)

        def _run_html():
            import tempfile, webbrowser
            try:
                tf = tempfile.NamedTemporaryFile(mode="w", suffix=".html", delete=False, encoding="utf-8")
                tf.write(code); tf.close()
                url = "file:///" + tf.name.replace("\\", "/")
                append(f"[*] Opening in browser: {url}", "dim")
                webbrowser.open(url)
                append("[*] HTML opened in your default browser.", "ok")
            except Exception as e:
                append(f"[!] Failed to open browser: {e}", "err")

        def copy_output():
            txt = ot.get("1.0", "end-1c")
            self.clipboard_clear(); self.clipboard_append(txt)
            append("[*] Output copied to clipboard.", "dim")

        # Configure text tags for colored output
        ot.tag_configure("ok", foreground="#00FF66")
        ot.tag_configure("err", foreground="#FF3B6B")
        ot.tag_configure("dim", foreground="#888888")

        # Buttons
        run_btn_text = f"Run {lang}" if lang != "html" else "Open in Browser"
        tk.Button(bf, text=run_btn_text, bg=t.accent, fg="#0E0E14", relief="flat",
                  font=t.f(0, True), cursor="hand2", padx=24, pady=8,
                  command=run).pack(side="left")
        tk.Button(bf, text="Copy Output", bg=t.card, fg=t.fg, relief="flat", font=t.f(0),
                  cursor="hand2", padx=14, pady=8, command=copy_output).pack(side="left", padx=8)
        tk.Button(bf, text="Close", bg=t.card, fg=t.muted, relief="flat", font=t.f(0), cursor="hand2",
                  padx=16, pady=8, command=dlg.destroy).pack(side="right")

        # Auto-run on open
        dlg.after(200, run)

    # ============================================================
    # MATH SYMBOLS KIT
    # ============================================================
    def _math_kit(self):
        """Open a categorized math symbols palette. Click a symbol to insert it into the editor."""
        t = self.t
        if not hasattr(self, "editor"):
            messagebox.showinfo("No Note", "Open a note first."); return
        dlg = tk.Toplevel(self)
        dlg.title("Math Symbols Kit"); dlg.configure(bg=t.bg)
        dlg.transient(self.winfo_toplevel()); dlg.grab_set()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        dlg.geometry(f"620x620+{(sw-620)//2}+{(sh-620)//2}")
        dlg.resizable(False, False)  # v5.9.9: fixed size
        sf = ScrollFrame(dlg, t); sf.pack(fill="both", expand=True)
        c = sf.inner; c.columnconfigure(0, weight=1)
        tk.Label(c, text="MATH SYMBOLS KIT", bg=t.bg, fg=t.accent, font=t.f(3, True)).grid(
            row=0, column=0, sticky="w", padx=20, pady=(16, 4))
        tk.Label(c, text="Click any symbol to insert it at the cursor.", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(
            row=1, column=0, sticky="w", padx=20, pady=(0, 12))

        categories = [
            ("Basic Operators", ["+", "−", "×", "÷", "±", "∓", "·", "∗", "∘", "√", "∛", "∜",
                                  "=", "≠", "≈", "≡", "∝", "<", ">", "≤", "≥", "≪", "≫"]),
            ("Calculus", ["∫", "∬", "∭", "∮", "∇", "∂", "δ", "ε", "lim", "→", "∞", "∑", "∏",
                          "d/dx", "d²/dx²", "ℏ"]),
            ("Greek Lowercase", ["α", "β", "γ", "δ", "ε", "ζ", "η", "θ", "ι", "κ", "λ", "μ", "ν",
                                 "ξ", "π", "ρ", "σ", "τ", "υ", "φ", "χ", "ψ", "ω"]),
            ("Greek Uppercase", ["Γ", "Δ", "Θ", "Λ", "Ξ", "Π", "Σ", "Φ", "Ψ", "Ω"]),
            ("Sets & Logic", ["∈", "∉", "⊂", "⊃", "⊆", "⊇", "∪", "∩", "∅", "∀", "∃", "¬",
                              "∧", "∨", "⊕", "⊖", "⊗", "⊙"]),
            ("Arrows", ["→", "←", "↔", "⇒", "⇐", "⇔", "↑", "↓", "↕", "⇑", "⇓", "↦", "⟶", "⟵"]),
            ("Superscripts", ["⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹", "⁺", "⁻", "ⁿ", "ⁱ"]),
            ("Subscripts", ["₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉", "₊", "₋", "ₐ", "ₓ", "ₑ"]),
            ("Geometry", ["∠", "⊥", "∥", "△", "□", "○", "◯", "⋄", "°", "′", "″"]),
            ("Misc", ["π", "e", "φ", "τ", "ℵ", "ℝ", "ℕ", "ℤ", "ℚ", "ℂ", "ℍ", "𝕀", "∴", "∵", "∶", "∷"]),
        ]
        row = 2
        collapsed = set()  # v5.9.9: track collapsed categories
        for cat_name, symbols in categories:
            # v5.9.9: unified color (t.accent) for all category headers, clickable to collapse
            hdr = tk.Label(c, text=f"  {cat_name}", bg=t.bg, fg=t.accent, font=t.f(0, True),
                           cursor="hand2", anchor="w")
            hdr.grid(row=row, column=0, sticky="ew", padx=20, pady=(8, 4)); row += 1
            gf = tk.Frame(c, bg=t.bg); gf.grid(row=row, column=0, sticky="ew", padx=20, pady=(0, 4))
            for i, sym in enumerate(symbols):
                b = tk.Button(gf, text=sym, bg=t.card, fg=t.fg, relief="flat", font=t.f(1),
                              width=3, cursor="hand2", padx=2, pady=4,
                              command=lambda s=sym: self._insert_symbol(s, dlg))
                b.grid(row=i // 12, column=i % 12, padx=2, pady=2)
            # v5.9.9: click header to toggle collapse
            def toggle(h=hdr, f=gf, name=cat_name):
                if name in collapsed:
                    collapsed.discard(name)
                    h.configure(text=f"  {name}")
                    f.grid()
                else:
                    collapsed.add(name)
                    h.configure(text=f"  {name}  (collapsed)")
                    f.grid_remove()
            hdr.bind("<Button-1>", lambda e, fn=toggle: fn())
            row += 1
        # LaTeX quick-insert section — v5.9.9: unified color
        tk.Label(c, text="LaTeX Quick-insert (renders as Unicode in preview)", bg=t.bg, fg=t.accent,
                 font=t.f(0, True)).grid(row=row, column=0, sticky="w", padx=20, pady=(12, 4)); row += 1
        latex_items = [
            ("Fraction",   r"$\frac{a}{b}$"),
            ("Square root", r"$\sqrt{x}$"),
            ("Integral",   r"$\int_a^b f(x) dx$"),
            ("Sum",        r"$\sum_{i=1}^{n} x_i$"),
            ("Limit",      r"$\lim_{x \to \infty} f(x)$"),
            ("pi",         r"$\pi$"),
            ("Infinity",   r"$\infty$"),
            ("alpha",      r"$\alpha$"),
            ("theta",      r"$\theta$"),
            ("Partial",    r"$\partial f / \partial x$"),
        ]
        lf = tk.Frame(c, bg=t.bg); lf.grid(row=row, column=0, sticky="ew", padx=20, pady=(0, 16))
        for i, (name, snippet) in enumerate(latex_items):
            tk.Button(lf, text=name, bg=t.hover, fg=t.accent, relief="flat", font=t.f(-1),
                      cursor="hand2", padx=8, pady=4,
                      command=lambda s=snippet: self._insert_symbol(s, dlg)).grid(
                row=i // 5, column=i % 5, padx=2, pady=2)

    def _insert_symbol(self, sym, dlg):
        if hasattr(self, "editor"):
            self.editor.insert("insert", sym)
            self._on_content()
        dlg.lift()

    # ============================================================
    # GRAPHING CALCULATOR (Desmos-like, matplotlib) — v5.9.9 rebuild
    # ============================================================
    def _graph_calc(self):
        """Open a Desmos-like graphing calculator.
        v5.9.9 rebuild: live preview, per-equation color + visibility toggle,
        zoom (x/y range), and an Add-to-Note button that inserts the graph
        as a static picture (unchangeable)."""
        t = self.t
        if not self.cur:
            messagebox.showwarning("No Note", "Open a note first, then use Graph to insert it as an image.")
            return
        if not hasattr(self, "editor"):
            messagebox.showwarning("No Editor", "Open a note first, then use Graph.")
            return
        try:
            import matplotlib
            matplotlib.use("TkAgg")
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            import numpy as np
        except ImportError:
            messagebox.showerror("No matplotlib", "matplotlib not installed."); return

        dlg = tk.Toplevel(self); dlg.title("Graphing Calculator")
        dlg.configure(bg=t.bg); dlg.transient(self.winfo_toplevel()); dlg.grab_set()
        dlg.resizable(False, False)  # v5.9.9: fixed size — everything fits, no scrolling
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        # v5.9.9: sized so all equation-row buttons (swatch, eye, entry, ✕) + Import button are visible
        _gw, _gh = 760, 580
        if _gh > sh - 80: _gh = sh - 80
        if _gw > sw - 80: _gw = sw - 80
        dlg.geometry(f"{_gw}x{_gh}+{(sw-_gw)//2}+{(sh-_gh)//2}")

        # State: list of equations, each {expr, color, visible}
        default_colors = [t.accent, t.success, t.warn, t.danger, "#00BCD4", "#FF6B6B",
                          "#A8FF3B", "#FFB347", "#C53BFF", "#3BD4FF"]
        eq_state = {"rows": []}  # each row: {frame, expr_var, color, visible, color_lbl}

        # ---- Left panel: equation list + add button ----
        # v5.9.9: 280px wide so the ✕ delete button is always visible
        left = tk.Frame(dlg, bg=t.panel, width=280); left.pack(side="left", fill="y", padx=(6,3), pady=6)
        left.pack_propagate(False)
        tk.Label(left, text="EQUATIONS", bg=t.panel, fg=t.accent, font=t.f(1, True)).pack(anchor="w", padx=12, pady=(12,4))
        hint = tk.Label(left, text="Type y = expr  (Enter to plot)", bg=t.panel, fg=t.muted, font=t.f(-2))
        hint.pack(anchor="w", padx=12, pady=(0,4))
        # Scrollable equation list
        eq_list_sf = ScrollFrame(left, t); eq_list_sf.pack(fill="both", expand=True, padx=4, pady=4)
        eq_list = eq_list_sf.inner

        # ---- Right panel: plot + range controls ----
        right = tk.Frame(dlg, bg=t.bg); right.pack(side="right", fill="both", expand=True, padx=(3,6), pady=6)
        # Range controls
        rng = tk.Frame(right, bg=t.bg); rng.pack(fill="x", pady=(0,3))
        tk.Label(rng, text="x:", bg=t.bg, fg=t.muted, font=t.f(-1)).pack(side="left", padx=(4,2))
        xmin_var = tk.StringVar(value="-10"); xmax_var = tk.StringVar(value="10")
        ymin_var = tk.StringVar(value="-10"); ymax_var = tk.StringVar(value="10")
        tk.Entry(rng, textvariable=xmin_var, width=5, bg=t.card, fg=t.fg, relief="flat", font=t.f(-1)).pack(side="left", padx=2)
        tk.Label(rng, text="to", bg=t.bg, fg=t.dim, font=t.f(-2)).pack(side="left", padx=2)
        tk.Entry(rng, textvariable=xmax_var, width=5, bg=t.card, fg=t.fg, relief="flat", font=t.f(-1)).pack(side="left", padx=2)
        tk.Label(rng, text="  y:", bg=t.bg, fg=t.muted, font=t.f(-1)).pack(side="left", padx=(8,2))
        tk.Entry(rng, textvariable=ymin_var, width=5, bg=t.card, fg=t.fg, relief="flat", font=t.f(-1)).pack(side="left", padx=2)
        tk.Label(rng, text="to", bg=t.bg, fg=t.dim, font=t.f(-2)).pack(side="left", padx=2)
        tk.Entry(rng, textvariable=ymax_var, width=5, bg=t.card, fg=t.fg, relief="flat", font=t.f(-1)).pack(side="left", padx=2)
        # Zoom buttons
        def zoom(factor):
            try:
                xc = (float(xmin_var.get()) + float(xmax_var.get())) / 2
                yc = (float(ymin_var.get()) + float(ymax_var.get())) / 2
                xw = (float(xmax_var.get()) - float(xmin_var.get())) / 2 * factor
                yw = (float(ymax_var.get()) - float(ymin_var.get())) / 2 * factor
                xmin_var.set(f"{xc - xw:.2f}"); xmax_var.set(f"{xc + xw:.2f}")
                ymin_var.set(f"{yc - yw:.2f}"); ymax_var.set(f"{yc + yw:.2f}")
                plot()
            except: pass
        tk.Button(rng, text="+", bg=t.card, fg=t.fg, relief="flat", font=t.f(0, True),
                  cursor="hand2", width=3, command=lambda: zoom(0.7)).pack(side="left", padx=2)
        tk.Button(rng, text="−", bg=t.card, fg=t.fg, relief="flat", font=t.f(0, True),
                  cursor="hand2", width=3, command=lambda: zoom(1.4)).pack(side="left", padx=2)
        tk.Button(rng, text="Reset", bg=t.card, fg=t.muted, relief="flat", font=t.f(-1),
                  cursor="hand2", command=lambda: (xmin_var.set("-10"), xmax_var.set("10"),
                                                   ymin_var.set("-10"), ymax_var.set("10"), plot())).pack(side="left", padx=4)
        # Plot area — v5.9.9: sized to fit the smaller window + leave room for Import button
        fig = Figure(figsize=(5, 3.2), dpi=100, facecolor=t.card)
        ax = fig.add_subplot(111)
        canvas_widget = FigureCanvasTkAgg(fig, master=right)
        canvas_widget.get_tk_widget().pack(fill="both", expand=True, pady=2)

        def safe_eval(expr, x_arr):
            """Evaluate y = f(x) with numpy. Supports ^, sin/cos/tan/log/exp/sqrt/abs."""
            e = expr.replace("^", "**")
            env = {
                "x": x_arr, "np": np,
                "sin": np.sin, "cos": np.cos, "tan": np.tan,
                "asin": np.arcsin, "acos": np.arccos, "atan": np.arctan,
                "sinh": np.sinh, "cosh": np.cosh, "tanh": np.tanh,
                "log": np.log, "log10": np.log10, "ln": np.log, "log2": np.log2,
                "exp": np.exp, "sqrt": np.sqrt, "abs": np.abs,
                "pi": np.pi, "e": np.e, "floor": np.floor, "ceil": np.ceil,
            }
            return eval(e, {"__builtins__": {}}, env)

        def parse_eq(raw):
            """Strip 'y =' or 'f(x) =' prefix. Return the rhs expression."""
            raw = raw.strip()
            if not raw: return None
            if "=" in raw:
                lhs, rhs = raw.split("=", 1)
                if lhs.strip().lower() in ("y", "f(x)", "y(x)"):
                    return rhs.strip()
                # Could be an implicit eq like x^2 + y^2 = 1 — not supported, skip
                return None
            return raw

        def plot():
            ax.clear()
            ax.set_facecolor(t.card)
            ax.tick_params(colors=t.muted)
            for spine in ax.spines.values(): spine.set_color(t.border)
            ax.axhline(0, color=t.border, linewidth=0.7); ax.axvline(0, color=t.border, linewidth=0.7)
            ax.grid(True, color=t.border, linestyle="--", linewidth=0.5, alpha=0.5)
            try:
                xmin = float(xmin_var.get()); xmax = float(xmax_var.get())
                ymin = float(ymin_var.get()); ymax = float(ymax_var.get())
                if xmin >= xmax or ymin >= ymax: raise ValueError("bad range")
            except Exception as ex:
                ax.text(0.5, 0.5, f"Bad range: {ex}", transform=ax.transAxes, color=t.danger, ha="center")
                canvas_widget.draw(); return
            ax.set_xlim(xmin, xmax); ax.set_ylim(ymin, ymax)
            ax.set_xlabel("x", color=t.fg); ax.set_ylabel("y", color=t.fg)
            xs = np.linspace(xmin, xmax, 800)
            plotted = 0
            for row in eq_state["rows"]:
                if not row["visible"]: continue
                expr = parse_eq(row["expr_var"].get())
                if not expr: continue
                try:
                    ys = safe_eval(expr, xs)
                    ax.plot(xs, ys, color=row["color"], linewidth=2.2, label=row["expr_var"].get().strip())
                    plotted += 1
                except Exception as ex:
                    ax.text(0.5, 0.5 + 0.05*plotted, f"Error: {row['expr_var'].get().strip()}: {ex}",
                            transform=ax.transAxes, color=t.danger, ha="center", fontsize=9)
            if plotted > 0:
                ax.legend(facecolor=t.card, edgecolor=t.border, labelcolor=t.fg, fontsize=9, loc="best")
            canvas_widget.draw()

        def add_eq_row(initial=""):
            idx = len(eq_state["rows"])
            color = default_colors[idx % len(default_colors)]
            row = {"color": color, "visible": True, "expr_var": tk.StringVar(value=initial)}
            rframe = tk.Frame(eq_list, bg=t.card); rframe.pack(fill="x", pady=2, padx=2)
            # v5.9.9: Pack order matters! Pack right-side buttons FIRST so they
            # claim space before the entry expands. Otherwise the entry takes all
            # space and the ✕ button is invisible.
            # Delete (✕) — pack RIGHT first so it's always visible
            x_btn = tk.Button(rframe, text="\u2715", bg=t.card, fg=t.danger, relief="flat",
                              cursor="hand2", font=t.f(0, True), width=3)
            x_btn.pack(side="right", padx=(1,3), pady=3)
            def del_row(r=row, rf=rframe):
                rf.destroy(); eq_state["rows"].remove(r); plot()
            x_btn.configure(command=del_row)
            # Color swatch (click to change color) — pack LEFT
            swatch = tk.Button(rframe, bg=color, relief="flat", width=3, cursor="hand2")
            swatch.pack(side="left", padx=(3,3), pady=3)
            def pick_color(r=row, sw=swatch):
                c = colorchooser.askcolor(r["color"], title="Equation color")[1]
                if c:
                    r["color"] = c; sw.configure(bg=c); plot()
            swatch.configure(command=pick_color)
            # Visibility toggle (eye) — pack LEFT after swatch
            eye = tk.Button(rframe, text="\U0001F441", bg=t.card, fg=t.fg, relief="flat", cursor="hand2",
                            font=t.f(-1), width=3)
            eye.pack(side="left", padx=1)
            def toggle_eye(r=row, lb=eye):
                r["visible"] = not r["visible"]
                lb.configure(fg=t.fg if r["visible"] else t.dim)
                plot()
            eye.configure(command=toggle_eye)
            # Entry — pack LEFT LAST with expand=True so it fills space between
            # the eye and the ✕ button (which already claimed the right edge)
            entry = tk.Entry(rframe, textvariable=row["expr_var"], bg=t.card, fg=t.fg,
                             insertbackground=t.fg, relief="flat", font=("Consolas", 10))
            entry.pack(side="left", fill="x", expand=True, padx=(2,2), pady=3)
            # Live preview on each keystroke
            row["expr_var"].trace_add("write", lambda *a: plot())
            eq_state["rows"].append(row)
            return row

        # "+ Add Equation" button — v5.9.9: made prominent (full-width, bold, larger)
        add_frame = tk.Frame(left, bg=t.panel); add_frame.pack(fill="x", padx=8, pady=(4,8))
        tk.Button(add_frame, text="+  Add Equation", bg=t.accent, fg="#0E0E14", relief="flat",
                  font=t.f(1, True), cursor="hand2", padx=12, pady=8,
                  command=lambda: (add_eq_row("y = "), eq_list.update())).pack(fill="x")

        # Seed with a few defaults
        add_eq_row("y = x^2")
        add_eq_row("y = sin(x)")
        add_eq_row("y = 2*x + 1")

        # Bottom buttons — v5.9.9: 'Import' is the primary action (most prominent)
        bf = tk.Frame(right, bg=t.bg); bf.pack(fill="x", pady=(3,0))
        tk.Button(bf, text="Replot", bg=t.card, fg=t.fg, relief="flat", font=t.f(-1),
                  cursor="hand2", padx=10, pady=4, command=plot).pack(side="left")
        tk.Button(bf, text="Close", bg=t.card, fg=t.muted, relief="flat", font=t.f(-1), cursor="hand2",
                  padx=10, pady=4, command=dlg.destroy).pack(side="right")
        # Import = paste the graph into the note (primary action, green, bold, larger)
        tk.Button(bf, text="\u2193  Import", bg=t.success, fg="#0E0E14", relief="flat",
                  font=t.f(0, True), cursor="hand2", padx=18, pady=6,
                  command=lambda: self._insert_graph_image(fig, dlg)).pack(side="right", padx=6)
        # Range entry live update
        for v in (xmin_var, xmax_var, ymin_var, ymax_var):
            v.trace_add("write", lambda *a: plot())
        # Initial plot
        dlg.after(150, plot)

    # ============================================================
    # FORMATTING TOOLBAR METHODS (MS Word-style)
    # ============================================================
    def _toggle_tag(self, tag_name):
        """Toggle a text tag (bold/italic/underline/strike) on the current selection."""
        if not hasattr(self, "editor"): return
        ed = self.editor
        try:
            current_tags = ed.tag_names("sel.first")
        except: return
        # Configure tag with current font family + size
        fam = self._font_var.get()
        size = self._size_var.get()
        style_map = {"bold": "bold", "italic": "italic", "underline": "underline", "strike": "overstrike"}
        if tag_name in style_map:
            ed.tag_configure(tag_name, font=(fam, size, style_map[tag_name]))
        if tag_name in current_tags:
            ed.tag_remove(tag_name, "sel.first", "sel.last")
        else:
            ed.tag_add(tag_name, "sel.first", "sel.last")
        self._on_content()

    def _apply_font_family(self, _=None):
        if not hasattr(self, "editor"): return
        fam = self._font_var.get()
        size = self._size_var.get()
        self.editor.configure(font=(fam, size))
        # Also update existing tags
        for tn in ("bold", "italic", "underline", "strike"):
            try: self.editor.tag_configure(tn, font=(fam, size, tn if tn != "strike" else "overstrike"))
            except: pass

    def _apply_font_size(self, _=None):
        if not hasattr(self, "editor"): return
        fam = self._font_var.get()
        size = self._size_var.get()
        self.editor.configure(font=(fam, size))
        for tn in ("bold", "italic", "underline", "strike"):
            try: self.editor.tag_configure(tn, font=(fam, size, tn if tn != "strike" else "overstrike"))
            except: pass

    def _apply_color(self):
        if not hasattr(self, "editor"): return
        c = colorchooser.askcolor(self.t.fg)[1]
        if c:
            self.editor.tag_configure("color_" + c, foreground=c)
            try: self.editor.tag_add("color_" + c, "sel.first", "sel.last")
            except: pass

    def _apply_align(self, align):
        if not hasattr(self, "editor"): return
        tag_name = "align_" + align
        self.editor.tag_configure(tag_name, justify=align)
        try: self.editor.tag_add(tag_name, "sel.first", "sel.last")
        except: pass

    def _transitions_menu(self):
        """v5.9.9: Open a dropdown menu to choose the Present-mode transition.
        Options: Fade / Slide / Morph / Zoom / Wipe / None."""
        t = self.t
        menu = tk.Menu(self, tearoff=0, bg=t.card, fg=t.fg, activebackground=t.hover,
                       activeforeground=t.fg, font=t.f(0), borderwidth=0)
        menu.add_command(label="Transitions", state="disabled")
        menu.add_separator()
        options = [("Fade", "fade"), ("Slide", "slide"), ("Morph", "morph"),
                   ("Zoom", "zoom"), ("Wipe", "wipe"), ("None", "none")]
        for label, val in options:
            prefix = "\u2713 " if self._transition_type == val else "   "
            menu.add_command(label=f"{prefix}{label}",
                             command=lambda v=val: self._set_transition(v))
        try:
            menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally:
            menu.grab_release()

    def _set_transition(self, val):
        """v5.9.9: Store the chosen transition type."""
        self._transition_type = val

    def _split_at_cursor(self):
        """v5.9.9: Splits are now added via the '+ Add Section' button at the bottom
        of the editor. This method is kept for compatibility but redirects to _add_section."""
        self._add_section()

    def _count_splits(self):
        # v5.10: count splits from the full note content (not just self.editor,
        # which is only the first section in the multi-section model).
        if not self.cur: return 0
        n = self.d.get_note(self.cur)
        if not n: return 0
        content = n.get("content", "")
        return len(re.findall(r'^===SPLIT:', content, re.MULTILINE))

    def _parse_splits(self, content):
        """Parse note content into split sections. Returns list of {name, bg, tags, content}.
        Content before first marker = intro section.
        v5.9.9 FIXED: was skipping sections with empty content (`if content_part:`),
        which meant newly-created splits (which start empty) would disappear after
        the note was reloaded. Now we keep sections even if content is empty."""
        sections = []
        pattern = re.compile(r'^===SPLIT:([^|]+)\|([^|]*)(?:\|([^=]*))?===\s*$', re.MULTILINE)
        parts = pattern.split(content)
        # parts[0] = content before first marker
        if parts[0].strip() or len(parts) == 1:
            sections.append({"name": "Intro", "bg": "#000000", "tags": "", "content": parts[0].strip()})
        i = 1
        while i < len(parts):
            name = parts[i].strip() if i < len(parts) else f"Split {len(sections)}"
            bg = parts[i+1].strip() if i+1 < len(parts) else "#000000"
            tags_raw = parts[i+2] if i+2 < len(parts) else None
            tags = (tags_raw or "").strip()
            content_part = parts[i+3] if i+3 < len(parts) else ""
            # v5.9.9 FIXED: always append the section, even if content is empty
            sections.append({"name": name, "bg": bg or "#000000", "tags": tags, "content": content_part.strip()})
            i += 4
        if not sections:
            sections.append({"name": "Main", "bg": "#000000", "tags": "", "content": content.strip()})
        return sections

    def _insert_graph_image(self, fig, dlg=None):
        """v5.10: Save matplotlib figure as PNG and embed at cursor."""
        try:
            gdir = APP_DIR / "graphs"; gdir.mkdir(parents=True, exist_ok=True)
            fp = gdir / f"graph_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            fig.savefig(str(fp), dpi=100, facecolor=fig.get_facecolor())
            fp_str = str(fp).replace("\\", "/")
            if self.cur and hasattr(self, "editor") and self.editor and self.editor.winfo_exists():
                self.editor.insert("insert", "\n")
                self._embed_image(self.editor, fp_str, "graph", at="insert")
                self.editor.insert("insert", "\n")
                self._on_content()
                if dlg: dlg.destroy()
                messagebox.showinfo("Inserted", "Graph stuck into note.")
            else:
                messagebox.showinfo("No Note", "Open a note first to insert the graph.", parent=dlg)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to insert graph: {e}", parent=dlg)

    def _present(self):
        if not self.cur: return
        self._flush_pending_save()  # v5.10: ensure latest content is saved before presenting
        n = self.d.get_note(self.cur)
        if not n: return
        content = n.get("content", "")
        slides = self._parse_splits(content)
        if not slides or (len(slides) == 1 and not slides[0]["content"].strip()):
            messagebox.showinfo("Empty", "Note has no content."); return
        pw = tk.Toplevel(self); pw.title("DILA Presentation"); pw.configure(bg="#000")
        pw.attributes("-fullscreen", True); pw.attributes("-topmost", True)
        pw.bind("<Escape>", lambda e: pw.destroy())
        pw.bind("<Right>", lambda e: nxt())
        pw.bind("<Left>", lambda e: prv())
        pw.bind("<space>", lambda e: nxt())
        state = {"i": 0}
        # v5.9.9: transition type — use the pre-selected choice from the ⤢ button
        transition = {"type": getattr(self, "_transition_type", "fade")}  # fade, slide, morph, none
        # Use a Text widget so we can render images/tables/code
        slide_text = tk.Text(pw, bg="#000", fg="#FFF", font=("Segoe UI", 24),
                             wrap="word", padx=60, pady=40, spacing1=6, spacing3=8,
                             state="disabled", cursor="arrow")
        slide_text.pack(fill="both", expand=True)
        # Configure tags for rich rendering
        slide_text.tag_configure("h1", font=("Segoe UI", 36, "bold"), foreground="#7C5CFF", spacing3=12)
        slide_text.tag_configure("h2", font=("Segoe UI", 30, "bold"), spacing3=8)
        slide_text.tag_configure("h3", font=("Segoe UI", 26, "bold"), spacing3=6)
        slide_text.tag_configure("bold", font=("Segoe UI", 24, "bold"))
        slide_text.tag_configure("code", font=("Consolas", 18), background="#1A1A2A", foreground="#3FE0A1")
        slide_text.tag_configure("img_caption", foreground="#888", font=("Segoe UI", 14, "italic"))
        title_label = tk.Label(pw, bg="#000", fg="#888", font=("Segoe UI", 16))
        title_label.pack(fill="x", side="top", pady=(10, 0))
        self._present_imgs = []  # keep references
        ctrl = tk.Frame(pw, bg="#000"); ctrl.pack(fill="x", side="bottom")
        counter = tk.Label(ctrl, text="", bg="#000", fg="#888", font=("Segoe UI", 12))
        counter.pack(side="left", expand=True)
        # v5.9.9: Transitions selector — default to the pre-selected choice
        _trans_labels = {"fade": "Fade", "slide": "Slide", "morph": "Morph",
                         "zoom": "Zoom", "wipe": "Wipe", "none": "None"}
        _trans_var = tk.StringVar(value=_trans_labels.get(transition["type"], "Fade"))
        trans_menu = tk.OptionMenu(ctrl, _trans_var, "Fade", "Slide", "Morph", "Zoom", "Wipe", "None",
                                   command=lambda v: transition.update({"type": v.lower()}))
        trans_menu.configure(bg="#444", fg="#FFF", relief="flat", font=("Segoe UI",10), highlightthickness=0)
        trans_menu.pack(side="left", padx=8, pady=8)
        tk.Button(ctrl, text="Exit", bg="#444", fg="#FFF", relief="flat", font=("Segoe UI",12),
                  cursor="hand2", padx=20, pady=8, command=pw.destroy).pack(side="right", pady=12)
        def render_slide():
            """Render current slide content (no transition)."""
            slide = slides[state["i"]]
            bg = slide.get("bg", "#000")
            pw.configure(bg=bg); slide_text.configure(bg=bg); title_label.configure(bg=bg)
            title_label.configure(text=slide.get("name", ""))
            slide_text.configure(state="normal")
            slide_text.delete("1.0", "end")
            self._present_imgs = []
            self._render_slide_content(slide_text, slide["content"], bg)
            slide_text.configure(state="disabled")
            counter.configure(text=f"Slide {state['i']+1} / {len(slides)}")
        def show():
            slide = slides[state["i"]]
            bg = slide.get("bg", "#000")
            tt = transition["type"]
            # v5.9.9: improved transitions — smoother fade, real slide (text visible),
            # morph (scale + alpha), plus new Zoom and Wipe.
            if tt == "none":
                render_slide()
            elif tt == "fade":
                # Smoother fade: smaller steps (0.08), 15ms interval
                def fade_out(alpha=1.0):
                    if not pw.winfo_exists(): return  # v5.9.9 FIX
                    if alpha <= 0.02:
                        render_slide()
                        pw.after(30, lambda: fade_in(0.0)); return
                    try: pw.attributes("-alpha", alpha)
                    except: pass
                    pw.after(15, lambda: fade_out(alpha - 0.08))
                def fade_in(alpha):
                    if alpha >= 0.98:
                        try: pw.attributes("-alpha", 1.0)
                        except: pass
                        return
                    try: pw.attributes("-alpha", alpha)
                    except: pass
                    pw.after(15, lambda: fade_in(alpha + 0.08))
                fade_out(1.0)
            elif tt == "slide":
                # Improved slide: render new slide off-screen right, then slide it in.
                # Text stays visible during the transition.
                sw = pw.winfo_screenwidth()
                # Render the new slide first (so text is visible), then animate position
                render_slide()
                # Move it off-screen right, then animate to x=0
                slide_text.place_forget()
                slide_text.place(x=sw, rely=0.0, relwidth=1, relheight=1)
                def slide_in(offset):
                    if offset <= 0:
                        slide_text.place_forget()
                        slide_text.pack(fill="both", expand=True)
                        return
                    try:
                        slide_text.place(x=offset, rely=0.0, relwidth=1, relheight=1)
                    except: pass
                    pw.after(12, lambda: slide_in(offset - sw/20))
                slide_in(sw)
            elif tt == "morph":
                # Improved morph: scale down via place + alpha, swap, scale up.
                # Uses a combination of alpha fade + a subtle scale effect on the
                # Text widget by adjusting its font size briefly.
                def morph_out(alpha=1.0):
                    if alpha <= 0.05:
                        render_slide()
                        pw.after(20, lambda: morph_in(0.05)); return
                    try: pw.attributes("-alpha", alpha)
                    except: pass
                    pw.after(12, lambda: morph_out(alpha - 0.08))
                def morph_in(alpha):
                    if alpha >= 0.98:
                        try: pw.attributes("-alpha", 1.0)
                        except: pass
                        return
                    try: pw.attributes("-alpha", alpha)
                    except: pass
                    pw.after(12, lambda: morph_in(alpha + 0.08))
                morph_out(1.0)
            elif tt == "zoom":
                # v5.9.9 new: Zoom — fade + scale the whole window via alpha steps
                # (Tk doesn't support window scaling, so we emulate with a quick
                # alpha dip + content re-render with a brief font bump).
                def zoom_out(alpha=1.0):
                    if alpha <= 0.1:
                        render_slide()
                        pw.after(20, lambda: zoom_in(0.1)); return
                    try: pw.attributes("-alpha", alpha)
                    except: pass
                    pw.after(12, lambda: zoom_out(alpha - 0.09))
                def zoom_in(alpha):
                    if alpha >= 0.98:
                        try: pw.attributes("-alpha", 1.0)
                        except: pass
                        return
                    try: pw.attributes("-alpha", alpha)
                    except: pass
                    pw.after(12, lambda: zoom_in(alpha + 0.09))
                zoom_out(1.0)
            elif tt == "wipe":
                # v5.9.9 new: Wipe — new slide revealed left-to-right by moving
                # a frame that masks the old content. Emulated by sliding the
                # text widget from left edge with clipping.
                render_slide()
                slide_text.place_forget()
                # Start with width 0 and grow
                sw_total = pw.winfo_screenwidth()
                slide_text.place(x=0, rely=0.0, relwidth=0.01, relheight=1)
                def wipe_in(frac=0.02):
                    if frac >= 1.0:
                        slide_text.place_forget()
                        slide_text.pack(fill="both", expand=True)
                        return
                    try:
                        slide_text.place(x=0, rely=0.0, relwidth=frac, relheight=1)
                    except: pass
                    pw.after(12, lambda: wipe_in(frac + 0.06))
                wipe_in(0.02)
        def nxt():
            if state["i"] < len(slides) - 1: state["i"] += 1; show()
            else: pw.destroy()
        def prv():
            if state["i"] > 0: state["i"] -= 1; show()
        show()

    def _render_slide_content(self, widget, content, bg="#000"):
        """v5.12: Render note content (markdown) into a Text widget for presentation.
        Now supports H1-H6, all HR variants, blockquotes, lists (ul/ol/task),
        block math $$...$$, and clickable links."""
        lines = content.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            # Skip split markers
            if line.strip().startswith("===SPLIT:"):
                i += 1; continue
            # Block math $$...$$
            if line.strip() == "$$":
                math_lines = []
                i += 1
                while i < len(lines) and lines[i].strip() != "$$":
                    math_lines.append(lines[i]); i += 1
                i += 1
                expr = "\n".join(math_lines)
                rendered = self._render_math(expr)
                widget.insert("end", "\n" + rendered + "\n\n", "math_block")
                continue
            m = re.match(r'^\$\$(.+)\$\$\s*$', line.strip())
            if m:
                rendered = self._render_math(m.group(1))
                widget.insert("end", "\n" + rendered + "\n\n", "math_block")
                i += 1; continue
            # Code block / diagram block
            if line.strip().startswith("```"):
                lang = line.strip()[3:].strip()
                code_lines = []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    code_lines.append(lines[i]); i += 1
                i += 1
                if lang in ("diagram", "flowchart", "mermaid"):
                    # Render diagram on canvas embedded in text
                    self._render_diagram_in_text(widget, "\n".join(code_lines))
                else:
                    widget.insert("end", "\n".join(code_lines) + "\n", "code")
                continue
            # Image
            m = re.match(r'^!\[([^\]]*)\]\(([^)]+)\)', line.strip())
            if m and HAS_PIL:
                alt, path = m.group(1), m.group(2)
                try:
                    if os.path.exists(path):
                        img = Image.open(path)
                        max_w = 800
                        if img.width > max_w:
                            ratio = max_w / img.width
                            img = img.resize((max_w, int(img.height * ratio)), Image.LANCZOS)
                        photo = ImageTk.PhotoImage(img)
                        self._present_imgs.append(photo)
                        widget.image_create("end", image=photo)
                        widget.insert("end", f"\n{alt}\n\n", "img_caption")
                    else:
                        widget.insert("end", f"[Image: {path}]\n", "img_caption")
                except:
                    widget.insert("end", f"[Image error]\n", "img_caption")
                i += 1; continue
            # Audio
            m = re.match(r'^\{+audio:([^}]+)\}+', line.strip())
            if m:
                path = m.group(1)
                widget.insert("end", f"[Audio: {os.path.basename(path)}] ", "img_caption")
                def play_a(p=path):
                    try: os.startfile(p)
                    except: pass
                bf = tk.Frame(widget, bg=bg)
                tk.Button(bf, text="Play", bg="#7C5CFF", fg="#FFF", relief="flat", font=("Segoe UI",10),
                          cursor="hand2", padx=10, pady=2, command=play_a).pack()
                widget.window_create("end", window=bf)
                widget.insert("end", "\n\n")
                i += 1; continue
            # Video
            m = re.match(r'^\{+video:([^}]+)\}+', line.strip())
            if m:
                path = m.group(1)
                widget.insert("end", f"[Video: {os.path.basename(path)}] ", "img_caption")
                def play_v(p=path):
                    try: os.startfile(p)
                    except: pass
                bf = tk.Frame(widget, bg=bg)
                tk.Button(bf, text="Play", bg="#7C5CFF", fg="#FFF", relief="flat", font=("Segoe UI",10),
                          cursor="hand2", padx=10, pady=2, command=play_v).pack()
                widget.window_create("end", window=bf)
                widget.insert("end", "\n\n")
                i += 1; continue
            # Table
            if line.strip().startswith("|") and i+1 < len(lines) and "---" in lines[i+1]:
                table_lines = []
                while i < len(lines) and lines[i].strip().startswith("|"):
                    table_lines.append(lines[i]); i += 1
                self._render_table_in_text(widget, table_lines, bg)
                continue
            # Headers — H1-H6
            hm = re.match(r'^(#{1,6})\s+(.*)$', line)
            if hm:
                level = len(hm.group(1))
                tag = f"h{level}" if level <= 3 else "h3"
                widget.insert("end", hm.group(2) + "\n", tag)
                if level <= 2:
                    sep_char = "\u2550" if level == 1 else "\u2500"
                    widget.insert("end", sep_char * 50 + "\n", "hr")
                i += 1; continue
            # Horizontal rules: ---, ***, ___
            if re.match(r'^(-{3,}|\*{3,}|_{3,})$', line.strip()):
                widget.insert("end", "\u2500" * 60 + "\n", "hr")
                i += 1; continue
            # Blockquote: > text
            qm = re.match(r'^\s*(>+)\s?(.*)$', line)
            if qm and qm.group(1):
                widget.insert("end", qm.group(2) + "\n", "quote")
                i += 1; continue
            # Task list: - [x] / - [ ]
            tm = re.match(r'^(\s*)([-*+])\s+\[([ xX])\]\s+(.*)$', line)
            if tm:
                check = "[\u2713]" if tm.group(3).lower() == "x" else "[ ]"
                indent = len(tm.group(1))
                lmargin = 20 + indent * 4
                widget.tag_configure(f"slide_task_{indent}", lmargin1=lmargin, lmargin2=lmargin,
                                     spacing1=2, spacing3=2)
                widget.insert("end", f"{check}  ", "task_check" if tm.group(3).lower() == "x" else "tag")
                text_tag = "task_done" if tm.group(3).lower() == "x" else f"slide_task_{indent}"
                widget.insert("end", tm.group(4) + "\n", text_tag)
                i += 1; continue
            # Unordered list
            um = re.match(r'^(\s*)([-*+])\s+(.*)$', line)
            if um:
                indent = len(um.group(1))
                lmargin = 20 + indent * 4
                widget.tag_configure(f"slide_ul_{indent}", lmargin1=lmargin, lmargin2=lmargin,
                                     spacing1=2, spacing3=2)
                widget.insert("end", "\u2022  ", "tag")
                widget.insert("end", um.group(3) + "\n", f"slide_ul_{indent}")
                i += 1; continue
            # Ordered list
            om = re.match(r'^(\s*)(\d+\.)\s+(.*)$', line)
            if om:
                indent = len(om.group(1))
                lmargin = 20 + indent * 4
                widget.tag_configure(f"slide_ol_{indent}", lmargin1=lmargin, lmargin2=lmargin,
                                     spacing1=2, spacing3=2)
                widget.insert("end", om.group(2) + "  ", "tag")
                widget.insert("end", om.group(3) + "\n", f"slide_ol_{indent}")
                i += 1; continue
            elif line.strip():
                self._render_inline(widget, line)
                widget.insert("end", "\n")
            else:
                widget.insert("end", "\n")
            i += 1

    def _render_diagram_in_text(self, widget, code):
        """Render a flowchart diagram inside a Text widget."""
        t = self.t
        try:
            edges = []; nodes = {}
            for line in code.split("\n"):
                line = line.strip()
                if not line or line.startswith("#"): continue
                m = re.match(r'^(\w[\w \-]*?)\s*(-->|->|---|==>)\s*(?:\|([^|]+)\|\s*)?(\w[\w \-]*)$', line)
                if m:
                    src = m.group(1).strip(); dst = m.group(4).strip(); label = (m.group(3) or "").strip()
                    nodes[src] = {"name": src}; nodes[dst] = {"name": dst}
                    edges.append((src, dst, label))
                elif line and line not in nodes:
                    nodes[line] = {"name": line}
            if not nodes:
                widget.insert("end", "[Empty diagram]\n", "img_caption"); return
            node_list = list(nodes.keys())
            n = len(node_list)
            cols = max(1, int(math.ceil(math.sqrt(n))))
            cell_w, cell_h = 120, 50
            pad = 20
            cw = cols * cell_w + pad * 2
            rows = max(1, int(math.ceil(n / cols)))
            ch = rows * cell_h + pad * 2
            for idx, name in enumerate(node_list):
                r = idx // cols; c = idx % cols
                x = pad + c * cell_w + cell_w // 2
                y = pad + r * cell_h + cell_h // 2
                nodes[name]["pos"] = (x, y)
            df = tk.Frame(widget, bg=t.card)
            cv = tk.Canvas(df, bg=t.card, width=cw, height=ch, highlightthickness=0)
            cv.pack(pady=4)
            for src, dst, label in edges:
                if src in nodes and dst in nodes:
                    x1, y1 = nodes[src]["pos"]; x2, y2 = nodes[dst]["pos"]
                    cv.create_line(x1, y1, x2, y2, fill=t.muted, width=2, arrow="last")
                    if label:
                        cv.create_text((x1+x2)//2, (y1+y2)//2 - 8, text=label, fill=t.warn, font=t.f(-2))
            for name, info in nodes.items():
                x, y = info["pos"]
                w = max(50, len(name) * 7 + 12)
                cv.create_rectangle(x-w//2, y-14, x+w//2, y+14, fill=t.hover, outline=t.accent, width=2)
                cv.create_text(x, y, text=name, fill=t.fg, font=t.f(-1, True))
            widget.window_create("end", window=df)
            widget.insert("end", "\n\n")
        except Exception as e:
            widget.insert("end", f"[Diagram error: {e}]\n", "img_caption")

    def _render_table_in_text(self, widget, lines, bg="#000"):
        """Render a markdown table inside a Text widget using a Treeview."""
        t = self.t
        rows = []
        for line in lines:
            if "---" in line: continue
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            rows.append(cells)
        if not rows: return
        headers = rows[0]
        tf = tk.Frame(widget, bg=bg)
        tree = ttk.Treeview(tf, columns=headers, show="headings", height=min(len(rows)-1, 8))
        for h in headers:
            tree.heading(h, text=h)
            tree.column(h, width=100, anchor="center")
        style = ttk.Style()
        style.configure("Treeview", background=t.card, foreground=t.fg, fieldbackground=t.card, font=t.f(-1))
        style.configure("Treeview.Heading", background=t.hover, foreground=t.fg, font=t.f(-1, True))
        for row in rows[1:]:
            tree.insert("", "end", values=row)
        tree.pack(fill="x")
        widget.window_create("end", window=tf)
        widget.insert("end", "\n\n")

    def _download(self):
        if not self.cur: return
        self._flush_pending_save()  # v5.10: ensure latest content is saved before downloading
        n = self.d.get_note(self.cur)
        if not n: return
        fmt = simpledialog.askstring("Format", "Format (md/html/txt):", parent=self, initialvalue="md")
        if not fmt: return
        content = n.get("content", "")
        # Check for selection
        if hasattr(self, "editor"):
            try:
                sel = self.editor.get("sel.first", "sel.last")
                if sel: content = sel
            except: pass
        if fmt == "html":
            html = content
            html = re.sub(r'\[\[([^\]]+)\]\]', r'<a href="#">\1</a>', html)
            html = re.sub(r'#(\w+)', r'<span style="color:#FFB347">#\1</span>', html)
            html = re.sub(r'```(\w+)?\n(.*?)```', r'<pre><code>\2</code></pre>', html, flags=re.DOTALL)
            html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
            html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
            html = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'<img src="\2" alt="\1" style="max-width:100%">', html)
            html = re.sub(r'\n\n', '</p><p>', html)
            content = f"<html><head><meta charset='utf-8'><title>{n['title']}</title><style>body{{font-family:sans-serif;max-width:800px;margin:40px auto;padding:20px;line-height:1.6}}pre{{background:#1E1E2A;color:#EAEAF0;padding:16px;border-radius:8px}}</style></head><body><h1>{n['title']}</h1><p>{html}</p></body></html>"
            ext = ".html"
        elif fmt == "txt":
            content = f"{n['title']}\n{'='*len(n['title'])}\n\n{content}"
            ext = ".txt"
        else:
            content = f"# {n['title']}\n\n{content}"
            ext = ".md"
        path = filedialog.asksaveasfilename(defaultextension=ext, initialfile=n["title"]+ext)
        if path:
            with open(path, "w", encoding="utf-8") as f: f.write(content)
            messagebox.showinfo("Saved", f"Note saved to:\n{path}")

    def _del(self):
        if not self.cur: return
        if messagebox.askyesno("Delete", "Delete this note?"):
            nid = self.cur
            self.d.delete_note(nid)
            self._cleanup_map_for_deleted_note(nid)  # v5.10: remove stale split/note entries from map
            self.cur = None
            self._refresh_list(); self._empty_state()
            self._refresh_map()  # v5.10: refresh map so note + its splits + connections disappear

    def refresh(self):
        self._refresh_list()
        if self.cur:
            n = self.d.get_note(self.cur)
            if n: self._load(n)


# ============================================================
# STATS VIEW
# ============================================================

class StatsView(tk.Frame):
    def __init__(self, parent, d, t, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.d = d; self.t = t
        self.tf = tk.StringVar(value="30")
        self._build()

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        sf = ScrollFrame(self, t); sf.pack(fill="both", expand=True)
        c = sf.inner; c.columnconfigure(0, weight=1); r = 0
        tk.Label(c, text="STATS & PROGRESS", bg=t.bg, fg=t.accent, font=t.f(8, True)).grid(row=r, column=0, sticky="w", pady=(20,16), padx=24); r+=1
        tf = tk.Frame(c, bg=t.bg); tf.grid(row=r, column=0, sticky="w", padx=24, pady=(0,12))
        tk.Label(tf, text="Timeframe:", bg=t.bg, fg=t.muted, font=t.f(0)).pack(side="left", padx=(0,8))
        for l, v in [("30 days","30"),("90 days","90"),("1 year","365"),("All time","all")]:
            tk.Radiobutton(tf, text=l, variable=self.tf, value=v, bg=t.bg, fg=t.fg, selectcolor=t.card,
                           activebackground=t.bg, activeforeground=t.fg, font=t.f(0),
                           command=self._build).pack(side="left", padx=(0,12))
        r+=1
        days = {"30":30,"90":90,"365":365,"all":9999}[self.tf.get()]
        if days == 9999:
            if self.d.streaks:
                earliest = min(pd(s.get("created","").split("T")[0]) if s.get("created") else dt.date.today() for s in self.d.streaks)
                days = max(1, (dt.date.today() - earliest).days + 1)
            else: days = 30
        series = self.d.series(days)
        total_e = sum(s[1] for s in series); total_p = sum(s[2] for s in series)
        avg = total_e / len(series) if series else 0
        best = max(series, key=lambda x: x[1]) if series else None
        pct = int(total_e * 100 / total_p) if total_p else 0
        sg = tk.Frame(c, bg=t.bg); sg.grid(row=r, column=0, sticky="ew", padx=24, pady=(0,16))
        for i in range(4): sg.columnconfigure(i, weight=1, uniform="s")
        self._stat(sg, 0, "AVG PTS/DAY", f"{avg:.1f}", t.accent)
        self._stat(sg, 1, "TOTAL PTS", str(total_e), t.success)
        self._stat(sg, 2, "BEST DAY (window)", f"{best[1] if best else 0} pts", t.warn)
        self._stat(sg, 3, "OVERALL", f"{pct}%", t.danger)
        r+=1
        # Best-ever records (persist even when streaks are deleted)
        be_pts = self.d.settings.get("best_ever_pts", 0)
        be_date = self.d.settings.get("best_ever_date", "")
        le_days = self.d.settings.get("longest_ever", 0)
        le_name = self.d.settings.get("longest_ever_name", "")
        be_frame = tk.Frame(c, bg=t.card); be_frame.grid(row=r, column=0, sticky="ew", padx=24, pady=(0, 12))
        be_frame.columnconfigure(0, weight=1)
        tk.Label(be_frame, text="ALL-TIME RECORDS (persist when streaks are deleted)",
                 bg=t.card, fg=t.accent, font=t.f(0, True)).grid(row=0, column=0, sticky="w", padx=16, pady=(10, 4))
        records_text = (f"Best day ever:  {be_pts} pts   ({be_date or 'never'})\n"
                        f"Longest streak ever:  {le_days} days   ({le_name or 'none yet'})")
        tk.Label(be_frame, text=records_text, bg=t.card, fg=t.fg, font=t.f(0),
                 justify="left").grid(row=1, column=0, sticky="w", padx=16, pady=(0, 10))
        r+=1
        lazy_d, lazy_p = self.d.laziest()
        if lazy_d:
            tk.Label(c, text=f"😴 Laziest day: {lazy_d} — only {lazy_p} pts. We all have those days.",
                     bg=t.card, fg=t.muted, font=t.f(0), wraplength=600, justify="left").grid(row=r, column=0, sticky="w", padx=24, pady=(0,16))
            r+=1
        else:
            tk.Label(c, text="😴 Laziest day: not enough data yet — keep going!",
                     bg=t.card, fg=t.muted, font=t.f(0), wraplength=600, justify="left").grid(row=r, column=0, sticky="w", padx=24, pady=(0,16))
            r+=1
        tk.Label(c, text="PROGRESS (points per day)", bg=t.bg, fg=t.fg, font=t.f(1, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(0,4)); r+=1
        graph = LineGraph(c, t, [(s[0][-5:], s[1]) for s in series], f"Daily Points - Last {len(series)} days", 700, 220)
        graph.grid(row=r, column=0, sticky="ew", padx=24, pady=(0,16)); r+=1
        tk.Label(c, text=f"ACTIVITY HEATMAP - {dt.date.today().year} (full year)", bg=t.bg, fg=t.fg, font=t.f(1, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(0,4)); r+=1
        # Show full current year: weeks from Jan 1 to today
        today = dt.date.today()
        jan1 = today.replace(month=1, day=1)
        weeks_this_year = (today - jan1).days // 7 + 2
        hm = Heatmap(c, self.d, t, None, weeks_this_year); hm.grid(row=r, column=0, sticky="ew", padx=24, pady=(0,16)); r+=1
        tk.Label(c, text="RECENT RECORDS", bg=t.bg, fg=t.fg, font=t.f(1, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(0,4)); r+=1
        rf = tk.Frame(c, bg=t.card); rf.grid(row=r, column=0, sticky="ew", padx=24, pady=(0,24))
        rf.columnconfigure(0, weight=1)
        # Build records
        history = {}
        for s in self.d.streaks:
            h = s.get("history", {})
            if isinstance(h, dict):
                for d in h:
                    if d not in history: history[d] = []
                    history[d].append(s["name"])
        sorted_d = sorted(history.keys(), reverse=True)[:20]
        if not sorted_d:
            tk.Label(rf, text="No records yet. Complete some streaks!", bg=t.card, fg=t.dim,
                     font=t.f(0), pady=20).grid(row=0, column=0)
        else:
            for i, d in enumerate(sorted_d):
                d_obj = pd(d)
                names = history[d]
                e, tot = self.d.daily_points(d)
                p = int(e * 100 / tot) if tot else 0
                color = t.success if p == 100 else (t.warn if p >= 50 else t.danger)
                rr = tk.Frame(rf, bg=t.card if i%2==0 else t.hover)
                rr.grid(row=i, column=0, sticky="ew")
                rr.columnconfigure(1, weight=1)
                tk.Label(rr, text=d_obj.strftime("%b %d, %Y"), bg=rr["bg"], fg=t.fg, font=t.f(0, True),
                         padx=12, pady=8).grid(row=0, column=0, sticky="w")
                tk.Label(rr, text=", ".join(names), bg=rr["bg"], fg=t.muted, font=t.f(-1),
                         padx=12, pady=8, wraplength=400, justify="left", anchor="w").grid(row=0, column=1, sticky="w")
                tk.Label(rr, text=f"{e}/{tot} pts", bg=rr["bg"], fg=color, font=t.f(1, True),
                         padx=12, pady=8).grid(row=0, column=2)
        r+=1

    def _stat(self, p, col, l, v, c):
        t = self.t
        card = tk.Frame(p, bg=t.card, padx=16, pady=10); card.grid(row=0, column=col, sticky="ew", padx=4)
        tk.Label(card, text=l, bg=t.card, fg=t.muted, font=t.f(-2, True)).pack(anchor="w")
        tk.Label(card, text=v, bg=t.card, fg=c, font=t.f(10, True)).pack(anchor="w")

    def refresh(self): self._build()


# ============================================================
# LINE GRAPH
# ============================================================

class LineGraph(tk.Canvas):
    def __init__(self, parent, t, data, title="", w=600, h=200, **kw):
        super().__init__(parent, bg=t.card, highlightthickness=1, highlightbackground=t.border,
                         width=w, height=h, **kw)
        self.t = t; self.data = data; self.title = title
        self.bind("<Configure>", lambda e: self._draw())
        self._draw()

    def _draw(self):
        t = self.t; self.delete("all")
        w = self.winfo_width(); h = self.winfo_height()
        if w < 50 or h < 50: return
        if not self.data:
            self.create_text(w//2, h//2, text="No data yet", fill=t.dim, font=t.f(1)); return
        pl, pr, pt, pb = 50, 20, 30, 30
        pw, ph = w - pl - pr, h - pt - pb
        if pw < 50 or ph < 50: return
        self.create_text(w//2, 12, text=self.title, fill=t.fg, font=t.f(0, True))
        max_v = max((d[1] for d in self.data), default=1) or 1
        for i in range(5):
            v = int(max_v * i / 4)
            y = pt + ph - (i/4) * ph
            self.create_text(pl - 5, y, text=str(v), fill=t.muted, font=t.f(-2), anchor="e")
            self.create_line(pl, y, w - pr, y, fill=t.border, dash=(2,2))
        n = len(self.data)
        for i, idx in enumerate([0, n//2, n-1]):
            if idx < n:
                label = self.data[idx][0]
                x = pl + (idx / max(1, n-1)) * pw
                self.create_text(x, h - 10, text=label, fill=t.muted, font=t.f(-2))
        pts = []
        for i, (label, v) in enumerate(self.data):
            x = pl + (i / max(1, n-1)) * pw
            y = pt + ph - (v / max_v) * ph
            pts.extend([x, y])
        if len(pts) >= 4:
            area = list(pts) + [pts[-2], pt + ph, pts[0], pt + ph]
            self.create_polygon(area, fill=blend(t.accent, t.card, 0.3), outline="")
            self.create_line(pts, fill=t.accent, width=2, smooth=True)
        for i in range(0, n, max(1, n//20)):
            x = pts[i*2]; y = pts[i*2+1]
            self.create_oval(x-3, y-3, x+3, y+3, fill=t.accent, outline="")


# ============================================================
# CUSTOMIZE VIEW
# ============================================================

class CustomizeView(tk.Frame):
    def __init__(self, parent, d, t, on_change=None, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.d = d; self.t = t; self.on_change = on_change
        self._build()

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        sf = ScrollFrame(self, t); sf.pack(fill="both", expand=True)
        c = sf.inner; c.columnconfigure(0, weight=1); r = 0
        tk.Label(c, text="CUSTOMIZE", bg=t.bg, fg=t.accent, font=t.f(8, True)).grid(row=r, column=0, sticky="w", pady=(20,16), padx=24); r+=1
        # Name
        tk.Label(c, text="App Name (YourName-DILA)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24); r+=1
        nf = tk.Frame(c, bg=t.bg); nf.grid(row=r, column=0, sticky="ew", padx=24, pady=(2,4))
        nf.columnconfigure(0, weight=1)
        self.name = tk.StringVar(value=self.d.settings.get("name",""))
        tk.Entry(nf, textvariable=self.name, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                 font=t.f(1), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).grid(row=0, column=0, sticky="ew", ipady=6)
        self.np = tk.Label(nf, text=f"Preview: {self.name.get()+'-DILA' if self.name.get().strip() else 'DILA'}",
                           bg=t.bg, fg=t.dim, font=t.f(-1))
        self.np.grid(row=1, column=0, sticky="w", pady=(4,0))
        self.name.trace_add("write", lambda *a: self.np.configure(text=f"Preview: {self.name.get()+'-DILA' if self.name.get().strip() else 'DILA'}"))
        r+=1
        # Theme
        tk.Label(c, text="Theme", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(16,2)); r+=1
        self.theme_var = tk.StringVar(value=self.d.settings.get("theme","Dark Neon"))
        for name, td in THEMES.items():
            tf = tk.Frame(c, bg=t.bg); tf.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
            tk.Radiobutton(tf, text=name, variable=self.theme_var, value=name, bg=t.bg, fg=t.fg,
                           selectcolor=t.card, activebackground=t.bg, activeforeground=t.fg,
                           font=t.f(0, True)).pack(side="left")
            tk.Label(tf, text=f"  {td['font']}", bg=t.bg, fg=t.dim, font=t.f(-2)).pack(side="left", padx=8)
            # Color swatches
            sf2 = tk.Frame(tf, bg=t.bg); sf2.pack(side="left", padx=12)
            for key in ["bg","card","accent","fg"]:
                sw = tk.Frame(sf2, bg=td[key], width=14, height=14); sw.pack(side="left", padx=1)
            r+=1
        # Font size
        tk.Label(c, text="Font Size Override (0 = theme default)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(16,2)); r+=1
        fsf = tk.Frame(c, bg=t.bg); fsf.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
        self.fs = tk.IntVar(value=self.d.settings.get("font_size", 0))
        tk.Scale(fsf, from_=0, to=20, orient="horizontal", variable=self.fs, bg=t.bg, fg=t.fg,
                 highlightthickness=0, font=t.f(-1)).pack(fill="x")
        r+=1
        # Font family override
        tk.Label(c, text="Font Family Override (blank = theme default)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(16,2)); r+=1
        fff = tk.Frame(c, bg=t.bg); fff.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
        font_options = ["", "Segoe UI", "Arial", "Calibri", "Cambria", "Times New Roman", "Georgia",
                        "Consolas", "Courier New", "Verdana", "Tahoma", "Trebuchet MS",
                        "Comic Sans MS", "Impact", "Bookman Old Style", "Garamond",
                        "Helvetica", "Lucida Console", "Microsoft Sans Serif"]
        self.font_var = tk.StringVar(value=self.d.settings.get("font_family", ""))
        ff_menu = tk.OptionMenu(fff, self.font_var, *font_options)
        ff_menu.configure(bg=t.card, fg=t.fg, relief="flat", font=t.f(0), highlightthickness=0, width=25)
        ff_menu.pack(side="left", ipady=4)
        r+=1
        # Accent
        tk.Label(c, text="Accent Color Override", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(16,2)); r+=1
        cf = tk.Frame(c, bg=t.bg); cf.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
        self.color = tk.StringVar(value=self.d.settings.get("color",""))
        tk.Entry(cf, textvariable=self.color, bg=t.card, fg=t.fg, relief="flat", font=t.f(0), width=12).pack(side="left", ipady=4)
        tk.Button(cf, text="Pick...", bg=t.card, fg=t.fg, relief="flat", cursor="hand2",
                  command=lambda: self.color.set(colorchooser.askcolor(self.color.get() or self.t.accent)[1] or "")).pack(side="left", padx=8)
        tk.Button(cf, text="Reset", bg=t.card, fg=t.muted, relief="flat", cursor="hand2",
                  command=lambda: self.color.set("")).pack(side="left", padx=8)
        r+=1
        # Logo
        tk.Label(c, text="Custom Logo (DILA watermark in corner)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=24, pady=(16,2)); r+=1
        lf = tk.Frame(c, bg=t.bg); lf.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
        self.logo = tk.StringVar(value=self.d.settings.get("logo",""))
        tk.Entry(lf, textvariable=self.logo, bg=t.card, fg=t.fg, relief="flat", font=t.f(0)).pack(side="left", fill="x", expand=True, ipady=4)
        tk.Button(lf, text="Browse...", bg=t.card, fg=t.fg, relief="flat", cursor="hand2",
                  command=lambda: self.logo.set(filedialog.askopenfilename(filetypes=[("Images","*.png *.jpg *.jpeg *.bmp *.gif *.ico")]) or "")).pack(side="left", padx=8)
        tk.Button(lf, text="Reset", bg=t.card, fg=t.muted, relief="flat", cursor="hand2",
                  command=lambda: self.logo.set("")).pack(side="left", padx=8)
        r+=1
        # Messages
        tk.Label(c, text="Wholesome Phrases (one per line)", bg=t.bg, fg=t.muted, font=t.f(0, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(16,2)); r+=1
        self.w_text = tk.Text(c, height=6, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                              font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                              highlightcolor=t.accent, wrap="word")
        self.w_text.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
        self.w_text.insert("1.0", "\n".join(self.d.settings.get("phrases_w", WHOLESALE)))
        r+=1
        tk.Label(c, text="Savage Phrases (one per line)", bg=t.bg, fg=t.muted, font=t.f(0, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(12,2)); r+=1
        self.s_text = tk.Text(c, height=6, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                              font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                              highlightcolor=t.accent, wrap="word")
        self.s_text.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
        self.s_text.insert("1.0", "\n".join(self.d.settings.get("phrases_s", SAVAGE)))
        r+=1
        tk.Button(c, text="SAVE ALL", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(2, True),
                  cursor="hand2", padx=32, pady=12, command=self._save).grid(row=r, column=0, pady=(24,24), padx=24)
        r+=1

    def _save(self):
        self.d.settings["name"] = self.name.get().strip()
        self.d.settings["color"] = self.color.get().strip()
        self.d.settings["logo"] = self.logo.get().strip()
        self.d.settings["theme"] = self.theme_var.get()
        self.d.settings["font_size"] = self.fs.get()
        self.d.settings["font_family"] = self.font_var.get().strip()
        self.d.settings["phrases_w"] = [p.strip() for p in self.w_text.get("1.0","end").splitlines() if p.strip()]
        self.d.settings["phrases_s"] = [p.strip() for p in self.s_text.get("1.0","end").splitlines() if p.strip()]
        self.d.save()
        if self.on_change: self.on_change()
        messagebox.showinfo("Saved", "Customization saved!")

    def refresh(self): self._build()


# ============================================================
# SETTINGS DIALOG
# ============================================================

class SettingsDialog(tk.Toplevel):
    def __init__(self, parent, d, t, n):
        super().__init__(parent)
        self.d = d; self.t = t; self.n = n
        self.title("Settings"); self.configure(bg=t.bg)
        self.resizable(False, False); self.transient(parent); self.grab_set()  # v5.9.9: fixed size
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        _h = min(680, sh - 80)
        self.geometry(f"520x{_h}+{(sw-520)//2}+{max(0,(sh-_h)//2-20)}")
        sf = ScrollFrame(self, t); sf.pack(fill="both", expand=True)
        c = sf.inner; c.columnconfigure(0, weight=1); r = 0
        tk.Label(c, text="SETTINGS", bg=t.bg, fg=t.accent, font=t.f(4, True)).grid(row=r, column=0, sticky="w", pady=(18,12), padx=20); r+=1
        # Test
        tk.Label(c, text="Test Notifications", bg=t.bg, fg=t.muted, font=t.f(0, True)).grid(row=r, column=0, sticky="w", padx=20, pady=(12,4)); r+=1
        tf = tk.Frame(c, bg=t.bg); tf.grid(row=r, column=0, sticky="ew", padx=20, pady=4)
        tk.Button(tf, text="Test All", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=6, command=self.n.test).pack(side="left", padx=(0,8))
        tk.Button(tf, text="Test Sound", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=6, command=lambda: threading.Thread(target=self.n._sound, daemon=True).start()).pack(side="left", padx=(0,8))
        tk.Button(tf, text="Test Voice", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=6, command=lambda: threading.Thread(target=self.n._speak, args=("Test from DILA.",), daemon=True).start()).pack(side="left", padx=(0,8))
        tk.Button(tf, text="Test Toast", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=6, command=lambda: threading.Thread(target=self.n._toast, args=("DILA Test", "Toast notifications are working!", {"color":"#7C5CFF"}), daemon=True).start()).pack(side="left")
        r+=1
        # Autostart
        self.auto = tk.BooleanVar(value=is_autostart())
        tk.Checkbutton(c, text="Start with Windows", variable=self.auto, bg=t.bg, fg=t.fg, selectcolor=t.card,
                       activebackground=t.bg, activeforeground=t.fg, font=t.f(1)).grid(row=r, column=0, sticky="w", padx=20, pady=4); r+=1
        self.tray = tk.BooleanVar(value=self.d.settings.get("min_tray", True))
        tk.Checkbutton(c, text="Minimize to tray on close", variable=self.tray, bg=t.bg, fg=t.fg, selectcolor=t.card,
                       activebackground=t.bg, activeforeground=t.fg, font=t.f(1)).grid(row=r, column=0, sticky="w", padx=20, pady=4); r+=1
        tk.Label(c, text="End-of-day recap time (HH:MM)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=20, pady=(12,2)); r+=1
        ef = tk.Frame(c, bg=t.bg); ef.grid(row=r, column=0, sticky="ew", padx=20, pady=2)
        self.eod = tk.StringVar(value=self.d.settings.get("eod_time","22:00"))
        tk.Entry(ef, textvariable=self.eod, width=8, bg=t.card, fg=t.fg, relief="flat", font=t.f(0)).pack(side="left", ipady=4)
        tk.Label(ef, text="  (daily recap popup)", bg=t.bg, fg=t.dim, font=t.f(-1)).pack(side="left")
        r+=1
        tk.Label(c, text="Custom sound (.wav)", bg=t.bg, fg=t.muted, font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=20, pady=(12,2)); r+=1
        sf2 = tk.Frame(c, bg=t.bg); sf2.grid(row=r, column=0, sticky="ew", padx=20, pady=2)
        self.sound = tk.StringVar(value=self.d.settings.get("sound",""))
        tk.Entry(sf2, textvariable=self.sound, bg=t.card, fg=t.fg, relief="flat", font=t.f(0)).pack(side="left", fill="x", expand=True, ipady=4)
        tk.Button(sf2, text="...", bg=t.card, fg=t.fg, relief="flat", cursor="hand2",
                  command=lambda: self.sound.set(filedialog.askopenfilename(filetypes=[("WAV","*.wav")]) or "")).pack(side="left", padx=4)
        r+=1
        # Rage questions
        tk.Label(c, text="Rage Mode Questions (one per line - must answer all to dismiss)", bg=t.bg, fg=t.muted, font=t.f(0, True)).grid(row=r, column=0, sticky="w", padx=20, pady=(12,2)); r+=1
        self.rage_q = tk.Text(c, height=4, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                              font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                              highlightcolor=t.accent, wrap="word")
        self.rage_q.grid(row=r, column=0, sticky="ew", padx=20, pady=2)
        self.rage_q.insert("1.0", "\n".join(self.d.settings.get("rage_questions", ["What did you just do?", "How do you feel about it?"])))
        r+=1
        # Status
        for l, a in [("TTS", HAS_TTS), ("Toast", HAS_TOAST), ("Tray", HAS_TRAY), ("PIL", HAS_PIL)]:
            color = t.muted if a else t.danger
            tk.Label(c, text=f"{l}: {'Available' if a else 'Not installed'}", bg=t.bg, fg=color,
                     font=t.f(-1)).grid(row=r, column=0, sticky="w", padx=20, pady=2); r+=1
        bf = tk.Frame(c, bg=t.bg); bf.grid(row=r, column=0, sticky="ew", pady=(20,20), padx=20)
        tk.Button(bf, text="Cancel", bg=t.card, fg=t.muted, relief="flat", font=t.f(0), cursor="hand2",
                  padx=20, pady=6, command=self.destroy).pack(side="right", padx=(8,0))
        tk.Button(bf, text="Save", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(0, True),
                  cursor="hand2", padx=24, pady=6, command=self._save).pack(side="right")
        r+=1

    def _save(self):
        eod = self.eod.get().strip()
        if not valid_time(eod):
            messagebox.showerror("Bad time", f"'{eod}' is not HH:MM.", parent=self); return
        set_autostart(self.auto.get())
        self.d.settings["min_tray"] = self.tray.get()
        self.d.settings["sound"] = self.sound.get()
        self.d.settings["eod_time"] = eod
        self.d.settings["eod_done"] = ""
        self.d.settings["rage_questions"] = [q.strip() for q in self.rage_q.get("1.0","end").splitlines() if q.strip()]
        self.d.save()
        self.destroy()


# ============================================================
# ABOUT DIALOG
# ============================================================

VERSION_HISTORY = {
    "5.12": ["Improved: Markdown rendering polished across the board — closer to Obsidian/GitHub/Typora.",
             "New: All six heading levels (H1-H6) render with a clear visual hierarchy (size, weight, spacing). H1 and H2 get a subtle separator underneath.",
             "New: Strikethrough (~~text~~), bold-italic (***text***), and inline code all render live as you type.",
             "New: Full list support — unordered (-, *, +), ordered (1.), nested (indent), and GFM task lists (- [x] done / - [ ] todo) with checkbox-style markers and strikethrough on completed items.",
             "New: Blockquotes render with a colored left border, soft background, italic text, and proper padding. Multi-line quotes are supported.",
             "New: Horizontal rules support all three Markdown forms (---, ***, ___) and render as clean full-width separators.",
             "New: Clickable links — both [text](url) and bare https://example.com URLs. Links are blue, underlined, hover-highlighted, and open in the default browser on click.",
             "New: Safe HTML subset — <b>, <i>, <u>, <em>, <strong>, <br>, <hr> are interpreted inline. Unsafe tags are passed through as text (no script execution).",
             "New: Block math ($$...$$) is detected as a block-level element and centered; inline math ($...$) keeps working. LaTeX is rendered to Unicode (Greek, operators, fractions, super/subscripts).",
             "Improved: Tables parse alignment markers (:---, ---:, :---:) and align columns left/right/center accordingly.",
             "New: Mermaid/diagram editor is now a true live editor — the source code editor is hidden by default. Click the diagram (or the 'Edit' chip) to reveal an inline editor; clicks outside collapse it again. The diagram re-renders on every keystroke. No more permanent duplicate raw-text widget below the canvas.",
             "Improved: Spacing throughout — paragraphs, code blocks, headings, lists, quotes, and tables all have more breathing room.",
             "Improved: Reduced typing flicker — live-formatting pass is debounced and only re-applies tags (never touches text content), so cursor position is preserved.",
             "Fixed: bare URLs and [text](url) links are now clickable from the editor and from presentation mode."],
    "5.10": ["New: Word-like WYSIWYG editor — one continuous Text widget per section with inline embedded rich content. Text flows naturally around images, code blocks, tables, diagrams, and media — just like Microsoft Word, but with code execution and more.",
             "New: Images, code blocks, tables, diagrams, audio, and video are embedded INLINE in the text flow — you can type before and after them, they're part of the document, not separate widgets floating outside.",
             "New: Code blocks are editable inline — click into the dark code area and type. Run/Copy buttons are right there.",
             "New: Diagrams have an Edit button — click it to open a dialog, edit the diagram source code, and re-render instantly.",
             "New: All rich elements stay inside their split section — no more stickers floating outside the split.",
             "New: Same split layout (colored header bars with name/tags/delete per section) + '+ Add Section' button at the bottom",
             "New: All editor features work — Insert image/code/table/math/diagram, Draw, Screenshot, Graphing Calculator, Run Code, formatting toolbar (bold/italic/font/size/color/align)",
             "New: Insert at cursor — images, code, tables, etc. are inserted at the cursor position in the current section, not appended at the bottom",
             "Fixed: zero data loss — each embedded element stores its raw markdown. Save reconstructs the full markdown by walking the widget with dump(). Tested round-trip.",
             "Fixed: Run Code scans ALL code blocks across ALL sections",
             "Fixed: toggling notes / Ctrl+S flushes pending saves immediately",
             "Removed: Preview button and Ctrl+P shortcut (no longer needed — everything is always rendered)",
             "Fixed: Map now auto-refreshes when splits or notes are deleted — deleted splits and their connections disappear immediately",
             "Fixed: soft-deleted notes no longer leave dangling split connections in the Map",
             "Fixed: hard-deleting a note cleans up all stale Map entries for that note and its splits",
             "Fixed: deleting a split cleans up its Map entries (positions, colors, edges)",
             "New: Map zoom — Control+MouseWheel to zoom in/out around the cursor, or use the + / − / Reset buttons in the top bar. Zoom level is preserved across refreshes.",
             "New: hiding the Notes category in the Map legend now also hides their splits — both split dots and their tag/hierarchy connections disappear",
             "New: Resize stickers — right-click any image, code block, or diagram and choose 'Resize...' to set its size (image width in px, code height in lines, diagram width in px). Size is saved in the markdown and persists across reloads.",
             "New: Move stickers — right-click any sticker and choose 'Move up' or 'Move down' to reposition it within the section.",
             "New: Delete stickers via right-click menu.",
             "New: Edit tables — tables now have an 'Edit' button that opens a dialog to edit the raw markdown table, then re-renders.",
             "New: Resize split sections — right-click a section's colored header bar and choose 'Set section height...' or 'Expand to fit content'.",
             "New: Sections auto-fit their height to content — no more clipped images or content you can't scroll to see. The section grows as you type or insert stickers.",
             "New: Inline stickers — images, audio, and video can now appear side by side on the same line, next to text or other stickers. Insert an image at cursor and it stays inline; insert another right after for side-by-side layout.",
             "New: Live markdown rendering — headers, bold, italic, code, links, tags, quotes, math all render with formatting tags on top of raw markdown as you type. Markers are de-emphasized (small/muted) so the rendered look is clean. Zero data loss — raw markdown is always preserved in the widget text.",
             "New: Editable tables — tables now use editable Entry widgets. Click any cell to edit it directly in the note. Add/remove rows and columns with + Row / + Col / - Row / - Col buttons. Right-click a cell to set its background color.",
             "New: Editable diagrams — diagram code is now editable inline (code editor below the canvas). Type to edit the diagram source — it re-renders live as you type. No dialog needed.",
             "Fixed: sections now auto-fit precisely using bbox measurement — the section ends exactly 2 lines after the last element, no more clipping or excessive empty space.",
             "Removed: 'Move up/down' from sticker context menu (per user request)."],
    "5.9.9": ["Rebuilt: Graphing Calculator is now Desmos-like — live preview as you type, per-equation color picker (click the swatch), visibility toggle (eye icon), add/remove equations, x/y range controls, zoom in/out/reset buttons",
               "New: 'Import' button in the Graphing Calculator pastes the current graph into your note as a static picture (unchangeable, like a screenshot of the finished graph)",
               "New: splits now visually divide the note like a river splitting land — the split marker renders as a thick colored bar with the split name centered (visible in both editor and preview)",
               "Improved: Present mode transitions — smoother Fade, real Slide (text visible during transition), Morph, plus new Zoom and Wipe transitions",
               "New: ⤢ button next to Present — opens a transitions dropdown (Fade / Slide / Morph / Zoom / Wipe / None), your choice is used as the default when you start presenting",
               "Fixed: math graphs from the Graphing Calculator now actually stick into notes — the Insert to Note button was blocked by an over-strict empty-plot check"],
    "5.9.8": ["Fixed: TODAY score in the top-right now only counts tasks actually due today — weekly/custom tasks no longer dilute the percentage",
               "New: math graphs insert as inline stickers (visible in the editor, not just as markdown links)",
               "New: 'Sticker' button — insert any image (PNG/JPG/GIF) as an inline sticker in your note",
               "Removed: weekday header row (M/T/W/T/F/S/S) above each month in year-view calendar",
               "Fixed: DILA logo now shows in the taskbar when you click the tray icon to restore the window"],
    "5.9.7": ["New: splits can now have tags (prompted at creation) — splits link to notes/tasks/time-periods in the Map via shared #tags",
               "New: click anywhere inside a month cell in year-view to select the whole month (no need to hit a specific day)",
               "New: split nodes in the Map now persist their dragged positions across refreshes",
               "New: app always starts fullscreen (maximized) and re-maximizes if you try to restore it",
               "Fixed: TODAY score in the top-right now updates instantly when you mark a task done / delete a task / toggle a heatmap day",
               "Fixed: notification popups are now clickable (I DID IT / Later) even when the Settings dialog is open — no need to close Settings first",
               "Fixed: year-view 2-click logic — first click selects whole month, second click on the same month enters month view",
               "Fixed: split tag connections now redraw correctly when dragging nodes in the Map"],
    "5.9.6": ["New: year view — hover a month for semi-transparent highlight, click to select with solid color","Fixed: tag name labels now follow their lines when dragging nodes","New: split dots are independently draggable in the map","New: hover bounce — animated halo ring around hovered nodes"],
    "5.9.5": ["Fixed: app no longer forced fullscreen — remembers windowed/maximized state","Fixed: map node dragging — old edge lines no longer remain, positions are permanent (saved on drag end)","Fixed: 'bad button number 6' crash on Windows (Button-4/5/6/7 wrapped in try/except)","Brought back: laziest day in stats (always shows)","Updated version history"],
    "5.9.4": ["Fixed: 'bad button number 6' crash on Windows — wrapped touchpad Button-4/5/6/7 bindings in try/except"],
    "5.9.3": ["Fixed: map node dragging — edges now follow in real-time, text labels move too","App starts fullscreen (maximized)","Middle mouse + touchpad scroll everywhere","Faster refresh: numbers update every 5 seconds (was 60)"],
    "5.9.2": ["Fixed: map node dragging (delta move works for all shapes)","Removed month labels above heatmaps","Heatmaps show full Jan 1 - Dec 31 year","Scrollable calendar side panel","Day comments can be cleared","Year view: click month title to enter month view","Year view: 2-click whole-month selection","Middle mouse button scrolling"],
    "5.9.1": ["Fixed: per-streak heatmap now shows (was never packed)","Infinite task counter display","Fixed: calendar year view month positioning","Stats heatmap shows full current year","Map nodes are draggable (click+drag)","Notebooks now connect via tags","Removed PyQt6 button from map"],
    "5.9.0": ["New: 'Infinite per day' task type (no cap on completions)","Fixed: notifications now fire reliably at the configured time (was missing exact-minute match)","Fixed: heatmap days stay blank even when done (intensity ratio + creation-date fix)","Fixed: calendar shows 0/3 progress on days before task creation","Fixed: calendar year navigation (safe Feb 29 handling)","Fixed: map nodes not linking (now scans note content + title for tags)","New: PyQt6 interactive fullscreen knowledge map (zoom/pan/drag)","Everything is now scrollable (map, notes, panels, popups, stats, history)","Full version history timeline (v1.0.0-v5.9.0) in About dialog"],
    "5.8.0": ["New neon app logo (gradient rounded square + flame + checkmark)","Taskbar now shows the DILA logo instead of the Python/Tk feather icon","AppUserModelID set at process start (before window creation)","Window hidden until icon is set (withdraw/deiconify)","On Windows: iconbitmap-only icon setting (iconphoto no longer overrides it)","Icon file always regenerated on launch","Icon errors logged to icon_error.log"],
    "5.7.0": ["Fixed: graph insertion now checks if a note is open BEFORE opening graph dialog","Fixed: code execution completely rewritten - shows every step, every path, every error","New: JS now tries Node.js first (runs in terminal), falls back to browser with console.log capture","New: HTML/CSS opens in browser with detailed URL logging","New: Python shows sys.executable path, search steps, stdout/stderr separately","Fixed: transitions button was already there - make sure you're running v5.7.0"],
    "5.6.2": ["Fixed: installer no longer crashes on launch (removed ASCII art with pipe characters that broke batch parsing)","Simplified installer to minimal reliable form"],
    "5.6.1": ["Fixed: installer now works reliably (v5.6.0 GUI installer was broken - terminal flashed and disappeared)","Reverted to reliable terminal installer with colored output and clear formatting"],
    "5.6.0": ["New: Calendar hover effects - day cells change color on hover","New: Click-to-select range - first click selects start, second click selects end, range is colored","New: Range info shown inline in side panel (no more popup)","New: Auto-fill duration from selected range","New: Present mode transitions selector - Fade/Slide/Morph/None","Fixed: Map layout improved - unassigned notes in circle when no notebooks, tasks/time periods spread evenly","New: Modern GUI installer with progress bar, status messages, launch button (no more blank terminal)"],
    "5.5.0": ["New: Calendar duration selector - view by Day/Week/Month/Year/Custom N days","New: Time-period tagging - tag any date range with #tags, shows in Map as hexagon nodes","New: Task tags - add #tags to tasks, they appear in Map as diamond nodes","New: Map shows 4 node types: Notebooks (circles), Notes (circles), Tasks (diamonds), Time Periods (hexagons)","New: Tag connections now link across ALL types (notes, tasks, time periods)","Fixed: Present mode now renders diagrams (```diagram blocks), tables (Treeview), videos (Play button), audios (Play button)","New: Fade transitions between presentation slides","Fixed: Run Code popup dimensions - now screen-aware, resizable, bottom always visible","Fixed: Draw popup dimensions - screen-aware"],
    "5.4.0": ["Renamed 'Streaks' to 'Tasks' throughout the app","New: Calendar tab - monthly view, click days to add comments/tasks, highlight days with comments","New: Day comments with #tags link to notes in Map view","Fixed: Windows taskbar icon now shows DILA logo (was showing Python icon)","New: Tutorial section in About dialog","New: SetCurrentProcessExplicitAppUserModelID for proper Windows taskbar grouping","Improved: Present mode renders tables, diagrams, images, code blocks"],
    "5.3.1": ["Fixed: splits are now dividers WITHIN the note (don't cut content out) - note stays whole","Fixed: tag connections now show in Map with #tag labels at midpoints","Fixed: splits now appear as small dots in the Map connected to their note","Fixed: Present mode now renders images/tables/code (was showing plain text)","Fixed: code execution now shows detailed debug info (python path, script path, errors)","New: per-streak rage questions (set when creating the task, not just in global settings)","New: notebook selector dropdown in note title bar - assign notes to notebooks","Fixed: graph sticker insertion - now normalizes path + checks editor exists","New: keyboard shortcuts: Ctrl+N (note), Ctrl+S (save), Ctrl+B (bold), Ctrl+I (italic), Ctrl+P (preview), F1 (about), F5 (map)","New: popups and rage dialog are now resizable","New: split count shown in sidebar with names"],
    "5.3.0": ["Fixed: notifications now fire reliably (was missing exact-minute match)","New: 4 notification intensity levels - Cute (toast only), Normal (toast+popup+snooze), Aggressive (TTS speaks + savage phrases), Rage (max volume + questions + PC shutdown)","New: snooze duration field - click Later to re-notify after N minutes","New: Rage mode - must answer custom questions to dismiss, 5-min countdown then PC shutdown","New: Rage questions configurable in Settings","New: Split feature - split note at cursor into named parts with custom background color","New: Presentation mode now shows splits one at a time with their background colors","New: Math graphs can be inserted into notes as image stickers (Insert to Note button)","New: Notebooks - organize notes into notebooks with tree sidebar","New: Tags field on notes and notebooks (#tag linking)","New: Knowledge Map view - Obsidian-style graph showing notebooks/notes/splits as connected dots","Fixed: code execution now writes to temp .py file (more reliable for multi-line code)","Fixed: popups now run on main thread (was failing silently in background thread)","New: Notebooks show as tree with notes as children, splits shown as sub-items"],
    "5.2.2": ["Fixed: crash on startup caused by tuple pady passed to tk.Label constructor in StatsView (TclError: bad screen distance)","Fixed: same bug in AboutDialog (pre-existing from v5.0.0, would crash when opening About)"],
    "5.2.1": ["Fixed: installer shortcut creation now works on Windows PowerShell 5.1 (removed ternary operator)","Fixed: installer now detects silent crashes and shows error console","Fixed: Notes editor formatting toolbar no longer overlaps the actions toolbar","Fixed: welcome toast no longer crashes due to duplicate title argument","New: error logging - crashes now write to error.log with full traceback","New: installer syntax-checks the extracted app before proceeding"],
    "5.2.0": ["Fixed: multi-streak type now requires N clicks for target N (was locking at 1 click)","Fixed: heatmap colors no longer shrink when streaks are deleted (uses historical max)","New: GitHub-style heatmap with month/day labels, 5 intensity levels, hover tooltips, legend","New: All-time records (best day ever + longest streak ever) persist when streaks are deleted","Fixed: video/audio preview now matches the insertion syntax (was showing as plain links)","Fixed: code execution - now uses python.exe instead of pythonw.exe (was failing silently)","Fixed: HTML/CSS/JS preview now opens correctly (file:// URL with forward slashes)","New: CSS code blocks now supported (wrap in <style> for preview)","New: Math symbols rendered as Unicode in preview (fractions, integrals, Greek, etc.)","New: Math Symbols Kit dialog - 10 categories + LaTeX quick-insert","New: Graphing Calculator (Desmos-like) - plot y=f(x) with matplotlib, multiple equations","New: Diagram blocks (```diagram) render as flowcharts on Canvas - syntax: A --> B","New: MS Word-style formatting toolbar - bold/italic/underline/strike/font/size/color/alignment","New: More fonts (18 families) and 14 font sizes in notes editor","Fixed: Drawing canvas now waits for full render before screenshot grab","New: Screenshot supports both full-screen and drag-to-select region modes","Fixed: dead 'set Untitled' line on new note, dead tuple code in heatmap"],
    "5.1.0": ["Windows toast notifications (Action Center) - new 'Toast' mode per streak","Welcome toast on app startup","Test Toast button in Settings","End-of-day recap now also fires a toast"],
    "5.0.0": ["Complete rewrite from scratch - clean architecture","WYSIWYG notes with image/table/code rendering","Notes preview mode with rich formatting","Code blocks with Run buttons (Python/HTML/JS)","Drawing canvas","Presentation mode with fade transitions","Download notes as MD/HTML/TXT","Streaks: once/day + multi/day types","Weighted points system","Stats: line graph + 52-week heatmap","8 themes with live preview","System tray + autostart"],
    "4.0.0": ["Full rewrite using pywebview + HTML/CSS/JS","Real WYSIWYG editor (KaTeX, highlight.js)","Split architecture: Python + HTML UI","Broken / unstable version - Discontinued"],
    "3.1.0": ["Fixed note rendering (images, tables, code blocks)","Improved toolbar usability","Download note (full or selected section)","Better math preview rendering","Stabilized tkinter architecture"],
    "3.0.0": ["Python code runner inside notes","HTML/CSS/JS runner (browser fallback)","Drawing canvas (save + embed images)","LaTeX math rendering (matplotlib)","Markdown tables rendering","Image embedding support","Audio/video embedding system","Presentation mode (full slideshow + transitions)","Screenshot tool","Full export system (notes, stats, presentations)","Insert toolbar overhaul"],
    "2.2.0": ["Two streak types: once/day (boolean), multi/day (count-based)","Notes Graph View (Obsidian-style nodes + links)","About page with GitHub link","Version history dialog added","Streak descriptions/notes field","Improved taskbar icon"],
    "2.1.0": ["App renamed to DILA (Do It Lazy Ass)","Tab system: Streaks | Notes | Stats | Customize","Notes system: wiki-links [[note]], tags #tag, backlinks + search","GitHub-style stats heatmap + graphs","Full customization system (themes, fonts, messages)","Custom app name + logo system"],
    "2.0.0": ["Full UI rewrite with scrollable layout","Weighted habits (1-10 per streak)","End-of-day score recap system","I DID IT / Later decision popup","Better scoring system (not just completion %)","Cleaner dark + neon UI"],
    "1.0.0": ["Basic tkinter app","Streaks (daily / weekly / N-day schedules)","Notifications: toast, sound, TTS, popup","GitHub-style 91-day heatmap","Forgiveness days","System tray + Windows autostart","JSON storage in AppData"],
}

class AboutDialog(tk.Toplevel):
    def __init__(self, parent, d, t):
        super().__init__(parent)
        self.d = d; self.t = t
        self.title("About DILA"); self.configure(bg=t.bg)
        self.resizable(False, False); self.transient(parent); self.grab_set()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"520x600+{(sw-520)//2}+{max(0,(sh-600)//2-20)}")
        sf = ScrollFrame(self, t); sf.pack(fill="both", expand=True)
        c = sf.inner; c.columnconfigure(0, weight=1); r = 0
        # Logo
        try:
            logo = get_logo(self.d, 64, t)
            self.logo_photo = ImageTk.PhotoImage(logo)
            tk.Label(c, image=self.logo_photo, bg=t.bg).grid(row=r, column=0, pady=(24,8))
        except: pass
        r+=1
        tk.Label(c, text="DILA", bg=t.bg, fg=t.accent, font=t.f(8, True)).grid(row=r, column=0); r+=1
        tk.Label(c, text="Do It Lazy Ass", bg=t.bg, fg=t.muted, font=t.f(2)).grid(row=r, column=0, pady=(0,4)); r+=1
        tk.Label(c, text=f"Version {APP_VERSION}", bg=t.bg, fg=t.dim, font=t.f(0)).grid(row=r, column=0, pady=(0,16)); r+=1
        tk.Label(c, text="DILA is a streak tracker + notes app for Windows.\n\nTrack your habits with weighted points, get motivational (or savage) notifications, take Obsidian-style notes with images, tables, code, math, and presentations.\n\nBuilt with Python + tkinter.",
                 bg=t.bg, fg=t.fg, font=t.f(0), wraplength=440, justify="left").grid(row=r, column=0, padx=24, pady=(0,16)); r+=1
        # GitHub
        gf = tk.Frame(c, bg=t.bg); gf.grid(row=r, column=0, pady=(0,16))
        tk.Label(gf, text="GitHub: ", bg=t.bg, fg=t.muted, font=t.f(0)).pack(side="left")
        link = tk.Label(gf, text="https://github.com/1wizo", bg=t.bg, fg=t.accent, font=t.f(0, True),
                        cursor="hand2", underline=True)
        link.pack(side="left")
        link.bind("<Button-1>", lambda e: self._gh())
        r+=1
        tk.Label(c, text="VERSION HISTORY", bg=t.bg, fg=t.accent, font=t.f(2, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(8,8)); r+=1
        for v in sorted(VERSION_HISTORY.keys(), reverse=True):
            vf = tk.Frame(c, bg=t.card); vf.grid(row=r, column=0, sticky="ew", padx=24, pady=4)
            vf.columnconfigure(0, weight=1)
            tk.Label(vf, text=f"v{v}", bg=t.card, fg=t.accent, font=t.f(1, True), padx=12, pady=8).grid(row=0, column=0, sticky="w")
            tk.Label(vf, text="\n".join(f"  • {f}" for f in VERSION_HISTORY[v]), bg=t.card, fg=t.fg,
                     font=t.f(-1), justify="left", anchor="w").grid(row=1, column=0, sticky="w", padx=12, pady=(0, 8))
            r+=1
        # Tutorial
        tk.Label(c, text="QUICK TUTORIAL", bg=t.bg, fg=t.accent, font=t.f(2, True)).grid(row=r, column=0, sticky="w", padx=24, pady=(8,8)); r+=1
        tutorial = [
            ("Tasks tab", "Create tasks with name, schedule, times, and notification intensity. Click 'MARK DONE' to complete. Multi-tasks need N clicks."),
            ("Notification Intensity", "Cute = toast only. Normal = toast+popup+snooze. Aggressive = TTS speaks. Rage = max volume + questions + PC shutdown."),
            ("Notes tab", "Create notes with rich text. Use +Insert for code/math/diagram/table/image. Use Split to divide notes into sections."),
            ("Splits", "Click 'Split' at a cursor line to insert a divider (===SPLIT:Name|color===). Note stays whole. Present mode shows each split as a slide."),
            ("Graphing", "Click 'Graph' to open the graphing calculator. Enter y=f(x), plot, then 'Insert to Note' to embed as image."),
            ("Calendar tab", "Monthly calendar. Click any day to add comments (#tags link to notes), see tasks due, or add new tasks for that day."),
            ("Map tab", "Knowledge graph showing notebooks (big dots), notes (medium dots), splits (small dots). Tag connections shown as dashed lines."),
            ("Notebooks", "Click '+ Notebook' to create. Use dropdown in note title bar to assign notes to notebooks."),
            ("Tags", "Type #tags in note title or day comments. Notes sharing tags get connected in the Map view."),
            ("Shortcuts", "Ctrl+N=new note, Ctrl+S=save, Ctrl+B=bold, Ctrl+I=italic, F1=about, F5=map, Ctrl+Shift+Left=Tasks, Ctrl+Shift+Right=Notes"),
            ("Code Blocks", "Use ```python, ```html, ```css, or ```js. Click Run to execute. Python shows output; HTML/CSS/JS open in browser."),
            ("Math", "Use $LaTeX$ for inline math (renders as Unicode). Click 'Math Kit' for symbol palette. Supports fractions, integrals, Greek, etc."),
        ]
        for title, desc in tutorial:
            tf2 = tk.Frame(c, bg=t.card); tf2.grid(row=r, column=0, sticky="ew", padx=24, pady=2)
            tf2.columnconfigure(0, weight=1)
            tk.Label(tf2, text=title, bg=t.card, fg=t.warn, font=t.f(-1, True), padx=12, pady=(6, 2)).grid(row=0, column=0, sticky="w")
            tk.Label(tf2, text=desc, bg=t.card, fg=t.fg, font=t.f(-1), padx=12, pady=(0, 6),
                     wraplength=440, justify="left", anchor="w").grid(row=1, column=0, sticky="w")
            r+=1
        tk.Button(c, text="Close", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(0, True),
                  cursor="hand2", padx=32, pady=8, command=self.destroy).grid(row=r, column=0, pady=(16,24))
        r+=1

    def _gh(self):
        import webbrowser
        webbrowser.open("https://github.com/1wizo")


# ============================================================
# CALENDAR VIEW
# ============================================================

class CalendarView(tk.Frame):
    """Calendar with duration selection (day/week/month/year/custom) and time-period tagging."""
    def __init__(self, parent, d, t, n, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.d = d; self.t = t; self.n = n
        self.cur_date = dt.date.today()
        self.sel_date = None
        self.range_start = None  # first click for range selection
        self.range_end = None    # second click for range selection
        self.duration_type = tk.StringVar(value="month")  # day/week/month/year/custom
        self._build()

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        # Header
        top = tk.Frame(self, bg=t.bg); top.pack(fill="x", padx=20, pady=(16, 8))
        tk.Label(top, text="CALENDAR", bg=t.bg, fg=t.accent, font=t.f(4, True)).pack(side="left")
        # Duration selector
        dur_frame = tk.Frame(top, bg=t.bg); dur_frame.pack(side="left", padx=(24, 0))
        tk.Label(dur_frame, text="View:", bg=t.bg, fg=t.muted, font=t.f(-1)).pack(side="left", padx=(0, 4))
        durations = [("Month", "month"), ("Week", "week"), ("Year", "year"), ("Day", "day"), ("Custom", "custom")]
        for label, val in durations:
            tk.Radiobutton(dur_frame, text=label, variable=self.duration_type, value=val,
                           bg=t.bg, fg=t.fg, selectcolor=t.card, activebackground=t.bg,
                           activeforeground=t.fg, font=t.f(-1), command=self._on_duration_change).pack(side="left", padx=2)
        # Navigation
        nav = tk.Frame(top, bg=t.bg); nav.pack(side="right")
        tk.Button(nav, text="<", bg=t.card, fg=t.fg, relief="flat", font=t.f(1, True), cursor="hand2",
                  padx=12, pady=4, command=self._prev).pack(side="left", padx=2)
        self.nav_label = tk.Label(nav, text="", bg=t.bg, fg=t.fg, font=t.f(2, True), width=20)
        self.nav_label.pack(side="left", padx=8)
        tk.Button(nav, text=">", bg=t.card, fg=t.fg, relief="flat", font=t.f(1, True), cursor="hand2",
                  padx=12, pady=4, command=self._next).pack(side="left", padx=2)
        tk.Button(nav, text="Today", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=4, command=self._go_today).pack(side="left", padx=(8, 0))
        # Content area
        content = tk.Frame(self, bg=t.bg); content.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        content.columnconfigure(0, weight=1); content.rowconfigure(0, weight=1)
        self.cal_container = tk.Frame(content, bg=t.bg); self.cal_container.grid(row=0, column=0, sticky="nsew")
        # Side panel for selected period (scrollable)
        info_wrap = tk.Frame(content, bg=t.panel, width=300); info_wrap.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        info_wrap.grid_propagate(False)
        info_sf = ScrollFrame(info_wrap, t); info_sf.pack(fill="both", expand=True)
        self.info_frame = info_sf.inner
        self.info_frame.configure(bg=t.panel)
        self._draw_view()
        self._refresh_nav_label()

    def _on_duration_change(self):
        self._draw_view(); self._refresh_nav_label()

    def _refresh_nav_label(self):
        dt_val = self.duration_type.get()
        if dt_val == "month":
            self.nav_label.configure(text=self.cur_date.strftime("%B %Y"))
        elif dt_val == "week":
            week_start = self.cur_date - dt.timedelta(days=self.cur_date.weekday())
            week_end = week_start + dt.timedelta(days=6)
            self.nav_label.configure(text=f"{week_start.strftime('%b %d')} - {week_end.strftime('%b %d')}")
        elif dt_val == "year":
            self.nav_label.configure(text=str(self.cur_date.year))
        elif dt_val == "day":
            self.nav_label.configure(text=self.cur_date.strftime("%a, %b %d"))
        elif dt_val == "custom":
            self.nav_label.configure(text=self.cur_date.strftime("%b %d") + " + N days")

    def _prev(self):
        dt_val = self.duration_type.get()
        if dt_val == "month":
            self.cur_date = (self.cur_date.replace(day=1) - dt.timedelta(days=1)).replace(day=1)
        elif dt_val == "week":
            self.cur_date -= dt.timedelta(weeks=1)
        elif dt_val == "year":
            self.cur_date = self._safe_year(self.cur_date, -1)
        elif dt_val == "day":
            self.cur_date -= dt.timedelta(days=1)
        else:
            self.cur_date -= dt.timedelta(days=1)
        self._draw_view(); self._refresh_nav_label()

    def _next(self):
        dt_val = self.duration_type.get()
        if dt_val == "month":
            self.cur_date = (self.cur_date.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
        elif dt_val == "week":
            self.cur_date += dt.timedelta(weeks=1)
        elif dt_val == "year":
            self.cur_date = self._safe_year(self.cur_date, 1)
        elif dt_val == "day":
            self.cur_date += dt.timedelta(days=1)
        else:
            self.cur_date += dt.timedelta(days=1)
        self._draw_view(); self._refresh_nav_label()

    def _go_today(self):
        self.cur_date = dt.date.today()
        self._draw_view(); self._refresh_nav_label()

    def _year_day_click(self, d, month):
        """In year view: first click selects whole month, second click on the same month enters month view."""
        # v5.9.7: fixed 2-click logic. The old condition `not self.range_end` was
        # always False after the first click (range_end gets set to last day of
        # month). Now we check if THIS month is already the selected month.
        already_selected = (
            getattr(self, "_selected_month", None) == month
            and self.range_start and self.range_end
            and self.range_start.month == month
            and self.range_start.year == self.cur_date.year
        )
        if already_selected:
            # Second click on the same month — enter month view
            self._enter_month(month)
            return
        # First click (or click on a different month) — select whole month
        self._select_whole_month(month)
        # Show this specific day in the side panel (with range info)
        self._select_day(d)

    def _select_whole_month(self, month):
        """v5.9.7: Select every day in the given month of the current year."""
        self._selected_month = month
        first = dt.date(self.cur_date.year, month, 1)
        if month == 12:
            last = first.replace(year=first.year + 1, month=1) - dt.timedelta(days=1)
        else:
            last = first.replace(month=month + 1) - dt.timedelta(days=1)
        self.range_start = first
        self.range_end = last
        self._draw_view()

    def _enter_month(self, month):
        """Switch to month view for the given month."""
        self.cur_date = self.cur_date.replace(month=month, day=1)
        self.duration_type.set("month")
        self._draw_view()
        self._refresh_nav_label()

    def _safe_year(self, date, delta):
        """Change year by delta, handling Feb 29 in non-leap years."""
        try:
            return date.replace(year=date.year + delta, day=1)
        except ValueError:
            return date.replace(year=date.year + delta, day=28)

    def _draw_view(self):
        """Draw the appropriate view based on duration type."""
        for w in self.cal_container.winfo_children(): w.destroy()
        dt_val = self.duration_type.get()
        if dt_val == "month":
            self._draw_month()
        elif dt_val == "week":
            self._draw_week()
        elif dt_val == "year":
            self._draw_year()
        elif dt_val == "day":
            self._draw_day()
        else:  # custom
            self._draw_custom()

    def _draw_month(self):
        t = self.t
        cal_frame = self.cal_container
        for i, day in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]):
            tk.Label(cal_frame, text=day, bg=t.bg, fg=t.muted, font=t.f(-1, True)).grid(
                row=0, column=i, sticky="ew", pady=(0, 4))
        for i in range(7): cal_frame.columnconfigure(i, weight=1, uniform="cal")
        first = self.cur_date.replace(day=1)
        start_weekday = first.weekday()
        if first.month == 12:
            next_month = first.replace(year=first.year + 1, month=1)
        else:
            next_month = first.replace(month=first.month + 1)
        days_in_month = (next_month - first).days
        today = dt.date.today()
        for day in range(1, days_in_month + 1):
            d = first.replace(day=day)
            row = (day + start_weekday - 1) // 7 + 1
            col = (day + start_weekday - 1) % 7
            self._draw_day_cell(cal_frame, d, row, col, today)

    def _draw_week(self):
        t = self.t
        cal_frame = self.cal_container
        for i, day in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]):
            tk.Label(cal_frame, text=day, bg=t.bg, fg=t.muted, font=t.f(-1, True)).grid(
                row=0, column=i, sticky="ew", pady=(0, 4))
        for i in range(7): cal_frame.columnconfigure(i, weight=1, uniform="cal")
        week_start = self.cur_date - dt.timedelta(days=self.cur_date.weekday())
        today = dt.date.today()
        for i in range(7):
            d = week_start + dt.timedelta(days=i)
            self._draw_day_cell(cal_frame, d, 1, i, today, big=True)

    def _draw_year(self):
        t = self.t
        cal_frame = self.cal_container
        sf = ScrollFrame(cal_frame, t); sf.pack(fill="both", expand=True)
        inner = sf.inner
        # 4 rows x 3 cols, each cell gets equal weight
        for i in range(3): inner.columnconfigure(i, weight=1, uniform="ym")
        for i in range(4): inner.rowconfigure(i, weight=1, uniform="yr")
        today = dt.date.today()
        for m in range(1, 13):
            mr = (m-1) // 3; mc = (m-1) % 3
            # Check if this month is selected (from _year_day_click)
            is_sel = (getattr(self, "_selected_month", None) == m and
                      self.cur_date.year == dt.date.today().year)
            mf_bg = t.hover if is_sel else t.card
            mf = tk.Frame(inner, bg=mf_bg); mf.grid(row=mr, column=mc, sticky="nsew", padx=6, pady=6)
            if is_sel:
                mf.config(highlightbackground=t.accent, highlightthickness=2)
            # Hover effect: semi-transparent-ish (use hover color)
            def on_m_enter(e, frame=mf, orig_bg=mf_bg):
                if not getattr(self, "_selected_month", None) or self._selected_month != int(frame._month):
                    frame.config(bg=t.hover)
            def on_m_leave(e, frame=mf, orig_bg=mf_bg):
                if not getattr(self, "_selected_month", None) or self._selected_month != int(frame._month):
                    frame.config(bg=orig_bg)
            mf._month = str(m)
            mf.bind("<Enter>", on_m_enter)
            mf.bind("<Leave>", on_m_leave)
            # v5.9.7: click anywhere in the month frame selects the whole month
            def _month_area_click(e, m=m):
                self._select_whole_month(m)
                # Show the first day in the side panel (with range info displayed)
                self._select_day(dt.date(self.cur_date.year, m, 1))
            mf.bind("<Button-1>", _month_area_click)
            # Month header with year — click to enter month view (existing behavior)
            mname = dt.date(self.cur_date.year, m, 1).strftime("%B %Y")
            mhdr = tk.Label(mf, text=mname, bg=t.card, fg=t.accent, font=t.f(-1, True), cursor="hand2")
            mhdr.pack(anchor="w", padx=10, pady=(8, 4))
            mhdr.bind("<Button-1>", lambda e, m=m: self._enter_month(m))
            # v5.9.8: weekday header row removed — user requested no M/T/W/T/F/S/S
            # above each month in year view. The mini calendar grid is enough.
            # Mini calendar grid
            mini = tk.Frame(mf, bg=t.card); mini.pack(fill="x", padx=6, pady=(0, 8))
            for i in range(7): mini.columnconfigure(i, weight=1, uniform="md")
            mini.bind("<Button-1>", _month_area_click)
            first = dt.date(self.cur_date.year, m, 1)
            start_wd = first.weekday()
            if m == 12:
                nm = first.replace(year=first.year + 1, month=1)
            else:
                nm = first.replace(month=m + 1)
            dim = (nm - first).days
            for day in range(1, dim + 1):
                d = first.replace(day=day)
                r = (day + start_wd - 1) // 7
                c = (day + start_wd - 1) % 7
                bg = t.accent if d == today else t.hover
                fg = "#0E0E14" if d == today else t.fg
                lbl = tk.Label(mini, text=str(day), bg=bg, fg=fg, font=t.f(-3), width=2, cursor="hand2")
                lbl.grid(row=r, column=c, padx=1, pady=1)
                # Single click on a day: first click selects whole month,
                # second click on the same month enters month view (v5.9.7 fix)
                lbl.bind("<Button-1>", lambda e, d=d, m=m: self._year_day_click(d, m))
                lbl.bind("<Double-Button-1>", lambda e, d=d: self._select_day(d))

    def _draw_day(self):
        t = self.t
        cal_frame = self.cal_container
        d = self.cur_date
        today = dt.date.today()
        # Big day view
        frame = tk.Frame(cal_frame, bg=t.card); frame.pack(fill="both", expand=True, padx=4, pady=4)
        tk.Label(frame, text=d.strftime("%A, %B %d, %Y"), bg=t.card, fg=t.accent,
                 font=t.f(6, True)).pack(anchor="w", padx=20, pady=(20, 8))
        # Tasks due
        iso = d.isoformat()
        due = [(s, iso in hist_dates(s)) for s in self.d.streaks if is_due(s, d) and streak_existed_on(s, d)]
        if due:
            tk.Label(frame, text="Tasks due today:", bg=t.card, fg=t.muted, font=t.f(0, True)).pack(anchor="w", padx=20, pady=(8, 4))
            for s, done in due:
                color = t.success if done else t.warn
                tk.Label(frame, text=f"  {'OK' if done else 'X'}  {s.get('name', '?')}", bg=t.card, fg=color,
                         font=t.f(1)).pack(anchor="w", padx=20)
        else:
            tk.Label(frame, text="No tasks due today.", bg=t.card, fg=t.dim, font=t.f(0)).pack(anchor="w", padx=20, pady=8)
        # Hourly slots (simple)
        tk.Label(frame, text="Hourly Schedule:", bg=t.card, fg=t.muted, font=t.f(0, True)).pack(anchor="w", padx=20, pady=(12, 4))
        for s in self.d.streaks:
            if not is_due(s, d): continue
            times = s.get("times", [])
            for tm in times:
                tf2 = tk.Frame(frame, bg=t.hover); tf2.pack(fill="x", padx=20, pady=2)
                tk.Label(tf2, text=f"  {tm}", bg=t.hover, fg=t.accent, font=t.f(0, True), width=8).pack(side="left")
                tk.Label(tf2, text=s.get("name", "?"), bg=t.hover, fg=t.fg, font=t.f(0)).pack(side="left", padx=8)
        frame.bind("<Button-1>", lambda e: self._select_day(d))

    def _draw_custom(self):
        t = self.t
        cal_frame = self.cal_container
        # Ask for number of days
        top_f = tk.Frame(cal_frame, bg=t.bg); top_f.pack(fill="x", pady=(0, 8))
        tk.Label(top_f, text="Days to show:", bg=t.bg, fg=t.muted, font=t.f(-1)).pack(side="left", padx=(0, 4))
        self.custom_days = tk.IntVar(value=30)
        tk.Spinbox(top_f, from_=1, to=365, textvariable=self.custom_days, width=5, bg=t.card, fg=t.fg,
                   relief="flat", font=t.f(0), command=self._draw_custom_grid).pack(side="left")
        tk.Label(top_f, text="starting from current date", bg=t.bg, fg=t.dim, font=t.f(-1)).pack(side="left", padx=8)
        self.custom_grid_frame = tk.Frame(cal_frame, bg=t.bg)
        self.custom_grid_frame.pack(fill="both", expand=True)
        self._draw_custom_grid()

    def _draw_custom_grid(self):
        t = self.t
        for w in self.custom_grid_frame.winfo_children(): w.destroy()
        n = self.custom_days.get()
        today = dt.date.today()
        # Grid: 7 columns
        for i in range(7): self.custom_grid_frame.columnconfigure(i, weight=1, uniform="c")
        for i in range(n):
            d = self.cur_date + dt.timedelta(days=i)
            row = i // 7; col = i % 7
            self._draw_day_cell(self.custom_grid_frame, d, row + 1, col, today)

    def _draw_day_cell(self, parent, d, row, col, today, big=False):
        t = self.t
        iso = d.isoformat()
        due_count = sum(1 for s in self.d.streaks if is_due(s, d) and streak_existed_on(s, d))
        done_count = sum(1 for s in self.d.streaks if is_due(s, d) and streak_existed_on(s, d) and iso in hist_dates(s))
        day_comments = self.d.settings.get("day_comments", {})
        has_comment = iso in day_comments
        # Check time tags for this day
        time_tags = self.d.settings.get("time_tags", [])
        day_tags = []
        for tt in time_tags:
            start = pd(tt.get("start", ""))
            dur = int(tt.get("duration", 0))
            if start <= d <= start + dt.timedelta(days=dur):
                day_tags.extend(re.findall(r'#(\w+)', tt.get("tags", "")))
        # Determine base background
        bg = t.card
        in_range = False
        if self.range_start and self.range_end:
            if self.range_start <= d <= self.range_end:
                in_range = True
                bg = t.accent
        elif self.range_start and self.range_start <= d <= self.range_start + dt.timedelta(days=6):
            # Preview range from start
            in_range = True
            bg = blend(t.card, t.accent, 0.3)
        if d == today and not in_range:
            bg = t.accent
        elif has_comment or day_tags:
            if not in_range:
                bg = t.hover
        fg = "#0E0E14" if (d == today or in_range) else t.fg
        cell = tk.Frame(parent, bg=bg, cursor="hand2")
        cell.grid(row=row, column=col, sticky="nsew", padx=2, pady=2)
        cell.pack_propagate(False)
        cell.configure(height=70 if big else 60)
        # Store original bg for hover
        cell._orig_bg = bg
        cell._hover_bg = blend(bg, t.accent, 0.4) if not in_range else bg
        tk.Label(cell, text=str(d.day), bg=bg, fg=fg, font=t.f(0, True), anchor="ne").pack(fill="x", padx=4, pady=2)
        if due_count > 0:
            status = f"{done_count}/{due_count}"
            color = t.success if done_count == due_count else t.warn
            tk.Label(cell, text=status, bg=bg, fg=color, font=t.f(-2)).pack(anchor="w", padx=4)
        if has_comment:
            comment = day_comments[iso]
            preview = (comment[:18] + "..") if len(comment) > 18 else comment
            tk.Label(cell, text=preview, bg=bg, fg=t.muted, font=t.f(-3), anchor="w").pack(fill="x", padx=4)
        if day_tags:
            tag_str = " ".join(f"#{tg}" for tg in day_tags[:2])
            tk.Label(cell, text=tag_str, bg=bg, fg=t.warn, font=t.f(-3)).pack(anchor="w", padx=4)
        # Click: range selection (first click = start, second = end)
        cell.bind("<Button-1>", lambda e, d=d: self._on_day_click(d))
        # Hover effects
        def on_enter(e):
            if not in_range:
                cell.configure(bg=cell._hover_bg)
                for child in cell.winfo_children():
                    try: child.configure(bg=cell._hover_bg)
                    except: pass
        def on_leave(e):
            if not in_range:
                cell.configure(bg=cell._orig_bg)
                for child in cell.winfo_children():
                    try: child.configure(bg=cell._orig_bg)
                    except: pass
        cell.bind("<Enter>", on_enter)
        cell.bind("<Leave>", on_leave)

    def _on_day_click(self, d):
        """Handle day click for range selection. First click = start, second = end."""
        if self.range_start is None or (self.range_start and self.range_end):
            # First click OR third click (reset) - set start
            self.range_start = d
            self.range_end = None
        elif self.range_end is None and self.range_start:
            # Second click - set end
            if d < self.range_start:
                self.range_start, d = d, self.range_start
            self.range_end = d
        self._draw_view()
        self._select_day(d)

    def _select_day(self, d):
        t = self.t
        self.sel_date = d
        iso = d.isoformat()
        for w in self.info_frame.winfo_children(): w.destroy()
        # Header
        tk.Label(self.info_frame, text=d.strftime("%A"), bg=t.panel, fg=t.accent,
                 font=t.f(2, True)).pack(anchor="w", padx=16, pady=(16, 0))
        tk.Label(self.info_frame, text=d.strftime("%B %d, %Y"), bg=t.panel, fg=t.fg,
                 font=t.f(1)).pack(anchor="w", padx=16, pady=(0, 8))
        # Range selection info
        if self.range_start and self.range_end:
            days = (self.range_end - self.range_start).days + 1
            range_frame = tk.Frame(self.info_frame, bg=t.accent)
            range_frame.pack(fill="x", padx=12, pady=4)
            tk.Label(range_frame, text="RANGE SELECTED", bg=t.accent, fg="#0E0E14", font=t.f(-1, True)).pack(anchor="w", padx=8, pady=(4, 0))
            tk.Label(range_frame, text=f"{self.range_start.strftime('%b %d')} - {self.range_end.strftime('%b %d')}", bg=t.accent, fg="#0E0E14", font=t.f(0)).pack(anchor="w", padx=8)
            tk.Label(range_frame, text=f"{days} days", bg=t.accent, fg="#0E0E14", font=t.f(-1, True)).pack(anchor="w", padx=8, pady=(0, 4))
        elif self.range_start:
            tk.Label(self.info_frame, text=f"Start: {self.range_start.strftime('%b %d')} (click another day to select range)", bg=t.panel, fg=t.warn, font=t.f(-1)).pack(anchor="w", padx=16, pady=4)
        # Tasks due
        due = [(s, iso in hist_dates(s)) for s in self.d.streaks if is_due(s, d)]
        if due:
            tk.Label(self.info_frame, text="TASKS DUE", bg=t.panel, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", padx=16, pady=(8, 2))
            for s, done in due:
                color = t.success if done else t.warn
                tk.Label(self.info_frame, text=f"  {'OK' if done else 'X'}  {s.get('name', '?')}", bg=t.panel, fg=color,
                         font=t.f(0)).pack(anchor="w", padx=16)
        else:
            tk.Label(self.info_frame, text="No tasks due.", bg=t.panel, fg=t.dim, font=t.f(-1)).pack(anchor="w", padx=16, pady=4)
        # Day comment
        tk.Label(self.info_frame, text="DAY COMMENT", bg=t.panel, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", padx=16, pady=(12, 2))
        day_comments = self.d.settings.get("day_comments", {})
        self.day_comment = tk.StringVar(value=day_comments.get(iso, ""))
        # v5.9.9 FIX: debounced save — no full redraw per keystroke
        self._comment_timer = None
        def _debounced_save(*a):
            if self._comment_timer: self._comment_timer.cancel()
            import threading as th
            self._comment_timer = th.Timer(0.4, lambda: self.after(0, lambda: self._save_comment_quiet(iso)))
            self._comment_timer.start()
        self.day_comment.trace_add("write", _debounced_save)
        tk.Entry(self.info_frame, textvariable=self.day_comment, bg=t.card, fg=t.fg, insertbackground=t.fg, relief="flat",
                 font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).pack(fill="x", padx=16, ipady=4)
        tk.Label(self.info_frame, text="Use #tags to link in Map", bg=t.panel, fg=t.dim, font=t.f(-2)).pack(anchor="w", padx=16, pady=(2, 2))
        if day_comments.get(iso, ""):
            tk.Button(self.info_frame, text="Clear comment", bg=t.card, fg=t.danger, relief="flat",
                      font=t.f(-2), cursor="hand2", padx=8, pady=2,
                      command=lambda: self._clear_comment(iso)).pack(anchor="w", padx=16, pady=(0, 8))
        # Time period tagger
        tk.Label(self.info_frame, text="TAG TIME PERIOD", bg=t.panel, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", padx=16, pady=(8, 2))
        dur_frame = tk.Frame(self.info_frame, bg=t.panel); dur_frame.pack(fill="x", padx=16, pady=2)
        tk.Label(dur_frame, text="Duration:", bg=t.panel, fg=t.dim, font=t.f(-1)).pack(side="left", padx=(0, 4))
        # Auto-fill duration from selected range
        default_dur = 7
        if self.range_start and self.range_end:
            default_dur = (self.range_end - self.range_start).days + 1
        self.tp_dur = tk.IntVar(value=default_dur)
        tk.Spinbox(dur_frame, from_=1, to=365, textvariable=self.tp_dur, width=5, bg=t.card, fg=t.fg,
                   relief="flat", font=t.f(-1)).pack(side="left")
        tk.Label(dur_frame, text="days", bg=t.panel, fg=t.dim, font=t.f(-1)).pack(side="left", padx=4)
        tk.Label(self.info_frame, text="Tags (e.g. #sprint #phase1):", bg=t.panel, fg=t.dim, font=t.f(-1)).pack(anchor="w", padx=16, pady=(4, 2))
        self.tp_tags = tk.StringVar()
        tk.Entry(self.info_frame, textvariable=self.tp_tags, bg=t.card, fg=t.warn, insertbackground=t.fg, relief="flat",
                 font=t.f(0), highlightthickness=1, highlightbackground=t.border,
                 highlightcolor=t.accent).pack(fill="x", padx=16, ipady=4)
        # Use range_start if available, otherwise use clicked day
        tag_start = self.range_start if self.range_start else d
        tk.Button(self.info_frame, text="Tag This Period", bg=t.accent, fg="#0E0E14", relief="flat",
                  font=t.f(0, True), cursor="hand2", padx=12, pady=6,
                  command=lambda: self._tag_period(tag_start)).pack(anchor="w", padx=16, pady=(6, 4))
        # Existing time tags for this day
        time_tags = self.d.settings.get("time_tags", [])
        matching = [tt for tt in time_tags if pd(tt.get("start", "")) <= d <= pd(tt.get("start", "")) + dt.timedelta(days=int(tt.get("duration", 0)))]
        if matching:
            tk.Label(self.info_frame, text="ACTIVE PERIODS", bg=t.panel, fg=t.muted, font=t.f(-1, True)).pack(anchor="w", padx=16, pady=(8, 2))
            for tt in matching:
                tt_frame = tk.Frame(self.info_frame, bg=t.card); tt_frame.pack(fill="x", padx=16, pady=2)
                tk.Label(tt_frame, text=f"{tt.get('tags','')} ({tt.get('duration',0)}d)", bg=t.card, fg=t.warn,
                         font=t.f(-1)).pack(side="left", padx=8, pady=4)
                tk.Button(tt_frame, text="X", bg=t.card, fg=t.danger, relief="flat", font=t.f(-1),
                          cursor="hand2", padx=4, command=lambda tid=tt.get("id",""): self._delete_period(tid)).pack(side="right", padx=4)
        # Add task button
        tk.Button(self.info_frame, text="+ Add Task for this Day", bg=t.card, fg=t.fg, relief="flat",
                  font=t.f(0), cursor="hand2", padx=12, pady=6,
                  command=lambda: self._add_task_for_day(d)).pack(anchor="w", padx=16, pady=(8, 16))

    def _clear_comment(self, iso):
        if "day_comments" in self.d.settings and iso in self.d.settings["day_comments"]:
            del self.d.settings["day_comments"][iso]
            self.d.save()
        if hasattr(self, "day_comment"): self.day_comment.set("")
        self._draw_view()
        if self.sel_date: self._select_day(self.sel_date)

    def _save_comment(self, iso):
        if "day_comments" not in self.d.settings:
            self.d.settings["day_comments"] = {}
        self.d.settings["day_comments"][iso] = self.day_comment.get()
        self.d.save()
        self._draw_view()

    def _save_comment_quiet(self, iso):
        """v5.9.9 FIX: save without redrawing the whole calendar."""
        if "day_comments" not in self.d.settings:
            self.d.settings["day_comments"] = {}
        self.d.settings["day_comments"][iso] = self.day_comment.get()
        self.d.save()

    def _tag_period(self, start_date):
        tags = self.tp_tags.get().strip()
        if not tags:
            messagebox.showinfo("No Tags", "Enter tags first (e.g. #sprint)"); return
        dur = self.tp_dur.get()
        if "time_tags" not in self.d.settings:
            self.d.settings["time_tags"] = []
        self.d.settings["time_tags"].append({
            "id": str(uuid.uuid4()),
            "start": start_date.isoformat(),
            "duration": dur,
            "tags": tags,
        })
        self.d.save()
        self._draw_view()
        self._select_day(start_date)
        messagebox.showinfo("Tagged", f"Tagged {dur} days starting {start_date} with {tags}")

    def _delete_period(self, tid):
        self.d.settings["time_tags"] = [tt for tt in self.d.settings.get("time_tags", []) if tt.get("id") != tid]
        self.d.save()
        self._draw_view()
        if self.sel_date: self._select_day(self.sel_date)

    def _add_task_for_day(self, d):
        dlg = StreakDialog(self.winfo_toplevel(), self.d, self.t)
        dlg.times.set("09:00")
        self.wait_window(dlg)
        if dlg.result:
            self.d.add_streak(dlg.result)
            self._draw_view()

    def refresh(self):
        self._draw_view()


# ============================================================
# GRAPH MAP VIEW (Obsidian-style knowledge graph)
# ============================================================

class GraphMapView(tk.Frame):
    """v5.9.9: Knowledge map with right-click context menus, legend toggle,
    and deleted-nodes restore panel."""
    def __init__(self, parent, d, t, **kw):
        super().__init__(parent, bg=t.bg, **kw)
        self.d = d; self.t = t
        # Visibility state (persisted in settings)
        self._hidden_categories = set(self.d.settings.get("map_hidden_categories", []))
        self._connections_hidden = self.d.settings.get("map_connections_hidden", False)
        self._deleted_nodes = self.d.settings.get("map_deleted_nodes", [])  # list of {type, id, name, color}
        self._zoom = 1.0  # v5.10: zoom level (1.0 = 100%)
        self._build()

    def _build(self):
        t = self.t
        for w in self.winfo_children(): w.destroy()
        top = tk.Frame(self, bg=t.bg); top.pack(fill="x", padx=20, pady=(16, 8))
        tk.Label(top, text="KNOWLEDGE MAP", bg=t.bg, fg=t.accent, font=t.f(4, True)).pack(side="left")
        # Right-side buttons
        btn_frame = tk.Frame(top, bg=t.bg); btn_frame.pack(side="right")
        # v5.10: Zoom controls
        tk.Button(btn_frame, text="\u2212", bg=t.card, fg=t.fg, relief="flat", font=t.f(1, True),
                  cursor="hand2", padx=12, pady=4, command=self._zoom_out).pack(side="left", padx=2)
        self._zoom_label = tk.Label(btn_frame, text="100%", bg=t.bg, fg=t.muted, font=t.f(-1), width=6)
        self._zoom_label.pack(side="left", padx=2)
        tk.Button(btn_frame, text="+", bg=t.card, fg=t.fg, relief="flat", font=t.f(1, True),
                  cursor="hand2", padx=12, pady=4, command=self._zoom_in).pack(side="left", padx=2)
        tk.Button(btn_frame, text="Reset", bg=t.card, fg=t.muted, relief="flat", font=t.f(-1),
                  cursor="hand2", padx=8, pady=4, command=self._zoom_reset).pack(side="left", padx=2)
        tk.Button(btn_frame, text="Deleted", bg=t.card, fg=t.warn, relief="flat",
                  font=t.f(-1), cursor="hand2", padx=10, pady=4,
                  command=self._show_deleted_nodes).pack(side="left", padx=2)
        tk.Button(btn_frame, text="Refresh", bg=t.card, fg=t.fg, relief="flat", font=t.f(0), cursor="hand2",
                  padx=12, pady=4, command=self._build).pack(side="left", padx=2)
        # Legend — v5.9.9: unified color (all t.muted), click to toggle category visibility
        leg = tk.Frame(self, bg=t.bg); leg.pack(fill="x", padx=20, pady=(0, 8))
        legend_items = [
            ("Notebooks", "notebook", "\u25CF"),
            ("Notes", "note", "\u25CF"),
            ("Tasks", "task", "\u25C6"),
            ("Time Periods", "time", "\u2B21"),
            ("Splits", "split", "\u2022"),
        ]
        for label, cat, symbol in legend_items:
            is_hidden = cat in self._hidden_categories
            fg = t.dim if is_hidden else t.muted
            text = f"  {symbol}  {label}" + (" (hidden)" if is_hidden else "")
            lbl = tk.Label(leg, text=text, bg=t.bg, fg=fg, font=t.f(-1), cursor="hand2")
            lbl.pack(side="left", padx=8)
            lbl.bind("<Button-1>", lambda e, c=cat: self._toggle_category(c))
        # Connections status indicator — v5.9.9: 3 modes
        if self._connections_hidden == "hide":
            conn_text = "  #  Connections (hidden)"
            conn_fg = t.dim
        elif self._connections_hidden == True:
            conn_text = "  #  Connections (kinda hidden — 25% visible)"
            conn_fg = t.dim
        else:
            conn_text = "  #  Connections (shown)"
            conn_fg = t.muted
        tk.Label(leg, text=conn_text, bg=t.bg, fg=conn_fg, font=t.f(-1)).pack(side="left", padx=8)
        # Canvas
        cv_frame = tk.Frame(self, bg=t.bg); cv_frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.cv = tk.Canvas(cv_frame, bg=t.card, highlightthickness=1, highlightbackground=t.border)
        sx = ttk.Scrollbar(cv_frame, orient="horizontal", command=self.cv.xview)
        sy = ttk.Scrollbar(cv_frame, orient="vertical", command=self.cv.yview)
        self.cv.configure(xscrollcommand=sx.set, yscrollcommand=sy.set)
        sx.pack(side="bottom", fill="x"); sy.pack(side="right", fill="y")
        self.cv.pack(side="left", fill="both", expand=True)
        self.cv.bind("<Configure>", lambda e: self._draw())
        self.cv.bind("<MouseWheel>", lambda e: self.cv.yview_scroll(-1*(e.delta//120), "units"))
        self.cv.bind("<Shift-MouseWheel>", lambda e: self.cv.xview_scroll(-1*(e.delta//120), "units"))
        # v5.10: Control-MouseWheel = zoom (plain MouseWheel stays as scroll)
        self.cv.bind("<Control-MouseWheel>", self._on_ctrl_wheel)
        try:
            self.cv.bind("<Control-Button-4>", lambda e: self._zoom_at(1.1, e.x, e.y))
            self.cv.bind("<Control-Button-5>", lambda e: self._zoom_at(1/1.1, e.x, e.y))
        except: pass
        try:
            self.cv.bind("<Button-4>", lambda e: self.cv.yview_scroll(-2, "units"))
            self.cv.bind("<Button-5>", lambda e: self.cv.yview_scroll(2, "units"))
        except: pass
        # Middle mouse: pan
        self._mid_drag = None
        self.cv.bind("<Button-2>", self._on_mid_down)
        self.cv.bind("<B2-Motion>", self._on_mid_drag)
        self.cv.bind("<ButtonRelease-2>", lambda e: (setattr(self, "_mid_drag", None), self.cv.config(cursor="")))
        # Left-click: drag nodes
        self._drag_node = None
        self._drag_offset = (0, 0)
        self.cv.bind("<Button-1>", self._on_canvas_down)
        self.cv.bind("<B1-Motion>", self._on_canvas_drag)
        self.cv.bind("<ButtonRelease-1>", self._on_canvas_up)
        self.cv.bind("<Motion>", self._on_canvas_hover)
        # v5.9.9: Right-click context menus
        self.cv.bind("<Button-3>", self._on_right_click)
        self._hovered_node = None
        self._draw()
        # v5.10: update zoom label to reflect current zoom level after rebuild
        if hasattr(self, "_zoom_label") and self._zoom_label.winfo_exists():
            self._zoom_label.configure(text=f"{int(self._zoom * 100)}%")

    # ----------------------------------------------------------------
    # v5.9.9: Category visibility toggle (click legend item)
    # ----------------------------------------------------------------
    def _toggle_category(self, cat):
        if cat in self._hidden_categories:
            self._hidden_categories.discard(cat)
        else:
            self._hidden_categories.add(cat)
        self.d.settings["map_hidden_categories"] = list(self._hidden_categories)
        self.d.save()
        self._build()

    # ----------------------------------------------------------------
    # v5.10: Zoom controls
    # ----------------------------------------------------------------
    def _on_ctrl_wheel(self, e):
        """Control-MouseWheel: zoom in/out centered on the cursor."""
        if e.delta > 0:
            self._zoom_at(1.1, e.x, e.y)
        else:
            self._zoom_at(1 / 1.1, e.x, e.y)

    def _zoom_in(self):
        self._zoom_at(1.2)

    def _zoom_out(self):
        self._zoom_at(1 / 1.2)

    def _zoom_reset(self):
        """Reset zoom to 100% by rebuilding (cleanest way to clear all scaling)."""
        self._zoom = 1.0
        self._build()

    def _zoom_at(self, factor, px=None, py=None):
        """Scale all canvas items by `factor` around the given screen point (px, py).
        If px/py is None, zoom around the center of the visible canvas area."""
        if not hasattr(self, "_node_items") or not self._node_items:
            # nothing drawn yet — just rebuild
            self._build(); return
        cv = self.cv
        # Clamp zoom: 0.2x to 5x
        new_zoom = self._zoom * factor
        if new_zoom < 0.2 or new_zoom > 5.0:
            return
        # Determine the center point in canvas coordinates
        if px is None or py is None:
            # Center of the visible area
            x0, y0 = cv.canvasx(0), cv.canvasy(0)
            x1, y1 = cv.canvasx(cv.winfo_width()), cv.canvasy(cv.winfo_height())
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        else:
            cx, cy = cv.canvasx(px), cv.canvasy(py)
        # Scale all items around the center point
        cv.scale("all", cx, cy, factor, factor)
        # Update the scrollregion to match the new bounds
        try:
            bbox = cv.bbox("all")
            if bbox:
                cv.configure(scrollregion=bbox)
        except: pass
        # Update stored node positions so drag/edge-updates use the new coordinates
        for item_id, (typ, idv, nx, ny, r) in list(self._node_items.items()):
            new_x = cx + (nx - cx) * factor
            new_y = cy + (ny - cy) * factor
            new_r = r * factor
            self._node_items[item_id] = (typ, idv, new_x, new_y, new_r)
        # Update stored edge endpoints so right-click / edge menus use new coords
        # (edge canvas items are already scaled by cv.scale("all", ...); the
        # _edge_endpoints dict stores logical (type,id) pairs, not coords, so no update needed)
        self._zoom = new_zoom
        # Update the zoom label
        if hasattr(self, "_zoom_label") and self._zoom_label.winfo_exists():
            self._zoom_label.configure(text=f"{int(self._zoom * 100)}%")

    # ----------------------------------------------------------------
    # v5.9.9: Right-click handler
    # ----------------------------------------------------------------
    def _on_right_click(self, e):
        cv = self.cv
        x = cv.canvasx(e.x); y = cv.canvasy(e.y)
        # 1. Check if right-clicked on a node
        clicked_node = None
        for item_id, (typ, idv, nx, ny, r) in getattr(self, "_node_items", {}).items():
            d = ((x - nx)**2 + (y - ny)**2) ** 0.5
            if d < r + 5:
                clicked_node = (item_id, typ, idv, nx, ny, r)
                break
        # 2. Check if right-clicked on a connection (edge)
        clicked_edge = None
        if not clicked_node:
            # Find the closest edge within 6px
            for item_id in cv.find_all():
                tags = cv.gettags(item_id)
                if tags and "edge" in tags:
                    coords = cv.coords(item_id)
                    if len(coords) == 4:
                        # Distance from point to line segment
                        x1, y1, x2, y2 = coords
                        dist = self._point_to_line_dist(x, y, x1, y1, x2, y2)
                        if dist < 10:  # v5.9.9: increased from 6 to 10 for easier right-clicking
                            clicked_edge = item_id
                            break
        if clicked_node:
            self._node_context_menu(e, clicked_node)
        elif clicked_edge:
            self._edge_context_menu(e, clicked_edge)
        else:
            self._empty_context_menu(e)

    def _point_to_line_dist(self, px, py, x1, y1, x2, y2):
        """Distance from point (px,py) to line segment (x1,y1)-(x2,y2)."""
        dx, dy = x2 - x1, y2 - y1
        if dx == 0 and dy == 0:
            return ((px - x1)**2 + (py - y1)**2) ** 0.5
        t = max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)))
        proj_x = x1 + t * dx
        proj_y = y1 + t * dy
        return ((px - proj_x)**2 + (py - proj_y)**2) ** 0.5

    def _empty_context_menu(self, e):
        """v5.9.9: Right-click on empty map area — 3 connection modes:
        Show (solid) / Kinda Hide (75% transparent, 25% visible) / Hide (invisible)."""
        t = self.t
        menu = tk.Menu(self, tearoff=0, bg=t.card, fg=t.fg, activebackground=t.hover,
                       activeforeground=t.fg, font=t.f(0), borderwidth=0)
        # Connection visibility submenu — 3 options
        menu.add_command(label="CONNECTIONS", state="disabled")
        menu.add_separator()
        # Show current mode with a checkmark
        mode = self._connections_hidden  # False=show, True=kinda-hide, "hide"=fully hidden
        if mode == "hide":
            menu.add_command(label="   Show", command=lambda: self._set_connection_mode(False))
            menu.add_command(label="   Kinda hide (25% visible)", command=lambda: self._set_connection_mode(True))
            menu.add_command(label="✓  Hide", state="disabled")
        elif mode == True:
            menu.add_command(label="   Show", command=lambda: self._set_connection_mode(False))
            menu.add_command(label="✓  Kinda hide (25% visible)", state="disabled")
            menu.add_command(label="   Hide", command=lambda: self._set_connection_mode("hide"))
        else:  # False = show
            menu.add_command(label="✓  Show", state="disabled")
            menu.add_command(label="   Kinda hide (25% visible)", command=lambda: self._set_connection_mode(True))
            menu.add_command(label="   Hide", command=lambda: self._set_connection_mode("hide"))
        menu.add_separator()
        menu.add_command(label="Reset all positions", command=self._reset_positions)
        menu.add_command(label="Refresh map", command=self._build)
        try: menu.tk_popup(e.x_root, e.y_root)
        finally: menu.grab_release()

    def _set_connection_mode(self, mode):
        """v5.9.9: Set connection visibility mode.
        False = show (solid), True = kinda hide (75% transparent), 'hide' = invisible."""
        self._connections_hidden = mode
        self.d.settings["map_connections_hidden"] = mode
        self.d.save()
        self._build()

    def _reset_positions(self):
        if messagebox.askyesno("Reset", "Reset all node positions to default layout?"):
            self.d.settings["map_positions"] = {}
            self.d.save()
            self._build()

    def _node_context_menu(self, e, node):
        """Right-click on a node: delete / adjust transparency / change color."""
        t = self.t
        item_id, typ, idv, nx, ny, r = node
        menu = tk.Menu(self, tearoff=0, bg=t.card, fg=t.fg, activebackground=t.hover,
                       activeforeground=t.fg, font=t.f(0), borderwidth=0)
        # Get node name for the header
        name = self._get_node_name(typ, idv)
        menu.add_command(label=f"{typ.capitalize()}: {name}", state="disabled")
        menu.add_separator()
        menu.add_command(label="Delete node (hide from map)", command=lambda: self._delete_node(item_id, typ, idv))
        menu.add_command(label="Change color...", command=lambda: self._change_node_color(item_id, typ, idv))
        menu.add_command(label="Adjust transparency...", command=lambda: self._adjust_node_transparency(item_id, typ, idv))
        menu.add_separator()
        menu.add_command(label="Reset position", command=lambda: self._reset_node_position(item_id, typ, idv))
        try: menu.tk_popup(e.x_root, e.y_root)
        finally: menu.grab_release()

    def _edge_context_menu(self, e, edge_item):
        """Right-click on a connection: remove / adjust transparency / change color."""
        t = self.t
        menu = tk.Menu(self, tearoff=0, bg=t.card, fg=t.fg, activebackground=t.hover,
                       activeforeground=t.fg, font=t.f(0), borderwidth=0)
        menu.add_command(label="Connection", state="disabled")
        menu.add_separator()
        menu.add_command(label="Remove this connection", command=lambda: self._remove_edge(edge_item))
        menu.add_command(label="Change color...", command=lambda: self._change_edge_color(edge_item))
        menu.add_command(label="Adjust transparency...", command=lambda: self._adjust_edge_transparency(edge_item))
        try: menu.tk_popup(e.x_root, e.y_root)
        finally: menu.grab_release()

    # ----------------------------------------------------------------
    # Node actions
    # ----------------------------------------------------------------
    def _get_node_name(self, typ, idv):
        if typ == "notebook":
            nb = self.d.get_notebook(idv)
            return nb.get("name", "?") if nb else "?"
        elif typ == "note":
            n = self.d.get_note(idv)
            return n.get("title", "?") if n else "?"
        elif typ == "task":
            s = self.d.get_streak(idv)
            return s.get("name", "?") if s else "?"
        elif typ == "time":
            for tt in self.d.settings.get("time_tags", []):
                if tt.get("id") == idv:
                    return tt.get("tags", "?")
            return "?"
        elif typ == "split":
            # idv format: {note_id}_split{idx}
            parts = idv.rsplit("_split", 1)
            if len(parts) == 2:
                n = self.d.get_note(parts[0])
                if n:
                    content = n.get("content", "")
                    splits = re.findall(r'^===SPLIT:([^|]+)', content, re.MULTILINE)
                    idx = int(parts[1])
                    if idx < len(splits):
                        return splits[idx].strip()
            return "Split"
        return "?"

    def _delete_node(self, item_id, typ, idv):
        """Hide a node from the map (store in deleted_nodes for later restore)."""
        name = self._get_node_name(typ, idv)
        # Get current color if stored
        color = self.d.settings.get("map_node_colors", {}).get(f"{typ}:{idv}", "")
        self._deleted_nodes.append({"type": typ, "id": idv, "name": name, "color": color})
        self.d.settings["map_deleted_nodes"] = self._deleted_nodes
        self.d.save()
        self._build()

    def _change_node_color(self, item_id, typ, idv):
        """Change a node's color (persisted in settings)."""
        colors = self.d.settings.get("map_node_colors", {})
        current = colors.get(f"{typ}:{idv}", self.t.accent)
        c = colorchooser.askcolor(current, title="Node color")[1]
        if c:
            colors[f"{typ}:{idv}"] = c
            self.d.settings["map_node_colors"] = colors
            self.d.save()
            self._build()

    def _adjust_node_transparency(self, item_id, typ, idv):
        """Adjust a node's transparency (0-100%)."""
        current = self.d.settings.get("map_node_transparency", {}).get(f"{typ}:{idv}", 0)
        val = simpledialog.askinteger("Transparency", "Transparency (0=solid, 80=mostly transparent):",
                                      parent=self, initialvalue=current, minvalue=0, maxvalue=95)
        if val is not None:
            transp = self.d.settings.get("map_node_transparency", {})
            transp[f"{typ}:{idv}"] = val
            self.d.settings["map_node_transparency"] = transp
            self.d.save()
            self._build()

    def _reset_node_position(self, item_id, typ, idv):
        """Clear saved position for this node so it returns to default layout."""
        positions = self.d.settings.get("map_positions", {})
        key = f"{typ}:{idv}"
        if key in positions:
            del positions[key]
            self.d.settings["map_positions"] = positions
            self.d.save()
            self._build()

    # ----------------------------------------------------------------
    # Edge actions
    # ----------------------------------------------------------------
    def _remove_edge(self, edge_item):
        """v5.9.9: Remove a connection — uses stored endpoint info from _edge_endpoints.
        Works for tag connections, notebook-note hierarchy, and note-split hierarchy."""
        ep = getattr(self, "_edge_endpoints", {}).get(edge_item)
        if not ep:
            # Fallback: try coords-based lookup (legacy)
            coords = self.cv.coords(edge_item)
            if len(coords) == 4:
                n1 = self._find_node_at(coords[0], coords[1])
                n2 = self._find_node_at(coords[2], coords[3])
                if n1 and n2: ep = (n1[0], n1[1], n2[0], n2[1])
        if ep:
            t1, i1, t2, i2 = ep
            removed = self.d.settings.get("map_removed_edges", [])
            removed.append({"from": f"{t1}:{i1}", "to": f"{t2}:{i2}"})
            self.d.settings["map_removed_edges"] = removed
            self.d.save()
            self._build()

    def _find_node_at(self, x, y):
        """Find the node closest to (x, y).
        v5.9.9: increased tolerance from r+2 to r+10 so hierarchy connections
        (notebook-to-note, note-to-split) can be right-clicked and removed."""
        for item_id, (typ, idv, nx, ny, r) in getattr(self, "_node_items", {}).items():
            if abs(nx - x) < r + 10 and abs(ny - y) < r + 10:
                return (typ, idv)
        return None

    def _change_edge_color(self, edge_item):
        """v5.9.9: Uses _edge_endpoints for reliable endpoint lookup."""
        ep = getattr(self, "_edge_endpoints", {}).get(edge_item)
        if not ep:
            coords = self.cv.coords(edge_item)
            if len(coords) == 4:
                n1 = self._find_node_at(coords[0], coords[1])
                n2 = self._find_node_at(coords[2], coords[3])
                if n1 and n2: ep = (n1[0], n1[1], n2[0], n2[1])
        if ep:
            t1, i1, t2, i2 = ep
            key = f"{t1}:{i1}-{t2}:{i2}"
            colors = self.d.settings.get("map_edge_colors", {})
            current = colors.get(key, self.t.warn)
            c = colorchooser.askcolor(current, title="Connection color")[1]
            if c:
                colors[key] = c
                colors[f"{t2}:{i2}-{t1}:{i1}"] = c  # both directions
                self.d.settings["map_edge_colors"] = colors
                self.d.save()
                self._build()

    def _adjust_edge_transparency(self, edge_item):
        """v5.9.9: Uses _edge_endpoints for reliable endpoint lookup."""
        ep = getattr(self, "_edge_endpoints", {}).get(edge_item)
        if not ep:
            coords = self.cv.coords(edge_item)
            if len(coords) == 4:
                n1 = self._find_node_at(coords[0], coords[1])
                n2 = self._find_node_at(coords[2], coords[3])
                if n1 and n2: ep = (n1[0], n1[1], n2[0], n2[1])
        if ep:
            t1, i1, t2, i2 = ep
            key = f"{t1}:{i1}-{t2}:{i2}"
            transp = self.d.settings.get("map_edge_transparency", {})
            current = transp.get(key, 0)
            val = simpledialog.askinteger("Transparency", "Connection transparency (0=solid, 80=mostly transparent):",
                                          parent=self, initialvalue=current, minvalue=0, maxvalue=95)
            if val is not None:
                transp[key] = val
                transp[f"{t2}:{i2}-{t1}:{i1}"] = val
                self.d.settings["map_edge_transparency"] = transp
                self.d.save()
                self._build()

    # ----------------------------------------------------------------
    # Deleted nodes restore panel
    # ----------------------------------------------------------------
    def _show_deleted_nodes(self):
        """v5.9.9: Show a dialog listing all deleted nodes AND connections with checkboxes to restore."""
        t = self.t
        dlg = tk.Toplevel(self); dlg.title("Deleted")
        dlg.configure(bg=t.bg); dlg.transient(self.winfo_toplevel()); dlg.grab_set()
        dlg.resizable(False, False)
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        _w, _h = 500, 520
        dlg.geometry(f"{_w}x{_h}+{(sw-_w)//2}+{(sh-_h)//2}")
        tk.Label(dlg, text="DELETED", bg=t.bg, fg=t.accent, font=t.f(2, True)).pack(pady=(16, 4))
        tk.Label(dlg, text="Check items to bring them back, then click Restore.", bg=t.bg,
                 fg=t.muted, font=t.f(-1)).pack(pady=(0, 12))
        deleted_edges = self.d.settings.get("map_removed_edges", [])
        sf = ScrollFrame(dlg, t); sf.pack(fill="both", expand=True, padx=20, pady=4)
        inner = sf.inner
        vars_list = []  # (BooleanVar, type, data)
        # --- Deleted Nodes section ---
        tk.Label(inner, text="NODES", bg=t.bg, fg=t.warn, font=t.f(-1, True)).pack(anchor="w", padx=4, pady=(4, 2))
        if not self._deleted_nodes:
            tk.Label(inner, text="  No deleted nodes.", bg=t.bg, fg=t.dim, font=t.f(-1)).pack(anchor="w", padx=4)
        else:
            for dn in self._deleted_nodes:
                v = tk.BooleanVar(value=False)
                vars_list.append((v, "node", dn))
                row = tk.Frame(inner, bg=t.card); row.pack(fill="x", pady=2, padx=4)
                tk.Checkbutton(row, variable=v, bg=t.card, fg=t.fg, selectcolor=t.hover,
                               activebackground=t.card, activeforeground=t.fg,
                               font=t.f(0)).pack(side="left", padx=8, pady=6)
                tk.Label(row, text=f"{dn['type'].capitalize()}: {dn['name']}", bg=t.card, fg=t.fg,
                         font=t.f(0)).pack(side="left", padx=4)
        # --- Deleted Connections section ---
        tk.Label(inner, text="CONNECTIONS", bg=t.bg, fg=t.warn, font=t.f(-1, True)).pack(anchor="w", padx=4, pady=(12, 2))
        if not deleted_edges:
            tk.Label(inner, text="  No deleted connections.", bg=t.bg, fg=t.dim, font=t.f(-1)).pack(anchor="w", padx=4)
        else:
            for de in deleted_edges:
                v = tk.BooleanVar(value=False)
                vars_list.append((v, "edge", de))
                # Try to get readable names
                from_label = de.get("from", "?")
                to_label = de.get("to", "?")
                # Parse type:id format
                def _parse(s):
                    parts = s.split(":", 1)
                    if len(parts) == 2:
                        return f"{parts[0]}:{self._get_node_name(parts[0], parts[1])}"
                    return s
                label = f"{_parse(from_label)}  \u2194  {_parse(to_label)}"
                row = tk.Frame(inner, bg=t.card); row.pack(fill="x", pady=2, padx=4)
                tk.Checkbutton(row, variable=v, bg=t.card, fg=t.fg, selectcolor=t.hover,
                               activebackground=t.card, activeforeground=t.fg,
                               font=t.f(0)).pack(side="left", padx=8, pady=6)
                tk.Label(row, text=label, bg=t.card, fg=t.fg, font=t.f(-1)).pack(side="left", padx=4)
        def restore():
            # Restore selected nodes
            nodes_to_restore = [data for v, typ, data in vars_list if v.get() and typ == "node"]
            edges_to_restore = [data for v, typ, data in vars_list if v.get() and typ == "edge"]
            if nodes_to_restore:
                self._deleted_nodes = [dn for dn in self._deleted_nodes if dn not in nodes_to_restore]
                self.d.settings["map_deleted_nodes"] = self._deleted_nodes
            if edges_to_restore:
                remaining_edges = [de for de in self.d.settings.get("map_removed_edges", []) if de not in edges_to_restore]
                self.d.settings["map_removed_edges"] = remaining_edges
            if nodes_to_restore or edges_to_restore:
                self.d.save()
                dlg.destroy()
                self._build()
            else:
                dlg.destroy()
        bf = tk.Frame(dlg, bg=t.bg); bf.pack(fill="x", pady=12, padx=20)
        tk.Button(bf, text="Restore Selected", bg=t.accent, fg="#0E0E14", relief="flat",
                  font=t.f(0, True), cursor="hand2", padx=20, pady=8, command=restore).pack(side="left")
        def restore_all():
            self._deleted_nodes = []
            self.d.settings["map_deleted_nodes"] = self._deleted_nodes
            self.d.settings["map_removed_edges"] = []
            self.d.save()
            dlg.destroy()
            self._build()
        tk.Button(bf, text="Restore All", bg=t.card, fg=t.fg, relief="flat", font=t.f(0),
                  cursor="hand2", padx=16, pady=8, command=restore_all).pack(side="left", padx=8)
        tk.Button(bf, text="Close", bg=t.card, fg=t.muted, relief="flat", font=t.f(0),
                  cursor="hand2", padx=16, pady=8, command=dlg.destroy).pack(side="right")

    # ----------------------------------------------------------------
    # Helpers for transparency
    # ----------------------------------------------------------------
    def _alpha_color(self, hex_color, alpha_pct):
        """Blend hex_color toward the canvas bg by alpha_pct (0=solid, 100=invisible)."""
        if alpha_pct <= 0: return hex_color
        if alpha_pct >= 95: return self.t.card  # effectively invisible
        return blend(self.t.card, hex_color, 1.0 - alpha_pct / 100.0)

    def _is_node_deleted(self, typ, idv):
        """Check if a node is in the deleted list.
        v5.9.9: also returns True if a split's parent note is deleted."""
        for dn in self._deleted_nodes:
            if dn["type"] == typ and dn["id"] == idv:
                return True
        # v5.9.9: if this is a split, check if its parent note is deleted
        if typ == "split":
            parts = idv.rsplit("_split", 1)
            if len(parts) == 2:
                parent_note_id = parts[0]
                for dn in self._deleted_nodes:
                    if dn["type"] == "note" and dn["id"] == parent_note_id:
                        return True
        return False

    def _is_edge_removed(self, typ1, id1, typ2, id2):
        """Check if an edge between two nodes has been removed."""
        removed = self.d.settings.get("map_removed_edges", [])
        k1 = f"{typ1}:{id1}-{typ2}:{id2}"
        k2 = f"{typ2}:{id2}-{typ1}:{id1}"
        for r in removed:
            rk = f"{r['from']}-{r['to']}"
            if rk == k1 or rk == k2:
                return True
        return False

    # ----------------------------------------------------------------
    # Pan + drag (unchanged from original)
    # ----------------------------------------------------------------
    def _on_mid_down(self, e):
        self._mid_drag = (e.x, e.y)
        self.cv.config(cursor="fleur")

    def _on_mid_drag(self, e):
        if not self._mid_drag: return
        dx = e.x - self._mid_drag[0]; dy = e.y - self._mid_drag[1]
        self._mid_drag = (e.x, e.y)
        self.cv.xview_scroll(int(-dx / 10), "units")
        self.cv.yview_scroll(int(-dy / 10), "units")

    def _on_canvas_down(self, e):
        cv = self.cv
        x = cv.canvasx(e.x); y = cv.canvasy(e.y)
        closest = None; min_d = 999
        for item_id, (typ, idv, nx, ny, r) in getattr(self, "_node_items", {}).items():
            d = ((x - nx)**2 + (y - ny)**2) ** 0.5
            if d < r + 5 and d < min_d:
                min_d = d; closest = (item_id, typ, idv, nx, ny, r)
        if closest:
            self._remove_halo()
            self._hovered_node = None
            self._drag_node = closest
            self._drag_offset = (x - closest[3], y - closest[4])
            self.cv.config(cursor="hand2")

    def _on_canvas_drag(self, e):
        if not self._drag_node: return
        cv = self.cv
        x = cv.canvasx(e.x) - self._drag_offset[0]
        y = cv.canvasy(e.y) - self._drag_offset[1]
        item_id, typ, idv, old_x, old_y, r = self._drag_node
        dx = x - old_x; dy = y - old_y
        if dx == 0 and dy == 0: return
        self._node_items[item_id] = (typ, idv, x, y, r)
        self._drag_node = (item_id, typ, idv, x, y, r)
        cv.move(item_id, dx, dy)
        if hasattr(self, "_node_labels") and item_id in self._node_labels:
            for lbl_id in self._node_labels[item_id]:
                cv.move(lbl_id, dx, dy)
        self._update_edges_for_node(typ, idv, x, y)

    def _on_canvas_up(self, e):
        if self._drag_node:
            self._save_node_positions()
        self._drag_node = None
        self.cv.config(cursor="")

    def _save_node_positions(self):
        if not hasattr(self, "_node_items") or not self._node_items: return
        # v5.10: divide by zoom so saved positions are in unscaled (logical) space.
        # _draw re-applies the zoom after placing nodes, so this keeps saved
        # positions zoom-independent.
        z = self._zoom if self._zoom else 1.0
        positions = {}
        for item_id, (typ, idv, nx, ny, r) in self._node_items.items():
            positions[f"{typ}:{idv}"] = [nx / z, ny / z]
        self.d.settings["map_positions"] = positions
        self.d.save()

    def _on_canvas_hover(self, e):
        cv = self.cv
        x = cv.canvasx(e.x); y = cv.canvasy(e.y)
        hovered_id = None
        for item_id, (typ, idv, nx, ny, r) in getattr(self, "_node_items", {}).items():
            d = ((x - nx)**2 + (y - ny)**2) ** 0.5
            if d < r + 5:
                hovered_id = item_id
                break
        cv.config(cursor="hand2" if hovered_id else "")
        if not hasattr(self, "_hovered_node"): self._hovered_node = None
        if hovered_id != self._hovered_node:
            self._remove_halo()
            self._hovered_node = hovered_id
            if hovered_id and hovered_id in self._node_items:
                self._bounce_step = 0
                self._animate_bounce()

    def _animate_bounce(self):
        if not self._hovered_node or self._hovered_node not in self._node_items:
            return
        cv = self.cv
        typ, idv, nx, ny, r = self._node_items[self._hovered_node]
        self._remove_halo()
        steps = [0, 2, 4, 6, 4, 2]
        if not hasattr(self, "_bounce_step"): self._bounce_step = 0
        idx = self._bounce_step % len(steps)
        extra = steps[idx]
        if extra > 0:
            t = self.t
            self._halo = cv.create_oval(nx - r - extra, ny - r - extra,
                                        nx + r + extra, ny + r + extra,
                                        outline=t.accent, width=2, tags="halo")
            cv.tag_lower("halo")
        self._bounce_step += 1
        if self._hovered_node:
            self._bounce_after = self.after(80, self._animate_bounce)

    def _remove_halo(self):
        try: self.cv.delete("halo")
        except: pass
        if hasattr(self, "_bounce_after"):
            try: self.after_cancel(self._bounce_after)
            except: pass
            self._bounce_after = None

    def _update_edges_for_node(self, typ, idv, x, y):
        """Update only edges connected to this node — smooth, no full redraw."""
        cv = self.cv
        t = self.t
        pos = {}
        for item_id, (ntyp, nidv, nx, ny, r) in getattr(self, "_node_items", {}).items():
            pos[(ntyp, nidv)] = (nx, ny)
        notebooks = self.d.get_notebooks()
        notes = self.d.notes
        tasks = self.d.streaks
        time_tags = self.d.settings.get("time_tags", [])
        tag_map = {}
        for n in notes:
            blob = (n.get("tags","") or "") + " " + (n.get("title","") or "") + " " + (n.get("content","") or "")
            for tag in re.findall(r'#(\w+)', blob):
                tag_map.setdefault(tag, []).append(("note", n["id"]))
        for s in tasks:
            for tag in re.findall(r'#(\w+)', s.get("tags","") or ""):
                tag_map.setdefault(tag, []).append(("task", s["id"]))
        for tt in time_tags:
            for tag in re.findall(r'#(\w+)', tt.get("tags","") or ""):
                tag_map.setdefault(tag, []).append(("time", tt.get("id","")))
        for nb in notebooks:
            for tag in re.findall(r'#(\w+)', nb.get("tags","") or ""):
                tag_map.setdefault(tag, []).append(("notebook", nb["id"]))
        # v5.9.9: include splits (with their own #tags) in the tag map
        # FIXED regex: optional 3rd group (tags) — was requiring tags, causing sync bugs
        for n in notes:
            content = n.get("content", "") or ""
            for m in re.finditer(r'^===SPLIT:([^|]+)\|([^|]*)(?:\|([^=]*))?===\s*$', content, re.MULTILINE):
                sp_name, _sp_bg, sp_tags = m.group(1), m.group(2), m.group(3) or ""
                idx = len(re.findall(r'^===SPLIT:', content[:m.start()], re.MULTILINE))
                sp_id = f"{n['id']}_split{idx}"
                for tag in re.findall(r'#(\w+)', sp_tags or ""):
                    tag_map.setdefault(tag, []).append(("split", sp_id))
        cv.delete("edge")
        cv.delete("edgelabel")
        self._edge_endpoints = {}  # v5.9.9: clear before redrawing
        # v5.9.9: respect hidden connections + edge transparency + removed edges
        # Mode: False=show (0% alpha), True=kinda hide (75% alpha), "hide"=skip entirely
        if self._connections_hidden == "hide":
            return  # don't draw any edges
        edge_alpha = 80 if self._connections_hidden == True else 0  # 80% transparent (percentage, not fraction)
        edge_colors = self.d.settings.get("map_edge_colors", {})
        edge_transp = self.d.settings.get("map_edge_transparency", {})
        for tag, items in tag_map.items():
            if len(items) < 2: continue
            for i in range(len(items)):
                for j in range(i+1, len(items)):
                    p1 = pos.get(items[i]); p2 = pos.get(items[j])
                    if p1 and p2:
                        t1, i1 = items[i]; t2, i2 = items[j]
                        if self._is_edge_removed(t1, i1, t2, i2): continue
                        key1 = f"{t1}:{i1}-{t2}:{i2}"
                        key2 = f"{t2}:{i2}-{t1}:{i1}"
                        ecolor = edge_colors.get(key1) or edge_colors.get(key2) or t.warn
                        et = edge_transp.get(key1, edge_transp.get(key2, 0))
                        total_alpha = max(et, edge_alpha)
                        ecolor = self._alpha_color(ecolor, total_alpha)
                        _eid = cv.create_line(p1[0], p1[1], p2[0], p2[1], fill=ecolor, width=2, dash=(4,3), tags="edge")
                        self._edge_endpoints[_eid] = (t1, i1, t2, i2)  # v5.9.9: store for right-click
                        mx, my = (p1[0]+p2[0])//2, (p1[1]+p2[1])//2
                        cv.create_text(mx, my, text=f"#{tag}", fill=ecolor, font=t.f(-3), tags="edgelabel")
        for nb in notebooks:
            for n in notes:
                if n.get("notebook_id") == nb["id"]:
                    p1 = pos.get(("notebook", nb["id"])); p2 = pos.get(("note", n["id"]))
                    if p1 and p2:
                        if self._is_edge_removed("notebook", nb["id"], "note", n["id"]): continue
                        _eid = cv.create_line(p1[0], p1[1], p2[0], p2[1], fill=t.border, width=1, tags="edge")
                        self._edge_endpoints[_eid] = ("notebook", nb["id"], "note", n["id"])
        for n in notes:
            np_ = pos.get(("note", n["id"]))
            if not np_: continue
            content = n.get("content", "") or ""
            split_names = re.findall(r'^===SPLIT:([^|]+)\|', content, re.MULTILINE)
            for j in range(len(split_names)):
                sp_id = f"{n['id']}_split{j}"
                sp = pos.get(("split", sp_id))
                if sp:
                    if self._is_edge_removed("note", n["id"], "split", sp_id): continue
                    _eid = cv.create_line(np_[0], np_[1], sp[0], sp[1], fill=t.dim, width=1, tags="edge")
                    self._edge_endpoints[_eid] = ("note", n["id"], "split", sp_id)
        # v5.9.9: lower ALL edges below nodes ONCE (not per-edge — that caused
        # connections to disappear until you clicked a node)
        cv.tag_lower("edge")
        cv.tag_lower("edgelabel")

    def _redraw_edges_for(self, typ, idv, new_x, new_y):
        """Redraw all edges connected to a moved node."""
        self._update_edges_for_node(typ, idv, new_x, new_y)

    def _draw(self):
        t = self.t; cv = self.cv
        cv.delete("all")
        w = max(cv.winfo_width(), 1200); h = max(cv.winfo_height(), 800)
        cv.configure(scrollregion=(-50, -50, w + 50, h + 50))
        if cv.winfo_width() < 50 or cv.winfo_height() < 50: return
        self._node_items = {}
        self._node_labels = {}
        self._edge_endpoints = {}  # v5.9.9: edge canvas_item_id -> (t1, i1, t2, i2)
        notebooks = self.d.get_notebooks()
        notes = self.d.notes
        tasks = self.d.streaks
        time_tags = self.d.settings.get("time_tags", [])
        cx, cy = w // 2, h // 2
        note_positions = {}
        nb_positions = {}
        task_positions = {}
        tp_positions = {}
        saved_pos = self.d.settings.get("map_positions", {})
        # v5.9.9: load color + transparency settings
        node_colors = self.d.settings.get("map_node_colors", {})
        node_transp = self.d.settings.get("map_node_transparency", {})
        edge_colors = self.d.settings.get("map_edge_colors", {})
        edge_transp = self.d.settings.get("map_edge_transparency", {})
        edge_alpha = 80 if self._connections_hidden == True else 0  # 80% transparent (percentage, not fraction)  # 80% transparent when "kinda hide"
        # Empty state
        if not notes and not tasks and not time_tags and not notebooks:
            cv.create_text(w // 2, h // 2, text="No content yet.\nCreate notes/tasks with #tags to see connections.",
                           fill=t.dim, font=t.f(1), justify="center")
            return
        # Position notebooks in a circle (skip if hidden)
        visible_notebooks = [nb for nb in notebooks if "notebook" not in self._hidden_categories and not self._is_node_deleted("notebook", nb["id"])]
        n_nbs = max(len(visible_notebooks), 1)
        radius_nb = min(w, h) * 0.3
        for i, nb in enumerate(visible_notebooks):
            angle = 2 * math.pi * i / n_nbs - math.pi / 2
            x = cx + radius_nb * math.cos(angle)
            y = cy + radius_nb * math.sin(angle)
            sp = saved_pos.get(f"notebook:{nb['id']}")
            if sp: x, y = sp[0], sp[1]
            nb_positions[nb["id"]] = (x, y)
        # Position unassigned notes
        unassigned = [n for n in notes if not n.get("notebook_id")
                      and "note" not in self._hidden_categories
                      and not self._is_node_deleted("note", n["id"])]
        if not notebooks and unassigned:
            n_un = len(unassigned)
            r_un = min(w, h) * 0.25
            for i, n in enumerate(unassigned):
                angle = 2 * math.pi * i / max(n_un, 1) - math.pi / 2
                x = cx + r_un * math.cos(angle)
                y = cy + r_un * math.sin(angle)
                sp = saved_pos.get(f"note:{n['id']}")
                if sp: x, y = sp[0], sp[1]
                note_positions[n["id"]] = (x, y)
        else:
            for i, n in enumerate(unassigned):
                cols = max(1, int(math.ceil(math.sqrt(len(unassigned)))))
                r = i // cols; c = i % cols
                x = cx - 120 + c * 80
                y = cy - 80 + r * 60
                sp = saved_pos.get(f"note:{n['id']}")
                if sp: x, y = sp[0], sp[1]
                note_positions[n["id"]] = (x, y)
        for nb in notebooks:
            if "notebook" in self._hidden_categories or self._is_node_deleted("notebook", nb["id"]): continue
            nbx, nby = nb_positions.get(nb["id"], (cx, cy))
            nb_notes = [n for n in notes if n.get("notebook_id") == nb["id"]
                        and "note" not in self._hidden_categories
                        and not self._is_node_deleted("note", n["id"])]
            for i, n in enumerate(nb_notes):
                angle = 2 * math.pi * i / max(len(nb_notes), 1)
                x = nbx + 90 * math.cos(angle)
                y = nby + 90 * math.sin(angle)
                sp = saved_pos.get(f"note:{n['id']}")
                if sp: x, y = sp[0], sp[1]
                note_positions[n["id"]] = (x, y)
        # Position tasks (skip if hidden)
        visible_tasks = [s for s in tasks if "task" not in self._hidden_categories and not self._is_node_deleted("task", s["id"])]
        n_tasks = len(visible_tasks)
        for i, s in enumerate(visible_tasks):
            if n_tasks == 1:
                x = cx; y = 40
            else:
                x = 80 + i * (w - 160) / max(n_tasks - 1, 1)
                y = 40
            sp = saved_pos.get(f"task:{s['id']}")
            if sp: x, y = sp[0], sp[1]
            task_positions[s["id"]] = (x, y)
        # Position time-period nodes
        visible_tp = [tt for tt in time_tags if "time" not in self._hidden_categories and not self._is_node_deleted("time", tt.get("id", ""))]
        n_tp = len(visible_tp)
        for i, tt in enumerate(visible_tp):
            tid = tt.get("id", "")
            if n_tp == 1:
                x = cx; y = h - 40
            else:
                x = 80 + i * (w - 160) / max(n_tp - 1, 1)
                y = h - 40
            sp = saved_pos.get(f"time:{tid}")
            if sp: x, y = sp[0], sp[1]
            tp_positions[tid] = (x, y)
        # Build tag map across ALL item types (notes, tasks, time periods, splits)
        # v5.10: skip notes that are soft-deleted from the map (their splits too)
        tag_map = {}
        splits_meta = []
        for n in notes:
            # v5.10: skip soft-deleted notes entirely — don't add their tags or splits
            if self._is_node_deleted("note", n["id"]): continue
            blob = (n.get("tags", "") or "") + " " + (n.get("title", "") or "") + " " + (n.get("content", "") or "")
            for tag in re.findall(r'#(\w+)', blob):
                tag_map.setdefault(tag, []).append(("note", n["id"]))
            content = n.get("content", "") or ""
            for idx, m in enumerate(re.finditer(r'^===SPLIT:([^|]+)\|([^|]*)(?:\|([^=]*))?===\s*$', content, re.MULTILINE)):
                sp_name = m.group(1).strip()
                sp_tags = (m.group(3) or "").strip()
                sp_id = f"{n['id']}_split{idx}"
                # v5.10: skip splits that are soft-deleted (or whose parent note is soft-deleted —
                # already handled by the continue above, but double-check here for safety).
                # v5.10: also skip splits if EITHER the split OR the note category is hidden
                # (splits are children of notes — hiding notes hides their splits too).
                if self._is_node_deleted("split", sp_id): continue
                if "split" in self._hidden_categories or "note" in self._hidden_categories: continue
                splits_meta.append((n["id"], idx, sp_id, sp_name, sp_tags))
                for tag in re.findall(r'#(\w+)', sp_tags):
                    tag_map.setdefault(tag, []).append(("split", sp_id))
        for s in tasks:
            tags = s.get("tags", "") or ""
            for tag in re.findall(r'#(\w+)', tags):
                tag_map.setdefault(tag, []).append(("task", s["id"]))
        for tt in time_tags:
            tags = tt.get("tags", "") or ""
            for tag in re.findall(r'#(\w+)', tags):
                tag_map.setdefault(tag, []).append(("time", tt.get("id", "")))
        for nb in notebooks:
            for tag in re.findall(r'#(\w+)', nb.get("tags","") or ""):
                tag_map.setdefault(tag, []).append(("notebook", nb["id"]))
        # v5.9.9 FIXED: pre-compute split positions BEFORE drawing tag connections
        # so that get_pos("split", ...) works. Previously split positions were only
        # computed inside the split-drawing loop (which runs AFTER tag drawing),
        # so split tag connections were never drawn initially.
        split_positions = {}
        for (note_id, sp_idx, sp_id, sp_name, sp_tags) in splits_meta:
            nx, ny = note_positions.get(note_id, (cx, cy))
            n_splits_in_note = sum(1 for sm in splits_meta if sm[0] == note_id)
            sa = 2 * math.pi * sp_idx / max(n_splits_in_note, 1)
            sx = nx + 35 * math.cos(sa)
            sy = ny + 35 * math.sin(sa)
            sp_key = f"split:{sp_id}"
            if sp_key in saved_pos:
                sx, sy = saved_pos[sp_key][0], saved_pos[sp_key][1]
            split_positions[sp_id] = (sx, sy)

        def get_pos(typ, idv):
            if typ == "note": return note_positions.get(idv)
            if typ == "task": return task_positions.get(idv)
            if typ == "time": return tp_positions.get(idv)
            if typ == "notebook": return nb_positions.get(idv)
            if typ == "split": return split_positions.get(idv)  # v5.9.9 FIXED
            return None
        # Draw tag links FIRST (behind everything) — v5.9.9: respect transparency + removed edges
        # v5.9.9: skip entirely if mode is "hide"
        if self._connections_hidden != "hide":
            for tag, items in tag_map.items():
                if len(items) < 2: continue
                for i in range(len(items)):
                    for j in range(i + 1, len(items)):
                        p1 = get_pos(items[i][0], items[i][1])
                        p2 = get_pos(items[j][0], items[j][1])
                        if p1 and p2:
                            t1, i1 = items[i]; t2, i2 = items[j]
                            if self._is_edge_removed(t1, i1, t2, i2): continue
                            key1 = f"{t1}:{i1}-{t2}:{i2}"
                            key2 = f"{t2}:{i2}-{t1}:{i1}"
                            ecolor = edge_colors.get(key1) or edge_colors.get(key2) or t.warn
                            et = edge_transp.get(key1, edge_transp.get(key2, 0))
                            total_alpha = max(et, edge_alpha)
                            ecolor = self._alpha_color(ecolor, total_alpha)
                            _eid = cv.create_line(p1[0], p1[1], p2[0], p2[1], fill=ecolor, width=2, dash=(4, 3), tags="edge")
                            self._edge_endpoints[_eid] = (t1, i1, t2, i2)  # v5.9.9: store for right-click
                            mx, my = (p1[0]+p2[0])//2, (p1[1]+p2[1])//2
                            cv.create_text(mx, my, text=f"#{tag}", fill=ecolor, font=t.f(-3), tags="edgelabel")
            # Draw notebook-to-note lines — v5.9.9: respect connection visibility
            for nb in notebooks:
                if "notebook" in self._hidden_categories or self._is_node_deleted("notebook", nb["id"]): continue
                nbx, nby = nb_positions.get(nb["id"], (cx, cy))
                for n in notes:
                    if n.get("notebook_id") == nb["id"] and "note" not in self._hidden_categories and not self._is_node_deleted("note", n["id"]):
                        px, py = note_positions.get(n["id"], (cx, cy))
                        if self._connections_hidden != "hide":
                            line_color = t.border
                            if self._connections_hidden == True:
                                line_color = self._alpha_color(t.border, 80)
                            # v5.9.9: apply per-edge color + transparency for hierarchy edges
                            _hkey1 = f"notebook:{nb['id']}-note:{n['id']}"
                            _hkey2 = f"note:{n['id']}-notebook:{nb['id']}"
                            _hcolor = edge_colors.get(_hkey1) or edge_colors.get(_hkey2) or line_color
                            _htransp = edge_transp.get(_hkey1, edge_transp.get(_hkey2, 0))
                            if self._connections_hidden == True:
                                _htransp = max(_htransp, 80)
                            _hcolor = self._alpha_color(_hcolor, _htransp)
                            # Check if removed
                            if self._is_edge_removed("notebook", nb["id"], "note", n["id"]): continue
                            _eid = cv.create_line(nbx, nby, px, py, fill=_hcolor, width=1, tags="edge")
                            self._edge_endpoints[_eid] = ("notebook", nb["id"], "note", n["id"])
        # Draw note-to-split lines + split dots (skip if split OR note category hidden, or deleted)
        # v5.10: hiding notes also hides their splits (splits are children of notes).
        # v5.9.9: also skip if connections are fully hidden; apply transparency if kinda-hidden
        for (note_id, sp_idx, sp_id, sp_name, sp_tags) in splits_meta:
            if "split" in self._hidden_categories or "note" in self._hidden_categories: continue
            if self._is_node_deleted("split", sp_id): continue
            nx, ny = note_positions.get(note_id, (cx, cy))
            n_splits_in_note = sum(1 for sm in splits_meta if sm[0] == note_id)
            j = sp_idx
            sa = 2 * math.pi * j / max(n_splits_in_note, 1)
            sx = nx + 35 * math.cos(sa)
            sy = ny + 35 * math.sin(sa)
            sp_key = f"split:{sp_id}"
            if sp_key in saved_pos:
                sx, sy = saved_pos[sp_key][0], saved_pos[sp_key][1]
            # v5.9.9: respect connection visibility for split-to-note lines too
            if self._connections_hidden != "hide":
                line_color = t.dim
                if self._connections_hidden == True:
                    line_color = self._alpha_color(t.dim, 80)  # 80% transparent
                # v5.9.9: apply per-edge color + transparency for split hierarchy edges
                _skey1 = f"note:{note_id}-split:{sp_id}"
                _skey2 = f"split:{sp_id}-note:{note_id}"
                _scolor = edge_colors.get(_skey1) or edge_colors.get(_skey2) or line_color
                _stransp = edge_transp.get(_skey1, edge_transp.get(_skey2, 0))
                if self._connections_hidden == True:
                    _stransp = max(_stransp, 80)
                _scolor = self._alpha_color(_scolor, _stransp)
                if self._is_edge_removed("note", note_id, "split", sp_id):
                    pass  # skip drawing the line but still draw the split dot
                else:
                    _eid = cv.create_line(nx, ny, sx, sy, fill=_scolor, width=1, tags="edge")
                    self._edge_endpoints[_eid] = ("note", note_id, "split", sp_id)
            sp_color = node_colors.get(f"split:{sp_id}", t.warn)
            sp_transp = node_transp.get(f"split:{sp_id}", 0)
            sp_color = self._alpha_color(sp_color, sp_transp)
            sp_item = cv.create_oval(sx - 5, sy - 5, sx + 5, sy + 5, fill=sp_color, outline="", tags="split")
            label_text = sp_name[:8]
            if sp_tags: label_text += " " + sp_tags
            sp_lbl = cv.create_text(sx, sy - 10, text=label_text, fill=t.muted, font=t.f(-4), tags="split")
            self._node_items[sp_item] = ("split", sp_id, sx, sy, 5)
            self._node_labels[sp_item] = [sp_lbl]
        # Draw notebooks (big dots) — v5.9.9: custom color + transparency
        for nb in notebooks:
            if "notebook" in self._hidden_categories or self._is_node_deleted("notebook", nb["id"]): continue
            x, y = nb_positions.get(nb["id"], (cx, cy))
            color = node_colors.get(f"notebook:{nb['id']}", t.accent)
            transp = node_transp.get(f"notebook:{nb['id']}", 0)
            color = self._alpha_color(color, transp)
            item = cv.create_oval(x - 18, y - 18, x + 18, y + 18, fill=color, outline="")
            lbl = cv.create_text(x, y, text=nb.get("name", "?")[:10], fill="#FFF", font=t.f(-2, True))
            self._node_items[item] = ("notebook", nb["id"], x, y, 18)
            self._node_labels[item] = [lbl]
        # Draw notes (medium dots)
        for n in notes:
            if "note" in self._hidden_categories or self._is_node_deleted("note", n["id"]): continue
            x, y = note_positions.get(n["id"], (cx, cy))
            color = node_colors.get(f"note:{n['id']}", t.fg)
            transp = node_transp.get(f"note:{n['id']}", 0)
            color = self._alpha_color(color, transp)
            item = cv.create_oval(x - 10, y - 10, x + 10, y + 10, fill=color, outline="")
            label = n.get("title", "?")[:14]
            tags = n.get("tags", "") or ""
            if tags: label += " " + tags
            lbl = cv.create_text(x, y + 18, text=label, fill=t.muted, font=t.f(-3))
            self._node_items[item] = ("note", n["id"], x, y, 10)
            self._node_labels[item] = [lbl]
        # Draw tasks (diamonds)
        for s in tasks:
            if "task" in self._hidden_categories or self._is_node_deleted("task", s["id"]): continue
            x, y = task_positions.get(s["id"], (cx, cy))
            color = node_colors.get(f"task:{s['id']}", s.get("color", t.accent))
            transp = node_transp.get(f"task:{s['id']}", 0)
            color = self._alpha_color(color, transp)
            item = cv.create_polygon(x, y-12, x+12, y, x, y+12, x-12, y, fill=color, outline="")
            label = s.get("name", "?")[:12]
            tags = s.get("tags", "") or ""
            if tags: label += " " + tags
            lbl = cv.create_text(x, y - 18, text=label, fill=t.fg, font=t.f(-3))
            self._node_items[item] = ("task", s["id"], x, y, 12)
            self._node_labels[item] = [lbl]
        # Draw time-period nodes (hexagons)
        for tt in time_tags:
            tid = tt.get("id", "")
            if "time" in self._hidden_categories or self._is_node_deleted("time", tid): continue
            x, y = tp_positions.get(tid, (cx, cy))
            color = node_colors.get(f"time:{tid}", t.success)
            transp = node_transp.get(f"time:{tid}", 0)
            color = self._alpha_color(color, transp)
            pts = []
            for k in range(6):
                a = math.pi / 3 * k - math.pi / 6
                pts.extend([x + 14*math.cos(a), y + 14*math.sin(a)])
            item = cv.create_polygon(pts, fill=color, outline="")
            label = tt.get("tags", "")[:12]
            dur = tt.get("duration", 0)
            lbl1 = cv.create_text(x, y, text=label, fill="#FFF", font=t.f(-3, True))
            lbl2 = cv.create_text(x, y + 22, text=f"{dur}d from {tt.get('start','')[-5:]}", fill=t.dim, font=t.f(-4))
            self._node_items[item] = ("time", tid, x, y, 14)
            self._node_labels[item] = [lbl1, lbl2]
        # v5.9.9: lower ALL edges below ALL nodes in one call (fixes the bug where
        # some connections didn't show until you clicked a node — per-edge tag_lower
        # was racing with node creation)
        cv.tag_lower("edge")
        cv.tag_lower("edgelabel")
        cv.tag_raise("halo")  # keep halo on top if present
        # v5.10: re-apply current zoom level after a full redraw (so Refresh / category
        # toggle / note deletion don't reset the zoom). We scale from the canvas origin
        # because _draw just placed everything at unscaled coordinates.
        if self._zoom != 1.0:
            try:
                cv.scale("all", 0, 0, self._zoom, self._zoom)
                bbox = cv.bbox("all")
                if bbox:
                    cv.configure(scrollregion=bbox)
                # Scale stored node positions + radii to match
                for item_id in list(self._node_items.keys()):
                    typ, idv, nx, ny, r = self._node_items[item_id]
                    self._node_items[item_id] = (typ, idv, nx * self._zoom, ny * self._zoom, r * self._zoom)
            except: pass

    def refresh(self): self._build()


# ============================================================
# MAIN APP
# ============================================================

class MainApp(tk.Tk):
    def __init__(self, d, n):
        super().__init__()
        # Keep the window hidden until the icon is set. If the window is mapped
        # before iconbitmap() runs, the Windows taskbar caches the default Tk
        # feather logo and won't let it go — even if we set a proper icon later.
        self.withdraw()
        self.d = d; self.n = n
        self.theme = Theme(d)
        self.title(get_name(d))
        self.configure(bg=self.theme.bg)
        self.minsize(900, 500)
        self.update_idletasks()
        # v5.9.7: Always fullscreen (maximized). Never windowed.
        # The user explicitly asked for "always full screen, never windowed".
        try: self.state("zoomed")
        except: pass
        # Re-apply zoomed state if the user un-maximizes (always fullscreen).
        self.bind("<Configure>", self._on_configure)
        # v5.9.8: when the window is mapped (deiconified from tray/taskbar),
        # re-apply the icon so the taskbar shows the DILA logo, not the
        # default Tk feather.
        self.bind("<Map>", self._on_map)
        self._set_icon()
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._close)
        self._setup_shortcuts()
        # Now that the icon is set, show the window — the taskbar will pick up
        # the DILA neon logo instead of the Tk feather.
        self.deiconify()
        self._loop()

    def _setup_shortcuts(self):
        """Global keyboard shortcuts."""
        self.bind("<Control-n>", lambda e: self._shortcut_new_streak())
        self.bind("<Control-N>", lambda e: self._shortcut_new_note())
        self.bind("<Control-s>", lambda e: self._shortcut_save())
        self.bind("<Control-b>", lambda e: self._shortcut_bold())
        self.bind("<Control-i>", lambda e: self._shortcut_italic())
        self.bind("<Control-Shift-Left>", lambda e: self._switch("Tasks"))
        self.bind("<Control-Shift-Right>", lambda e: self._switch("Notes"))
        self.bind("<F5>", lambda e: self._switch("Map"))
        self.bind("<F1>", lambda e: self._about())

    def _shortcut_new_streak(self):
        self._switch("Tasks")
        if "Tasks" in self.tabs: self.tabs["Tasks"].new()

    def _shortcut_new_note(self):
        self._switch("Notes")
        if "Notes" in self.tabs: self.tabs["Notes"]._new()

    def _shortcut_save(self):
        # Save current note content
        if "Notes" in self.tabs:
            nv = self.tabs["Notes"]
            if nv.cur:
                nv._flush_pending_save()
                messagebox.showinfo("Saved", "Note saved!", parent=self)

    def _shortcut_bold(self):
        if "Notes" in self.tabs and hasattr(self.tabs["Notes"], "editor"):
            self.tabs["Notes"]._toggle_tag("bold")

    def _shortcut_italic(self):
        if "Notes" in self.tabs and hasattr(self.tabs["Notes"], "editor"):
            self.tabs["Notes"]._toggle_tag("italic")

    def _set_icon(self):
        # Generate the .ico and set it as the window icon.
        # On Windows, iconbitmap(default=path) sets the window class hIcon,
        # which is what the taskbar reliably displays. We do NOT call
        # iconphoto on Windows because Tk checks iconphoto first and it
        # overrides iconbitmap — and the taskbar doesn't pick up the
        # PhotoImage-based icon as reliably as the .ico-based one.
        # Errors are logged to icon_error.log instead of being silently
        # swallowed (so if it still fails we can see why).
        icon_path = APP_DIR / "dila_icon.ico"
        # 1. Always regenerate the .ico with the current neon logo
        if HAS_PIL:
            try:
                logo_img = get_logo(self.d, 256, self.theme)
                logo_img.save(str(icon_path), format="ICO",
                              sizes=[(256,256),(128,128),(64,64),(48,48),(32,32),(16,16)])
            except Exception as e:
                self._log_icon_error("save .ico failed: " + str(e))
        # 2. Set the icon
        if os.name == "nt":
            # Windows: use iconbitmap only (iconphoto would override it)
            try:
                if icon_path.exists():
                    self.iconbitmap(default=str(icon_path))
            except Exception as e:
                self._log_icon_error("iconbitmap failed: " + str(e))
        else:
            # Non-Windows: use iconphoto (no .ico support)
            try:
                logo = get_logo(self.d, 64, self.theme)
                if logo:
                    self.icon_photo = ImageTk.PhotoImage(logo)
                    self.iconphoto(True, self.icon_photo)
            except Exception as e:
                self._log_icon_error("iconphoto failed: " + str(e))

    def _log_icon_error(self, msg):
        try:
            with open(APP_DIR / "icon_error.log", "a") as f:
                f.write(msg + "\n")
        except: pass

    def _on_configure(self, e):
        """v5.9.7: keep the window maximized. If the user restores it down to
        'normal' state, snap it back to 'zoomed'. Always fullscreen, never windowed."""
        if e.widget is not self: return
        try:
            if self.state() == "normal":
                self.state("zoomed")
        except: pass

    def _on_map(self, e):
        """v5.9.8: when the window is mapped (restored from tray/taskbar),
        re-apply the icon so the taskbar shows the DILA logo."""
        if e.widget is not self: return
        # Defer slightly so deiconify completes first
        self.after(50, self._set_icon)

    def _build(self):
        t = self.theme
        # Top bar
        top = tk.Frame(self, bg=t.panel, height=56); top.pack(fill="x", side="top"); top.pack_propagate(False)
        try:
            logo = get_logo(self.d, 32, t)
            self.logo_photo = ImageTk.PhotoImage(logo)
            tk.Label(top, image=self.logo_photo, bg=t.panel).pack(side="left", padx=(16,8), pady=12)
        except: pass
        tk.Label(top, text=get_name(self.d), bg=t.panel, fg=t.accent, font=t.f(4, True)).pack(side="left", padx=(0,20))
        self.score = tk.Label(top, text="", bg=t.panel, fg=t.fg, font=t.f(0, True))
        self.score.pack(side="right", padx=(16,8), pady=10)
        tk.Button(top, text="+ New Task", bg=t.accent, fg="#0E0E14", relief="flat", font=t.f(0, True),
                  cursor="hand2", padx=16, pady=6, command=self._new).pack(side="right", padx=(0,16), pady=10)
        tk.Button(top, text="Settings", bg=t.panel, fg=t.fg, relief="flat", font=t.f(1), cursor="hand2",
                  padx=8, pady=6, command=self._settings).pack(side="right", padx=(0,8), pady=10)
        tk.Button(top, text="About", bg=t.panel, fg=t.fg, relief="flat", font=t.f(1), cursor="hand2",
                  padx=8, pady=6, command=self._about).pack(side="right", padx=(0,8), pady=10)
        # Tabs
        tb = tk.Frame(self, bg=t.bg, height=40); tb.pack(fill="x", side="top")
        self.tabs = {}; self.tab_btns = {}
        for name in ["Tasks", "Notes", "Calendar", "Map", "Stats", "Customize"]:
            btn = tk.Button(tb, text=name, bg=t.bg, fg=t.muted, relief="flat", font=t.f(1, True),
                            cursor="hand2", padx=24, pady=8, command=lambda n=name: self._switch(n))
            btn.pack(side="left", padx=2)
            self.tab_btns[name] = btn
        self.tc = tk.Frame(self, bg=t.bg); self.tc.pack(fill="both", expand=True)
        self.tabs["Tasks"] = StreaksView(self.tc, self.d, t, self.n)
        self.tabs["Notes"] = NotesView(self.tc, self.d, t)
        self.tabs["Calendar"] = CalendarView(self.tc, self.d, t, self.n)
        self.tabs["Map"] = GraphMapView(self.tc, self.d, t)
        self.tabs["Stats"] = StatsView(self.tc, self.d, t)
        self.tabs["Customize"] = CustomizeView(self.tc, self.d, t, on_change=self._changed)
        self._switch("Tasks")
        self._update_score()

    def _switch(self, name):
        t = self.theme
        for tn, btn in self.tab_btns.items():
            btn.configure(bg=t.panel, fg=t.accent) if tn == name else btn.configure(bg=t.bg, fg=t.muted)
        for tn, tab in self.tabs.items():
            if tn == name:
                tab.pack(fill="both", expand=True)
                if hasattr(tab, "refresh"): tab.refresh()
            else:
                tab.pack_forget()

    def _update_score(self):
        t = self.theme
        e, tot = self.d.daily_points()
        if tot > 0:
            pct = int(e * 100 / tot)
            color = t.success if pct == 100 else (t.warn if pct >= 50 else t.danger)
            self.score.configure(text=f"TODAY  {e}/{tot} pts  ({pct}%)", fg=color)
        else:
            self.score.configure(text="TODAY  -", fg=t.muted)

    def _new(self):
        self.tabs["Tasks"].new()
        self._update_score()

    def _settings(self):
        dlg = SettingsDialog(self, self.d, self.theme, self.n)
        self.wait_window(dlg)

    def _about(self):
        dlg = AboutDialog(self, self.d, self.theme)
        self.wait_window(dlg)

    def _changed(self):
        self.theme.refresh()
        self.title(get_name(self.d))
        self._set_icon()
        for w in self.winfo_children(): w.destroy()
        self._build()

    def _loop(self):
        try:
            self._update_score()
            # v5.9.9 FIX: only refresh Tasks list (not detail panel) every 5s — avoids flicker
            if "Tasks" in self.tabs and hasattr(self.tabs["Tasks"], "_refresh_list"):
                self.tabs["Tasks"]._refresh_list()
        except: pass
        self.after(5000, self._loop)

    def _save_window_state(self):
        # v5.9.7: app is always fullscreen — record that.
        try:
            self.d.settings["window_state"] = "zoomed"
            self.d.settings["window_geometry"] = self.geometry()
            self.d.save()
        except: pass

    def _close(self):
        self._save_window_state()
        if self.d.settings.get("min_tray", True) and HAS_TRAY:
            self.withdraw()
        else:
            self.quit()


# ============================================================
# TRAY
# ============================================================

class Tray:
    def __init__(self, app, sched):
        self.app = app; self.sched = sched; self.icon = None
        if HAS_TRAY: self._build()

    def _build(self):
        img = get_logo(self.app.d, 64, self.app.theme)
        menu = pystray.Menu(
            pystray.MenuItem("Open", self._open, default=True),
            pystray.MenuItem("Pause notifications", self._pause),
            pystray.MenuItem("Trigger end-of-day now", self._eod),
            pystray.MenuItem("Exit", self._exit),
        )
        self.icon = pystray.Icon(APP_NAME, img, get_name(self.app.d), menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

    def _open(self, *a):
        # v5.9.8: re-apply the icon after deiconify — Windows forgets the
        # taskbar icon when the window is withdrawn to tray, so when the user
        # clicks the tray icon to bring the app back, the taskbar briefly
        # shows the default Tk feather. Re-setting iconbitmap fixes this.
        def _restore():
            try:
                self.app.deiconify()
                self.app.lift()
                if hasattr(self.app, "_set_icon"):
                    self.app._set_icon()
            except: pass
        try: self.app.after(0, _restore)
        except: pass  # v5.9.9 FIX: app may be destroyed

    def _pause(self, *a):
        self.sched.paused = not self.sched.paused
        if self.icon: self.icon.update_menu()

    def _eod(self, *a):
        self.app.d.settings["eod_done"] = ""
        self.app.d.save()
        self.app.n.eod()

    def _exit(self, *a):
        self.sched.stop()
        if self.icon:
            try: self.icon.stop()
            except: pass
        self.app.after(0, self.app.quit)


# ============================================================
# MAIN
# ============================================================

def main():
    # CRITICAL: set the AppUserModelID at the very start of the process, BEFORE
    # any window is created. If this is done after a Tk window exists, Windows
    # has already grouped the process under the default Python AppUserModelID
    # and the taskbar shows the paper+python icon instead of DILA's logo.
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DILA.App")
        except: pass
    import traceback
    try:
        _run_app()
    except Exception as e:
        # Log the error so we can debug even under pythonw.exe (which suppresses stderr)
        log_path = APP_DIR / "error.log"
        try:
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(f"DILA v{APP_VERSION} crashed at {dt.datetime.now().isoformat()}\n")
                f.write(f"Python: {sys.version}\n")
                f.write(f"Platform: {sys.platform}\n\n")
                f.write(traceback.format_exc())
        except: pass
        # Try to show a messagebox (may fail if tkinter itself is broken)
        try:
            import tkinter.messagebox as mb
            mb.showerror("DILA Error",
                         f"DILA crashed: {e}\n\nError log saved to:\n{log_path}\n\n"
                         f"Please send this log to the developer.")
        except:
            pass

def _run_app():
    d = Data()
    n = Notifier(d)
    if HAS_TOAST:
        try: win11toast.set_app_id(APP_NAME)
        except: pass
        threading.Thread(target=lambda: _safe_toast(
            "Welcome back", "DILA is running. Don't break your streak!"
        ), daemon=True).start()
    s = Scheduler(d, n); s.start()
    app = MainApp(d, n)
    n.app = app  # wire up so popups run on main thread
    tray = Tray(app, s)
    if d.settings.get("autostart"): set_autostart(True)
    try: app.mainloop()
    finally:
        s.stop()
        if tray.icon:
            try: tray.icon.stop()
            except: pass

def _safe_toast(title, body):
    """Wrapper that swallows toast errors (e.g. if win11toast API differs)."""
    try:
        win11toast.notify(title=title, body=body, app_id=APP_NAME, duration="short")
    except Exception as e:
        print(f"Toast error: {e}")

if __name__ == "__main__":
    main()
