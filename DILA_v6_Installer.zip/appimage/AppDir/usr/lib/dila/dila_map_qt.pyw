#!/usr/bin/env python3
"""DILA Interactive Knowledge Map (PyQt6) — launched from the Map tab."""
import os, sys, json, re, math
from pathlib import Path
try:
    from PyQt6.QtWidgets import (QApplication, QGraphicsView, QGraphicsScene,
        QGraphicsEllipseItem, QGraphicsTextItem, QGraphicsLineItem, QGraphicsItem)
    from PyQt6.QtCore import Qt, QPointF
    from PyQt6.QtGui import QBrush, QPen, QColor, QFont, QPainter
except ImportError:
    try:
        import tkinter.messagebox as mb
        mb.showerror("PyQt6 missing", "PyQt6 is required for the interactive map.\nRun: pip install PyQt6")
    except: pass
    sys.exit(1)

APP_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "DILA"
DATA_FILE = APP_DIR / "data.json"
BG="#0E0E14"; CARD="#1E1E2A"; FG="#EAEAF0"; MUTED="#8B8B9A"
ACCENT="#7C5CFF"; SUCCESS="#3FE0A1"; WARN="#FFB347"; BORDER="#2A2A3A"

class GNode(QGraphicsEllipseItem):
    def __init__(self, x, y, r, color, label):
        super().__init__(-r, -r, r*2, r*2)
        self.setPos(x, y)
        self.setBrush(QBrush(QColor(color)))
        self.setPen(QPen(QColor(BORDER), 1))
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setZValue(2)
        lbl = QGraphicsTextItem(label, parent=self)
        lbl.setDefaultTextColor(QColor(FG))
        lbl.setFont(QFont("Segoe UI", 7))
        lbl.setPos(-lbl.boundingRect().width()/2, r + 2)

class MapView(QGraphicsView):
    def __init__(self, scene):
        super().__init__(scene)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setBackgroundBrush(QBrush(QColor(BG)))
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
    def wheelEvent(self, e):
        f = 1.15 if e.angleDelta().y() > 0 else 1/1.15
        self.scale(f, f)

def build():
    if not DATA_FILE.exists(): return None
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    notes = data.get("notes", [])
    streaks = data.get("streaks", [])
    ttags = data.get("settings", {}).get("time_tags", [])
    nbooks = data.get("settings", {}).get("notebooks", [])

    # tag map — scan tags field + content + title for notes
    tag_map = {}
    for n in notes:
        blob = (n.get("tags","") or "") + " " + (n.get("title","") or "") + " " + (n.get("content","") or "")
        for t in re.findall(r'#(\w+)', blob):
            tag_map.setdefault(t, []).append(("note", n["id"]))
    for s in streaks:
        for t in re.findall(r'#(\w+)', s.get("tags","") or ""):
            tag_map.setdefault(t, []).append(("task", s["id"]))
    for tt in ttags:
        for t in re.findall(r'#(\w+)', tt.get("tags","") or ""):
            tag_map.setdefault(t, []).append(("time", tt.get("id","")))

    scene = QGraphicsScene()
    scene.setSceneRect(-600, -450, 1200, 900)
    nodes = {}
    items = []
    for nb in nbooks: items.append(("notebook", nb["id"], nb.get("name","?")[:10], ACCENT, 18))
    for n in notes: items.append(("note", n["id"], n.get("title","?")[:14], FG, 10))
    for s in streaks: items.append(("task", s["id"], s.get("name","?")[:12], s.get("color",ACCENT), 12))
    for tt in ttags: items.append(("time", tt.get("id",""), tt.get("tags","")[:12], SUCCESS, 12))

    n = len(items)
    for i, (typ, idv, label, color, r) in enumerate(items):
        a = 2*math.pi*i/max(n,1) - math.pi/2
        rad = min(350, 60 + n*6)
        node = GNode(rad*math.cos(a), rad*math.sin(a), r, color, label)
        scene.addItem(node)
        nodes[(typ, idv)] = node

    # edges for shared tags
    for tag, its in tag_map.items():
        if len(its) < 2: continue
        for i in range(len(its)):
            for j in range(i+1, len(its)):
                p1 = nodes.get(its[i]); p2 = nodes.get(its[j])
                if p1 and p2:
                    line = QGraphicsLineItem(p1.x(), p1.y(), p2.x(), p2.y())
                    pen = QPen(QColor(WARN)); pen.setStyle(Qt.PenStyle.DashLine); pen.setWidth(1)
                    line.setPen(pen); line.setZValue(0)
                    scene.addItem(line)
    # notebook-note edges
    for nb in nbooks:
        for n2 in notes:
            if n2.get("notebook_id") == nb["id"]:
                p1 = nodes.get(("notebook", nb["id"])); p2 = nodes.get(("note", n2["id"]))
                if p1 and p2:
                    line = QGraphicsLineItem(p1.x(), p1.y(), p2.x(), p2.y())
                    line.setPen(QPen(QColor(BORDER), 1)); line.setZValue(0)
                    scene.addItem(line)
    return scene

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("DILA Map")
    scene = build()
    if not scene:
        from PyQt6.QtWidgets import QMessageBox
        QMessageBox.information(None, "DILA Map", "No data found. Create some notes/tasks first.")
        return
    view = MapView(scene)
    view.setWindowTitle("DILA — Interactive Knowledge Map (PyQt6)")
    view.resize(1200, 800)
    view.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
