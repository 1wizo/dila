#!/usr/bin/env bash
# ============================================================================
#  DILA AppImage builder
#
#  Produces:  DILA-v6-x86_64.AppImage
#
#  Prerequisites:
#     - Linux x86_64 host (or Docker container)
#     - `wget` or `curl` for downloading appimagetool
#     - `chmod` (every Linux has it)
#
#  Usage:
#     cd /path/to/dila-packaging/appimage
#     ./build_appimage.sh
#
#  Output:
#     DILA-v6-x86_64.AppImage
#
#  The script is idempotent — re-running it will rebuild the AppImage
#  from scratch.  No root required.
# ============================================================================
set -euo pipefail

# --- Config -----------------------------------------------------------------
APP_NAME="DILA"
APP_VERSION="6.0.0"
APP_LOWER="dila"
ARCH="x86_64"

# Resolve paths relative to this script so it works from any CWD.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPDIR="$SCRIPT_DIR/AppDir"
OUTPUT_DIR="$SCRIPT_DIR/output"
OUTPUT_IMAGE="$OUTPUT_DIR/${APP_NAME}-v${APP_VERSION}-${ARCH}.AppImage"

# appimagetool lives here once downloaded
TOOL_DIR="$SCRIPT_DIR/.tools"
TOOL_BIN="$TOOL_DIR/appimagetool-${ARCH}.AppImage"
TOOL_URL="https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-${ARCH}.AppImage"

# ----------------------------------------------------------------------------
# 0. Sanity checks
# ----------------------------------------------------------------------------
echo "[build] DILA AppImage builder — v${APP_VERSION}"
echo "[build] ARCH        : ${ARCH}"
echo "[build] APPDIR      : ${APPDIR}"
echo "[build] OUTPUT_IMAGE: ${OUTPUT_IMAGE}"
echo

if [ ! -d "$APPDIR" ]; then
    echo "[build] ERROR: AppDir not found at $APPDIR" >&2
    echo "[build]        Run this script from the packaging/appimage directory." >&2
    exit 1
fi

if [ ! -x "$APPDIR/AppRun" ]; then
    echo "[build] ERROR: $APPDIR/AppRun is missing or not executable." >&2
    exit 1
fi

# ----------------------------------------------------------------------------
# 1. Fetch appimagetool (cached in .tools/)
# ----------------------------------------------------------------------------
mkdir -p "$TOOL_DIR" "$OUTPUT_DIR"

if [ ! -x "$TOOL_BIN" ]; then
    echo "[build] Downloading appimagetool …"
    if command -v wget >/dev/null 2>&1; then
        wget -q -O "$TOOL_BIN" "$TOOL_URL"
    elif command -v curl >/dev/null 2>&1; then
        curl -fsSL -o "$TOOL_BIN" "$TOOL_URL"
    else
        echo "[build] ERROR: need wget or curl to download appimagetool." >&2
        exit 1
    fi
    chmod +x "$TOOL_BIN"
    echo "[build] Cached appimagetool at $TOOL_BIN"
fi

# ----------------------------------------------------------------------------
# 2. Update version strings in the .desktop file
# ----------------------------------------------------------------------------
DESKTOP_FILE="$APPDIR/dila.desktop"
if [ -f "$DESKTOP_FILE" ]; then
    # Ensure Exec and Icon are correct
    if ! grep -q '^Exec=AppRun' "$DESKTOP_FILE"; then
        sed -i 's|^Exec=.*|Exec=AppRun|' "$DESKTOP_FILE"
    fi
    if ! grep -q '^Icon=dila$' "$DESKTOP_FILE"; then
        sed -i 's|^Icon=.*|Icon=dila|' "$DESKTOP_FILE"
    fi
    echo "[build] .desktop file OK"
fi

# ----------------------------------------------------------------------------
# 3. Make sure icons are present at all required sizes
# ----------------------------------------------------------------------------
for size in 16 32 48 64 128 256 512; do
    dir="$APPDIR/usr/share/icons/hicolor/${size}x${size}/apps"
    if [ ! -f "$dir/dila.png" ]; then
        mkdir -p "$dir"
        # Resample from the 512px master
        if command -v convert >/dev/null 2>&1; then
            convert -resize "${size}x${size}" \
                "$APPDIR/usr/share/icons/hicolor/512x512/apps/dila.png" \
                "$dir/dila.png" 2>/dev/null || true
        elif command -v rsvg-convert >/dev/null 2>&1; then
            rsvg-convert -w "$size" -h "$size" \
                "$APPDIR/usr/share/icons/hicolor/scalable/apps/dila.svg" \
                -o "$dir/dila.png" 2>/dev/null || true
        else
            # Fall back to copying the 256 (only if size matches)
            if [ "$size" = "256" ]; then
                cp "$APPDIR/usr/share/icons/hicolor/256x256/apps/dila.png" "$dir/dila.png" 2>/dev/null || true
            fi
        fi
    fi
done

# ----------------------------------------------------------------------------
# 4. Make sure AppRun + .desktop are executable / correct
# ----------------------------------------------------------------------------
chmod +x "$APPDIR/AppRun"
chmod +x "$APPDIR/dila.desktop" 2>/dev/null || true
find "$APPDIR" -name '*.pyw' -exec chmod 0644 {} \;
find "$APPDIR" -name '*.png'   -exec chmod 0644 {} \;
find "$APPDIR" -name '*.svg'   -exec chmod 0644 {} \;
find "$APPDIR" -name '*.txt'   -exec chmod 0644 {} \;

# ----------------------------------------------------------------------------
# 5. Build the AppImage
# ----------------------------------------------------------------------------
echo
echo "[build] Building ${OUTPUT_IMAGE##*/} …"
# We export APPIMAGE_EXTRACT_AND_RUN=1 so appimagetool works inside distros
# that don't have FUSE available (CI containers, Docker, etc.).
# ARCH is required so appimagetool doesn't have to guess.
export APPIMAGE_EXTRACT_AND_RUN=1
export ARCH
"$TOOL_BIN" "$APPDIR" "$OUTPUT_IMAGE"

# ----------------------------------------------------------------------------
# 6. Verify + finalise
# ----------------------------------------------------------------------------
if [ ! -f "$OUTPUT_IMAGE" ]; then
    echo "[build] ERROR: AppImage was not created." >&2
    exit 1
fi
chmod +x "$OUTPUT_IMAGE"

SIZE_HUMAN=$(du -h "$OUTPUT_IMAGE" | cut -f1)
echo
echo "[build] ✅ Built: $OUTPUT_IMAGE"
echo "[build]    Size: $SIZE_HUMAN"
echo
echo "[build] Test it with:"
echo "          ./$OUTPUT_IMAGE"
echo
echo "[build] Distribute it as-is — users just need to:"
echo "          chmod +x ${OUTPUT_IMAGE##*/}"
echo "          ./${OUTPUT_IMAGE##*/}"
