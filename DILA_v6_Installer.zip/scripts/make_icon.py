#!/usr/bin/env python3
"""
Generate the DILA application icon set from the inline SVG logo used by the
original HTA installer. Produces:

  dila.ico     - multi-resolution Windows icon (16,32,48,64,128,256)
  dila_256.png - 256x256 PNG for the Linux AppImage
  dila_512.png - 512x512 PNG (extra)
  dila.svg     - source SVG

The SVG is the exact same logo the HTA injects at runtime (purple→green gradient
square with a flame + checkmark), so visual identity is preserved 1:1.
"""
import os
import cairosvg
from PIL import Image

OUT_DIR = "/home/z/my-project/build/dila"
os.makedirs(OUT_DIR, exist_ok=True)

# --- The exact SVG from the HTA's IC.logo variable -------------------------
SVG = """<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="dg" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
      <stop stop-color="#7c5cff"/>
      <stop offset="0.5" stop-color="#a78bfa"/>
      <stop offset="1" stop-color="#3be0a1"/>
    </linearGradient>
  </defs>
  <rect x="6" y="6" width="88" height="88" rx="22" fill="url(#dg)" opacity="0.18"/>
  <rect x="6" y="6" width="88" height="88" rx="22" stroke="url(#dg)" stroke-width="2" opacity="0.7" fill="none"/>
  <path d="M50 22 C 58 36, 68 40, 64 56 C 78 50, 74 70, 50 78 C 26 70, 22 50, 36 56 C 32 40, 42 36, 50 22 Z" fill="url(#dg)"/>
  <path d="M42 56 L48 62 L60 46" stroke="#0E0E14" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
</svg>"""

svg_path = os.path.join(OUT_DIR, "dila.svg")
with open(svg_path, "w", encoding="utf-8") as f:
    f.write(SVG)
print(f"Wrote {svg_path}")

# render PNG at several sizes
sizes = [16, 24, 32, 48, 64, 128, 256, 512]
pngs = {}
for s in sizes:
    png_path = os.path.join(OUT_DIR, f"_tmp_{s}.png")
    cairosvg.svg2png(bytestring=SVG.encode("utf-8"),
                     write_to=png_path,
                     output_width=s, output_height=s)
    pngs[s] = Image.open(png_path).convert("RGBA")
    print(f"  rendered {s}x{s}")

# Save the canonical 256 and 512 PNGs
pngs[256].save(os.path.join(OUT_DIR, "dila_256.png"))
pngs[512].save(os.path.join(OUT_DIR, "dila_512.png"))
print("Saved dila_256.png and dila_512.png")

# Build multi-resolution .ico
ico_path = os.path.join(OUT_DIR, "dila.ico")
ico_sizes = [16, 24, 32, 48, 64, 128, 256]
ico_images = [pngs[s] for s in ico_sizes]
pngs[256].save(ico_path, format="ICO",
               sizes=[(s, s) for s in ico_sizes])
print(f"Saved {ico_path}")

# cleanup tmp PNGs
for s in sizes:
    p = os.path.join(OUT_DIR, f"_tmp_{s}.png")
    if os.path.exists(p):
        os.remove(p)

# Also drop a 256 PNG specifically named for the AppImage's standard location
print("\nDone. Icon assets in", OUT_DIR)
