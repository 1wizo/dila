#!/usr/bin/env python3
"""
Generate the two wizard BMP files required by Inno Setup:

  wizard.bmp       — left side of Welcome / Finish pages  (modern: 197x313)
  wizard_small.bmp — top-right corner of inner pages      (modern: 69x71)

Inno Setup requires BMP (not PNG).  We render a dark background with the
DILA flame logo so the wizard matches the original HTA's dark/neon look.
"""
import os
import cairosvg
from PIL import Image, ImageDraw, ImageFont

OUT_DIR = "/home/z/my-project/build/dila"

# --- Large wizard image (197x313 for WizardStyle=modern) -------------------
W, H = 197, 313
BG_TOP    = (0x06, 0x06, 0x0c)   # #06060c (HTA bg)
BG_BOT    = (0x0e, 0x0e, 0x16)   # #0e0e16 (HTA bg)

def vertical_gradient(draw, w, h, top, bot):
    for y in range(h):
        t = y / max(1, h-1)
        r = int(top[0] + (bot[0]-top[0]) * t)
        g = int(top[1] + (bot[1]-top[1]) * t)
        b = int(top[2] + (bot[2]-top[2]) * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b))

# Render the DILA logo PNG at high res for compositing
logo_png = os.path.join(OUT_DIR, "_wizard_logo.png")
SVG = open(os.path.join(OUT_DIR, "dila.svg")).read()
cairosvg.svg2png(bytestring=SVG.encode("utf-8"),
                 write_to=logo_png,
                 output_width=140, output_height=140)
logo = Image.open(logo_png).convert("RGBA")

# Large wizard image
img = Image.new("RGB", (W, H), BG_TOP)
d = ImageDraw.Draw(img)
vertical_gradient(d, W, H, BG_TOP, BG_BOT)
# paste logo centered horizontally, near the top
img.paste(logo, ((W - logo.width) // 2, 40), logo)

# Add a thin gradient accent bar at the bottom
bar_h = 6
for y in range(H - bar_h, H):
    t = (y - (H - bar_h)) / max(1, bar_h-1)
    r = int(0x7c + (0x3b - 0x7c) * t)
    g = int(0x5c + (0xe0 - 0x5c) * t)
    b = int(0xff + (0xa1 - 0xff) * t)
    d.line([(0, y), (W, y)], fill=(r, g, b))

# Bottom-right footer text "DILA v6"
try:
    font = ImageFont.truetype(
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 14)
except Exception:
    font = ImageFont.load_default()
d.text((W - 80, H - 26), "DILA v6", fill=(0xff, 0xff, 0xff), font=font)

img.save(os.path.join(OUT_DIR, "wizard.bmp"))
print("Saved wizard.bmp")

# Small wizard image (69x71)
SW, SH = 69, 71
small_logo_png = os.path.join(OUT_DIR, "_wizard_small_logo.png")
cairosvg.svg2png(bytestring=SVG.encode("utf-8"),
                 write_to=small_logo_png,
                 output_width=50, output_height=50)
slogo = Image.open(small_logo_png).convert("RGBA")
simg = Image.new("RGB", (SW, SH), BG_TOP)
sd = ImageDraw.Draw(simg)
vertical_gradient(sd, SW, SH, BG_TOP, BG_BOT)
simg.paste(slogo, ((SW - slogo.width) // 2, (SH - slogo.height) // 2), slogo)
simg.save(os.path.join(OUT_DIR, "wizard_small.bmp"))
print("Saved wizard_small.bmp")

# Cleanup
for p in (logo_png, small_logo_png):
    if os.path.exists(p):
        os.remove(p)

print("\nWizard BMPs ready in", OUT_DIR)
