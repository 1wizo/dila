#!/usr/bin/env python3
"""
Extract the two base64-encoded Python application files (dila.pyw and
dila_map_qt.pyw) from the original DILA HTA installer and write them to disk
so the new Inno Setup + AppImage installers can package them.

The HTA declares:
    var DILA_B64 = "...";
    var DILA_MAP_B64 = "...";
We pull the contents of each string literal and base64-decode them.
"""
import base64
import os
import re
import sys

HTA_PATH = "/home/z/my-project/upload/DILA_v5.12_Setup.hta"
OUT_DIR  = "/home/z/my-project/build/dila"

def extract_var(html: str, var_name: str) -> str:
    """Return the raw string contents of `var NAME = "....";`."""
    # match: var NAME = "....";  (the payload can contain escaped \" but
    # in this HTA the strings are pure base64 with no escapes)
    pat = re.compile(
        r'var\s+' + re.escape(var_name) + r'\s*=\s*"((?:[^"\\]|\\.)*)"\s*;',
        re.DOTALL,
    )
    m = pat.search(html)
    if not m:
        raise RuntimeError(f"Could not find variable {var_name} in HTA")
    raw = m.group(1)
    # unescape \" \\ etc.
    raw = raw.replace('\\"', '"').replace('\\\\', '\\')
    return raw

def main():
    with open(HTA_PATH, "r", encoding="utf-8", errors="replace") as f:
        html = f.read()

    os.makedirs(OUT_DIR, exist_ok=True)

    targets = [
        ("DILA_B64",      "dila.pyw"),
        ("DILA_MAP_B64",  "dila_map_qt.pyw"),
    ]
    for var, fname in targets:
        print(f"Extracting {var} -> {fname} ...")
        b64 = extract_var(html, var)
        data = base64.b64decode(b64)
        out_path = os.path.join(OUT_DIR, fname)
        with open(out_path, "wb") as f:
            f.write(data)
        # show first 4 lines so we can sanity-check
        head = data.decode("utf-8", errors="replace").splitlines()[:6]
        print(f"  wrote {len(data)} bytes to {out_path}")
        for ln in head:
            print(f"    | {ln}")
        print()

    # also extract the LICENSE text — the HTA references a license page
    # but the actual license text lives in a JS variable `LICENSE_TEXT`
    # if present. We'll search for any var that looks like it.
    m = re.search(r'var\s+LICENSE_TEXT\s*=\s*"((?:[^"\\]|\\.)*)"\s*;', html, re.DOTALL)
    if m:
        lic = m.group(1).replace('\\n', '\n').replace('\\"', '"').replace('\\\\', '\\')
        with open(os.path.join(OUT_DIR, "LICENSE.txt"), "w", encoding="utf-8") as f:
            f.write(lic)
        print(f"Wrote LICENSE.txt ({len(lic)} bytes)")
    else:
        print("No LICENSE_TEXT variable found in HTA")

if __name__ == "__main__":
    sys.exit(main() or 0)
