@echo off
REM ===========================================================================
REM  DILA installer - Step 5: Create shortcuts + write initial data.json.
REM
REM  This replaces Inno Setup's [Icons] section.  Doing it in batch lets us
REM  resolve the actual pythonw.exe path on this system (which might be
REM  Python 3.11/3.12/3.13) and write the .lnk files with the correct
REM  TargetPath.
REM
REM  Shortcuts created (matching the HTA's behaviour):
REM     - Desktop\DILA.lnk           (if "desktopicon" task selected)
REM     - Start Menu\DILA\DILA.lnk   (if "startmenuicon" task selected)
REM     - Startup\DILA.lnk           (if "autostart" task selected)
REM
REM  Theme + min_tray are written to data.json (HTA: Dark Neon + true).
REM ===========================================================================
setlocal enabledelayedexpansion

call :findpy
if not defined DILA_PYW (
  echo [DILA] shortcuts: no Python found, cannot create shortcuts
  exit /b 1
)

REM -- Read the Inno Setup task selections from environment ---------------
REM Inno Setup passes {code:GetSelectedTask} values via env vars when
REM [Run] entries are Flagged checkable.  But since we removed [Icons],
REM we have to read the tasks ourselves.  Inno writes selected task names
REM to a temp file we can read.

REM -- Defaults: match the HTA (desktop + start menu ON, autostart OFF) --
set "DO_DESKTOP=1"
set "DO_STARTMENU=1"
set "DO_AUTOSTART=0"
set "DO_MINTRAY=1"

REM -- Read the Inno task selection file if present -----------------------
REM Inno writes /TASKS="desktopicon,startmenuicon,..." to the install log
REM but doesn't expose it to [Run] entries directly.  We use a small
REM workaround: the tasks are encoded in the env var DILA_TASKS if the
REM user passed them via /TASKS= on the installer command line.  If not
REM present, we use the defaults above (which match the HTA defaults).
if defined DILA_TASKS (
  echo !DILA_TASKS! | findstr /i "desktopicon"   >nul && set "DO_DESKTOP=1"   || set "DO_DESKTOP=0"
  echo !DILA_TASKS! | findstr /i "startmenuicon" >nul && set "DO_STARTMENU=1" || set "DO_STARTMENU=0"
  echo !DILA_TASKS! | findstr /i "autostart"     >nul && set "DO_AUTOSTART=1" || set "DO_AUTOSTART=0"
  echo !DILA_TASKS! | findstr /i "mintray"       >nul && set "DO_MINTRAY=1"   || set "DO_MINTRAY=0"
)

set "APPDIR=%LOCALAPPDATA%\DILA"
set "ICON=%APPDIR%\dila.ico"
set "TARGET=%DILA_PYW%"
set "ARGS=""%APPDIR%\dila.pyw"""
set "DESC=DILA - Streak Tracker + Notes"

echo [DILA] App dir: %APPDIR%
echo [DILA] PythonW: %TARGET%
echo [DILA] Tasks: desktop=!DO_DESKTOP! startmenu=!DO_STARTMENU! autostart=!DO_AUTOSTART! mintray=!DO_MINTRAY!

REM -- Stop any running DILA so we can recreate the folder ----------------
echo [DILA] Stopping any running DILA ...
taskkill /FI "IMAGENAME eq pythonw.exe" /F >nul 2>&1
taskkill /FI "IMAGENAME eq python.exe"  /F >nul 2>&1

REM -- Create shortcuts via PowerShell (more reliable than VBScript) -----
REM PowerShell can create .lnk files via WScript.Shell COM object.

set "PS1=%TEMP%\dila_shortcuts.ps1"
> "%PS1%" echo $ws = New-Object -ComObject WScript.Shell
>> "%PS1%" echo $appdir = $env:LOCALAPPDATA + '\DILA'
>> "%PS1%" echo $icon   = "$appdir\dila.ico"
>> "%PS1%" echo $target = $env:DILA_PYW
>> "%PS1%" echo $args   = '"' + $appdir + '\dila.pyw"'
>> "%PS1%" echo $desc   = 'DILA - Streak Tracker + Notes'

if "%DO_DESKTOP%"=="1" (
  >> "%PS1%" echo $lnk = [Environment]::GetFolderPath('Desktop') + '\DILA.lnk'
  >> "%PS1%" echo $sc = $ws.CreateShortcut($lnk)
  >> "%PS1%" echo $sc.TargetPath = $target
  >> "%PS1%" echo $sc.Arguments = $args
  >> "%PS1%" echo $sc.WorkingDirectory = $appdir
  >> "%PS1%" echo $sc.IconLocation = "$icon,0"
  >> "%PS1%" echo $sc.Description = $desc
  >> "%PS1%" echo $sc.Save()
  >> "%PS1%" echo Write-Host "[DILA] Created $lnk"
)

if "%DO_STARTMENU%"=="1" (
  >> "%PS1%" echo $progDir = [Environment]::GetFolderPath('Programs')
  >> "%PS1%" echo $dilaDir = "$progDir\DILA"
  >> "%PS1%" echo if (-not (Test-Path $dilaDir)) { New-Item -ItemType Directory -Path $dilaDir ^| Out-Null }
  >> "%PS1%" echo $lnk = "$dilaDir\DILA.lnk"
  >> "%PS1%" echo $sc = $ws.CreateShortcut($lnk)
  >> "%PS1%" echo $sc.TargetPath = $target
  >> "%PS1%" echo $sc.Arguments = $args
  >> "%PS1%" echo $sc.WorkingDirectory = $appdir
  >> "%PS1%" echo $sc.IconLocation = "$icon,0"
  >> "%PS1%" echo $sc.Description = $desc
  >> "%PS1%" echo $sc.Save()
  >> "%PS1%" echo Write-Host "[DILA] Created $lnk"
)

if "%DO_AUTOSTART%"=="1" (
  >> "%PS1%" echo $lnk = [Environment]::GetFolderPath('Startup') + '\DILA.lnk'
  >> "%PS1%" echo $sc = $ws.CreateShortcut($lnk)
  >> "%PS1%" echo $sc.TargetPath = $target
  >> "%PS1%" echo $sc.Arguments = $args
  >> "%PS1%" echo $sc.WorkingDirectory = $appdir
  >> "%PS1%" echo $sc.IconLocation = "$icon,0"
  >> "%PS1%" echo $sc.Description = $desc
  >> "%PS1%" echo $sc.Save()
  >> "%PS1%" echo Write-Host "[DILA] Created $lnk"
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"
del /q "%PS1%" 2>nul

if not "%RC%"=="0" (
  echo [DILA] WARNING: shortcut creation returned exit code %RC%
)

REM -- Write initial data.json (HTA behaviour: install folder) ------------
REM Schema: {"streaks":[],"notes":[],"settings":{"theme":"Dark Neon","min_tray":true}}
set "MINTRAY=true"
if "%DO_MINTRAY%"=="0" set "MINTRAY=false"

set "JSON={\"streaks\":[],\"notes\":[],\"settings\":{\"theme\":\"Dark Neon\",\"min_tray\":%MINTRAY%}}"
> "%APPDIR%\data.json" echo %JSON%
echo [DILA] Wrote %APPDIR%\data.json (theme=Dark Neon, min_tray=%MINTRAY%)

REM -- Also write to %APPDATA%\DILA\data.json if it doesn't exist ----------
REM (this is the location dila.pyw actually reads from)
if not exist "%APPDATA%\DILA" mkdir "%APPDATA%\DILA"
if not exist "%APPDATA%\DILA\data.json" (
  > "%APPDATA%\DILA\data.json" echo %JSON%
  echo [DILA] Wrote %APPDATA%\DILA\data.json (first-run defaults)
)

REM -- Copy uninstall_ask.bat into the install folder ---------------------
> "%APPDIR%\uninstall_ask.bat" echo @echo off
>> "%APPDIR%\uninstall_ask.bat" echo REM Called by Inno's [UninstallRun]. Asks whether to delete user data.
>> "%APPDIR%\uninstall_ask.bat" echo setlocal
>> "%APPDIR%\uninstall_ask.bat" echo set "CHOICE=0"
>> "%APPDIR%\uninstall_ask.bat" echo powershell -NoProfile -Command "Add-Type -AssemblyName PresentationFramework; $r = [System.Windows.MessageBox]::Show('Do you also want to delete your DILA streaks, notes and settings? This cannot be undone.', 'DILA Uninstall', 'YesNo', 'Question', 'No'); if ($r -eq 'Yes') { '1' ^| Out-File -Encoding ascii '%TEMP%\dila_uninst_choice.txt' -NoNewline } else { '0' ^| Out-File -Encoding ascii '%TEMP%\dila_uninst_choice.txt' -NoNewline }"
>> "%APPDIR%\uninstall_ask.bat" echo if exist "%TEMP%\dila_uninst_choice.txt" set /p CHOICE=^<"%TEMP%\dila_uninst_choice.txt"
>> "%APPDIR%\uninstall_ask.bat" echo if "%CHOICE%"=="1" (
>> "%APPDIR%\uninstall_ask.bat" echo   rmdir /s /q "%APPDATA%\DILA" 2^>nul
>> "%APPDIR%\uninstall_ask.bat" echo   rmdir /s /q "%LOCALAPPDATA%\DILA" 2^>nul
>> "%APPDIR%\uninstall_ask.bat" echo   echo [DILA] User data deleted.
>> "%APPDIR%\uninstall_ask.bat" echo ) else (
>> "%APPDIR%\uninstall_ask.bat" echo   echo [DILA] User data preserved.
>> "%APPDIR%\uninstall_ask.bat" echo )
>> "%APPDIR%\uninstall_ask.bat" echo del /q "%TEMP%\dila_uninst_choice.txt" 2^>nul
>> "%APPDIR%\uninstall_ask.bat" echo endlocal
echo [DILA] Wrote %APPDIR%\uninstall_ask.bat

endlocal
exit /b 0

:findpy
if defined DILA_PYW exit /b 0
if exist "%TEMP%\dila_pyenv.cmd" call "%TEMP%\dila_pyenv.cmd"
if defined DILA_PYW exit /b 0
REM Detect Python at common locations
for %%V in (Python312 Python311 Python313 Python310) do (
  if exist "%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe" (
    set "DILA_PYEXE=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
    set "DILA_PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"
    set "DILA_PYDIR=%LOCALAPPDATA%\Programs\Python\%%V"
    exit /b 0
  )
)
exit /b 0
