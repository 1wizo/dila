@echo off
REM ===========================================================================
REM  DILA installer - Step 3: pip install all Python dependencies.
REM  Mirrors the HTA's stepInstallDeps() Python portion.
REM
REM  Packages (exact same set as the HTA):
REM     pystray Pillow pyttsx3 numpy matplotlib win11toast PyQt6 dukpy
REM ===========================================================================
setlocal enabledelayedexpansion

call :findpy
if not defined DILA_PYEXE (
  echo [DILA] pip deps: no Python found, cannot install deps
  exit /b 1
)

echo [DILA] Step 3: Installing Python dependencies ...

echo [DILA] Upgrading pip ...
"%DILA_PYEXE%" -m pip install --upgrade pip --quiet
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo [DILA] pip upgrade returned %RC% (continuing)

echo [DILA] Installing runtime packages ...
"%DILA_PYEXE%" -m pip install pystray Pillow pyttsx3 numpy matplotlib win11toast PyQt6 dukpy --quiet
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo [DILA] One or more packages failed to install (exit %RC%).
  echo [DILA] DILA will still run, but some features may be disabled.
  echo [DILA] You can retry manually with:
  echo [DILA]   "%DILA_PYEXE%" -m pip install pystray Pillow pyttsx3 numpy matplotlib win11toast PyQt6 dukpy
  exit /b 0
)

echo [DILA] All Python packages ready.
endlocal & set "DILA_PYEXE=%DILA_PYEXE%"
exit /b 0

:findpy
if defined DILA_PYEXE exit /b 0
if exist "%TEMP%\dila_pyenv.cmd" call "%TEMP%\dila_pyenv.cmd"
if defined DILA_PYEXE exit /b 0
for %%V in (Python312 Python311 Python313 Python310) do (
  if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" (
    set "DILA_PYEXE=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
    set "DILA_PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"
    set "DILA_PYDIR=%LOCALAPPDATA%\Programs\Python\%%V%"
    exit /b 0
  )
)
exit /b 0
