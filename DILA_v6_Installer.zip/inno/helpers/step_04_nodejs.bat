@echo off
REM ===========================================================================
REM  DILA installer - Step 5: Install Node.js LTS for JS code execution.
REM  Mirrors the HTA's stepInstallDeps() Node.js portion.
REM
REM  Strategy:
REM     1. Try `winget install OpenJS.NodeJS.LTS --silent`
REM     2. Fallback: download node-v20.11.1-x64.msi from nodejs.org
REM        and install with msiexec /qn
REM     3. If both fail, warn the user but continue (app still works,
REM        only JS code blocks won't run).
REM ===========================================================================
setlocal enabledelayedexpansion

REM -- Already installed? ----------------------------------------------------
where node >nul 2>&1
if %ERRORLEVEL%==0 (
  echo [DILA] Node.js already installed:
  node --version
  exit /b 0
)
if exist "%ProgramFiles%\nodejs\node.exe" (
  echo [DILA] Node.js found at %ProgramFiles%\nodejs\
  exit /b 0
)

echo [DILA] Step 4: Installing Node.js LTS ...

REM -- 1) winget ------------------------------------------------------------
where winget >nul 2>&1
if %ERRORLEVEL%==0 (
  echo [DILA] Trying winget ...
  winget install OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements --silent
  if !ERRORLEVEL!==0 (
    echo [DILA] Node.js installed via winget.
    exit /b 0
  )
  echo [DILA] winget failed (exit !ERRORLEVEL!), falling back to MSI download.
) else (
  echo [DILA] winget not available, downloading Node.js MSI ...
)

REM -- 2) MSI download + silent install ------------------------------------
set "NODEMSI=%TEMP%\node-lts.msi"
set "NODEURL=https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; ^
   $ProgressPreference = 'SilentlyContinue'; ^
   (New-Object System.Net.WebClient).DownloadFile('%NODEURL%', '%NODEMSI%')"

if not exist "%NODEMSI%" (
  echo [DILA] Node.js download failed - JS code blocks will show an error.
  echo [DILA] Install manually from https://nodejs.org/
  exit /b 0
)

echo [DILA] MSI downloaded, installing silently ...
msiexec /i "%NODEMSI%" /qn /norestart
set "RC=%ERRORLEVEL%"
del /q "%NODEMSI%" 2>nul

if "%RC%"=="0" (
  echo [DILA] Node.js installed via MSI.
) else (
  echo [DILA] Node.js MSI install failed (code %RC%) - JS code blocks will show an error.
  echo [DILA] Install manually from https://nodejs.org/
)

exit /b 0
