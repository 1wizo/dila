@echo off
REM ===========================================================================
REM  DILA installer - Step 6: Persist detected Python paths.
REM
REM  Writes a small file to %APPDATA%\DILA\python_paths.txt so the
REM  uninstaller / future upgrades know which Python the app is bound to.
REM ===========================================================================
setlocal enabledelayedexpansion

call :findpy

if not defined DILA_PYEXE (
  echo [DILA] userdata: no Python found, skipping path export
  exit /b 0
)

if not exist "%APPDATA%\DILA" mkdir "%APPDATA%\DILA"
> "%APPDATA%\DILA\python_paths.txt" echo DILA_PYEXE=%DILA_PYEXE%
>> "%APPDATA%\DILA\python_paths.txt" echo DILA_PYW=%DILA_PYW%
>> "%APPDATA%\DILA\python_paths.txt" echo DILA_PYDIR=%DILA_PYDIR%
echo [DILA] Wrote %APPDATA%\DILA\python_paths.txt

endlocal
exit /b 0

:findpy
if defined DILA_PYEXE exit /b 0
if exist "%TEMP%\dila_pyenv.cmd" call "%TEMP%\dila_pyenv.cmd"
if defined DILA_PYEXE exit /b 0
for %%V in (Python312 Python311 Python313 Python310) do (
  if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" (
    set "DILA_PYEXE=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
    set "DILA_PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"
    set "DILA_PYDIR=%LOCALAPPDATA%\Programs\Python\%%V%"
    exit /b 0
  )
)
exit /b 0
