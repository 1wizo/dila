@echo off
REM ===========================================================================
REM  DILA installer - Step 2: Test tkinter; repair Python if missing.
REM  Mirrors the HTA's stepTestTkinter().
REM ===========================================================================
setlocal enabledelayedexpansion

call :findpy
if not defined DILA_PYEXE (
  echo [DILA] tkinter test: no Python found, skipping
  exit /b 0
)

echo [DILA] Step 2: Verifying tkinter UI toolkit ...
"%DILA_PYEXE%" -c "import tkinter; root = tkinter.Tk(); root.destroy(); print('OK')"
set "RC=%ERRORLEVEL%"

if "%RC%"=="0" (
  echo [DILA] tkinter loaded OK
  echo [DILA] No repair needed.
  exit /b 0
)

echo [DILA] tkinter missing - repairing Python ...
set "PYINSTALLER=%TEMP%\python-3.12.3-amd64.exe"
if not exist "%PYINSTALLER%" (
  echo [DILA] Re-downloading Python installer for repair ...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
    "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; ^
     $ProgressPreference = 'SilentlyContinue'; ^
     (New-Object System.Net.WebClient).DownloadFile('https://www.python.org/ftp/python/3.12.3/python-3.12.3-amd64.exe', '%PYINSTALLER%')"
)

"%PYINSTALLER%" /quiet InstallAllUsers=0 PrependPath=0 Include_tcltk=1 Include_pip=1 Include_lib=1 InstallLauncherAllUsers=0 TargetDir="%DILA_PYDIR%"
set "RC=%ERRORLEVEL%"
echo [DILA] Repair complete (exit %RC%)
exit /b 0

:findpy
if defined DILA_PYEXE exit /b 0
if exist "%TEMP%\dila_pyenv.cmd" call "%TEMP%\dila_pyenv.cmd"
if defined DILA_PYEXE exit /b 0
for %%V in (Python312 Python311 Python313 Python310) do (
  if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" (
    set "DILA_PYEXE=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
    set "DILA_PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"
    set "DILA_PYDIR=%LOCALAPPDATA%\Programs\Python\%%V%"
    exit /b 0
  )
)
exit /b 0
