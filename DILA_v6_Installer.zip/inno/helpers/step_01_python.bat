@echo off
REM ===========================================================================
REM  DILA installer - Step 1: Detect or download + install Python 3.12.3.
REM
REM  Mirrors the HTA's stepDownload() + stepInstallPython().
REM
REM  Behaviour:
REM    - If Python 3.10-3.13 already exists at a known location, USE it
REM      and skip the download/install.  Write its path to %TEMP%\dila_pyenv.cmd
REM      so subsequent steps can pick it up.
REM    - Otherwise, download python-3.12.3-amd64.exe from python.org and
REM      install it quietly (user scope, no admin) to the HTA's default
REM      location: %LOCALAPPDATA%\Programs\Python\Python312.
REM
REM  Exports (via %TEMP%\dila_pyenv.cmd):
REM    DILA_PYEXE   full path to python.exe
REM    DILA_PYW     full path to pythonw.exe
REM    DILA_PYDIR   Python install directory
REM ===========================================================================
setlocal enabledelayedexpansion

set "PYVER=3.12.3"
set "PYINSTALLER=python-%PYVER%-amd64.exe"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/%PYINSTALLER%"
set "HTA_PYDIR=%LOCALAPPDATA%\Programs\Python\Python312"
set "HTA_PYEXE=%HTA_PYDIR%\python.exe"
set "HTA_PYW=%HTA_PYDIR%\pythonw.exe"
set "DL=%TEMP%\%PYINSTALLER%"
set "ENVFILE=%TEMP%\dila_pyenv.cmd"

echo [DILA] Step 1: Preparing Python runtime ...

REM -- 1) Check common locations for an existing Python 3.10-3.13 ---------
for %%V in (Python312 Python311 Python313 Python310) do (
  if exist "%LOCALAPPDATA%\Programs\Python\%%V\python.exe" (
    if exist "%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe" (
      set "DILA_PYEXE=%LOCALAPPDATA%\Programs\Python\%%V\python.exe"
      set "DILA_PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"
      set "DILA_PYDIR=%LOCALAPPDATA%\Programs\Python\%%V"
      echo [DILA] Found existing Python at !DILA_PYDIR!
      goto :write_env
    )
  )
)

REM -- 2) No existing Python - download + install -------------------------
echo [DILA] No existing Python found. Downloading %PYINSTALLER% ...

set "PS1=%TEMP%\dila_dl_py.ps1"
> "%PS1%" echo [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
>> "%PS1%" echo $ProgressPreference = 'SilentlyContinue'
>> "%PS1%" echo $ErrorActionPreference = 'Stop'
>> "%PS1%" echo try {
>> "%PS1%" echo   $wc = New-Object System.Net.WebClient
>> "%PS1%" echo   $wc.DownloadFile('%PYURL%', '%DL%')
>> "%PS1%" echo   if ((Test-Path '%DL%') -and ((Get-Item '%DL%').Length -gt 1000000)) { exit 0 } else { exit 2 }
>> "%PS1%" echo } catch {
>> "%PS1%" echo   try { [IO.File]::WriteAllText('%TEMP%\dila_dl_py_err.txt', $_.Exception.Message) } catch {}
>> "%PS1%" echo   exit 1
>> "%PS1%" echo }

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"
del /q "%PS1%" 2>nul
if not "%RC%"=="0" (
  if exist "%TEMP%\dila_dl_py_err.txt" (
    set /p DLERR=<"%TEMP%\dila_dl_py_err.txt"
  ) else (
    set "DLERR=(no detail captured)"
  )
  echo [DILA] FAILED to download Python.
  echo [DILA] Reason: !DLERR!
  echo [DILA] Please install Python %PYVER% manually from https://www.python.org/downloads/
  exit /b 1
)

echo [DILA] Installing Python quietly (user scope, no admin required) ...
"%DL%" /quiet InstallAllUsers=0 PrependPath=0 Include_tcltk=1 Include_pip=1 InstallLauncherAllUsers=0 TargetDir="%HTA_PYDIR%"
set "RC=%ERRORLEVEL%"
del /q "%DL%" 2>nul
if not "%RC%"=="0" (
  echo [DILA] Python installer returned exit code %RC%
  exit /b %RC%
)

REM -- 3) Wait up to 60s for python.exe to appear -------------------------
set /a TRIES=0
:waitpy
if exist "%HTA_PYEXE%" if exist "%HTA_PYW%" goto :pyok
set /a TRIES+=1
if %TRIES% GEQ 60 (
  echo [DILA] Python did not install correctly. The installer may have been blocked.
  exit /b 1
)
timeout /t 1 /nobreak >nul
goto :waitpy

:pyok
set "DILA_PYEXE=%HTA_PYEXE%"
set "DILA_PYW=%HTA_PYW%"
set "DILA_PYDIR=%HTA_PYDIR%"
echo [DILA] Python installed at %HTA_PYDIR%

:write_env
REM -- Write %TEMP%\dila_pyenv.cmd so subsequent batch steps can call it ---
> "%ENVFILE%" echo @echo off
>> "%ENVFILE%" echo set "DILA_PYEXE=%DILA_PYEXE%"
>> "%ENVFILE%" echo set "DILA_PYW=%DILA_PYW%"
>> "%ENVFILE%" echo set "DILA_PYDIR=%DILA_PYDIR%"
echo [DILA] Wrote %ENVFILE%
echo [DILA]   DILA_PYEXE=%DILA_PYEXE%
echo [DILA]   DILA_PYW=%DILA_PYW%
echo [DILA]   DILA_PYDIR=%DILA_PYDIR%

endlocal & (
  set "DILA_PYEXE=%DILA_PYEXE%"
  set "DILA_PYW=%DILA_PYW%"
  set "DILA_PYDIR=%DILA_PYDIR%"
)
exit /b 0
