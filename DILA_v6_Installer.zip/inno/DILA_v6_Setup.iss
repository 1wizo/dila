; ============================================================================
;  DILA  -  Inno Setup installer (replaces DILA_v5.12_Setup.hta)
;  Version: 6.0.0
;
;  This installer is a 1:1 behavioural replacement of the original HTA
;  installer.  Every step the HTA performed is preserved here:
;
;     1. Download Python 3.12.3 from python.org            (if missing)
;     2. Install Python quietly, user scope, no admin      (if missing)
;     3. Test tkinter; repair if broken
;     4. pip install --upgrade pip
;        pip install pystray Pillow pyttsx3 numpy
;                    matplotlib win11toast PyQt6 dukpy
;     5. Install Node.js LTS via winget (fallback: MSI)    (if missing)
;     6. Stop any running DILA, recreate install folder
;     7. Write dila.pyw + dila_map_qt.pyw + icon + LICENSE
;     8. Create Desktop / Start Menu / Startup shortcuts
;     9. Write initial data.json (theme=Dark Neon, min_tray=true)
;    10. Register with Add/Remove Programs
;
;  User data (%APPDATA%\DILA\data.json) is preserved across upgrades
;  and is NOT removed on uninstall unless the user explicitly opts in.
;
;  Build:
;     ISCC.exe DILA_v6_Setup.iss
;
;  Tested with Inno Setup 6.0.0+ (Unicode).
; ============================================================================

#define MyAppName          "DILA"
#define MyAppVersion       "6.0.0"
#define MyAppPublisher     "wizo"
#define MyAppURL           "https://github.com/wizo/dila"
#define MyAppExeName       "dila.pyw"
#define MyAppCopyright     "Copyright (c) 2025 wizo"

[Setup]
AppId={{8F4E6D9A-2C7B-4E1F-9A3D-5C2E1B7F8D4A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
AppCopyright={#MyAppCopyright}
AppContact={#MyAppPublisher}

; Install into the user's LOCALAPPDATA - exactly like the HTA, so NO admin
; prompt is ever shown.
DefaultDirName={localappdata}\DILA
DisableDirPage=no
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=no

; Single-file installer
OutputDir=Output
OutputBaseFilename=DILA_v6_Setup

; Branding
SetupIconFile=..\dila\dila.ico
UninstallDisplayIcon={app}\dila.ico
UninstallDisplayName={#MyAppName}
LicenseFile=..\dila\LICENSE.txt
Compression=lzma2/ultra64
SolidCompression=yes

; Wizard look & feel
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
DisableWelcomePage=no
DisableReadyPage=no
DisableFinishedPage=no
ShowLanguageDialog=no
LanguageDetectionMethod=none

; Misc
CloseApplications=force
RestartApplications=no
VersionInfoVersion={#MyAppVersion}
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription={#MyAppName} Setup
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
MinVersion=10.0

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

; ---------------------------------------------------------------------------
;  Tasks  -  mirrors the HTA "Options" toggles
; ---------------------------------------------------------------------------
[Tasks]
Name: "desktopicon";       Description: "{cm:CreateDesktopIcon}";            GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce
Name: "startmenuicon";     Description: "Add DILA to my Start Menu";        GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce checkablealone
Name: "autostart";         Description: "Start DILA with Windows";          GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce unchecked
Name: "mintray";           Description: "Minimize DILA to the system tray"; GroupDescription: "Behavior:";            Flags: checkedonce

; ---------------------------------------------------------------------------
;  Files  -  bundled assets
; ---------------------------------------------------------------------------
[Files]
Source: "..\dila\dila.pyw";          DestDir: "{app}"; Flags: ignoreversion overwritereadonly
Source: "..\dila\dila_map_qt.pyw";   DestDir: "{app}"; Flags: ignoreversion overwritereadonly
Source: "..\dila\dila.ico";          DestDir: "{app}"; Flags: ignoreversion
Source: "..\dila\dila_256.png";      DestDir: "{app}"; Flags: ignoreversion
Source: "..\dila\LICENSE.txt";       DestDir: "{app}"; Flags: ignoreversion
Source: "helpers\*"; DestDir: "{tmp}"; Flags: deleteafterinstall

; ---------------------------------------------------------------------------
;  Dirs
; ---------------------------------------------------------------------------
[Dirs]
Name: "{app}";               Flags: uninsneveruninstall
Name: "{localappdata}\DILA"; Flags: uninsneveruninstall

; ---------------------------------------------------------------------------
;  Icons  -  created only if the matching task was selected.
;
;  Target is pythonw.exe resolved by step_01_python.bat.  The actual
;  pythonw.exe path is baked into the shortcut by step_06_shortcuts.bat
;  after Python is installed/detected, so we DON'T use [Icons] here.
;  See [Run] step 6 below.
; ---------------------------------------------------------------------------

; ---------------------------------------------------------------------------
;  Run  -  the real install logic, run after files are copied.
;
;  Each helper batch file is independent - they detect Python/Node
;  themselves and act accordingly.  No Pascal Script [Code] section
;  is needed.
; ---------------------------------------------------------------------------
[Run]
; Step 1+2: Download Python 3.12.3 + install silently IF Python is missing.
Filename: "{tmp}\step_01_python.bat"; \
    WorkingDir: "{tmp}"; \
    Flags: runhidden waituntilterminated; \
    StatusMsg: "Step 1 of 6 - Preparing Python 3.12.3 runtime ..."

; Step 3: Test tkinter; repair Python if missing.
Filename: "{tmp}\step_02_tkinter.bat"; \
    WorkingDir: "{tmp}"; \
    Flags: runhidden waituntilterminated; \
    StatusMsg: "Step 2 of 6 - Verifying tkinter UI toolkit ..."

; Step 4: pip upgrade + install all Python deps.
Filename: "{tmp}\step_03_pipdeps.bat"; \
    WorkingDir: "{tmp}"; \
    Flags: runhidden waituntilterminated; \
    StatusMsg: "Step 3 of 6 - Installing Python dependencies ..."

; Step 5: Install Node.js LTS (winget -> MSI fallback) IF Node is missing.
Filename: "{tmp}\step_04_nodejs.bat"; \
    WorkingDir: "{tmp}"; \
    Flags: runhidden waituntilterminated; \
    StatusMsg: "Step 4 of 6 - Installing Node.js LTS ..."

; Step 6: Create Desktop / Start Menu / Startup shortcuts + write data.json.
;         This batch file resolves the actual pythonw.exe path on this system
;         and writes the .lnk files + data.json accordingly.
Filename: "{tmp}\step_05_shortcuts.bat"; \
    WorkingDir: "{tmp}"; \
    Flags: runhidden waituntilterminated; \
    StatusMsg: "Step 5 of 6 - Creating shortcuts ..."

; Step 7: Persist detected Python paths for the uninstaller / future upgrades.
Filename: "{tmp}\step_06_userdata.bat"; \
    WorkingDir: "{tmp}"; \
    Flags: runhidden waituntilterminated; \
    StatusMsg: "Step 6 of 6 - Writing initial settings ..."

; DILA does NOT auto-launch after install (per the HTA's v5.9.9 change).

; ---------------------------------------------------------------------------
;  Uninstall - remove only program files; user data is preserved unless the
;  user explicitly opts in.
; ---------------------------------------------------------------------------
[UninstallRun]
Filename: "taskkill";   Parameters: "/FI ""IMAGENAME eq pythonw.exe"" /F"; Flags: runhidden waituntilterminated; RunOnceId: "KillPythonw"
Filename: "taskkill";   Parameters: "/FI ""IMAGENAME eq python.exe"" /F";  Flags: runhidden waituntilterminated; RunOnceId: "KillPython"
; Ask the user about deleting their data, then act on the answer.
Filename: "{app}\uninstall_ask.bat"; WorkingDir: "{app}"; Flags: runhidden waituntilterminated; RunOnceId: "AskUserData"

[UninstallDelete]
Type: files;       Name: "{app}\dila.pyw"
Type: files;       Name: "{app}\dila_map_qt.pyw"
Type: files;       Name: "{app}\dila.ico"
Type: files;       Name: "{app}\dila_256.png"
Type: files;       Name: "{app}\LICENSE.txt"
Type: files;       Name: "{app}\data.json"
Type: files;       Name: "{app}\install.log"
Type: files;       Name: "{app}\uninstall_ask.bat"
Type: dirifempty;  Name: "{app}"

; ---------------------------------------------------------------------------
;  Registry - Add/Remove Programs entry.
; ---------------------------------------------------------------------------
[Registry]
Root: HKCU; Subkey: "Software\DILA"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\DILA"; ValueType: string; ValueName: "Version";     ValueData: "{#MyAppVersion}"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Uninstall\DILA"; ValueType: string; ValueName: "DisplayIcon"; ValueData: "{app}\dila.ico"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Uninstall\DILA"; ValueType: string; ValueName: "Publisher";  ValueData: "{#MyAppPublisher}"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Uninstall\DILA"; ValueType: string; ValueName: "HelpLink";   ValueData: "{#MyAppURL}"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Uninstall\DILA"; ValueType: string; ValueName: "NoModify";    ValueData: "1"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Uninstall\DILA"; ValueType: string; ValueName: "NoRepair";    ValueData: "1"; Flags: uninsdeletekey

; ---------------------------------------------------------------------------
;  NO [Code] SECTION.
;
;  All logic that the original HTA implemented in JavaScript is here
;  implemented as standalone batch files under helpers\.  This keeps
;  the .iss trivially compilable by any version of Inno Setup 6 and
;  avoids Pascal Script syntax pitfalls entirely.
; ---------------------------------------------------------------------------
